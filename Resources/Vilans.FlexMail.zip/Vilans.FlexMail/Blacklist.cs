﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FlexMail.Service;

using System.Globalization;
using System.Resources;

namespace FlexMail
{
    /// <summary>
    /// 
    /// </summary>
    public partial class Blacklist : IDisposable
    {
        internal Blacklist()
        {
            FlexMail.Resources.Blacklist.Culture = Client.CultureInfo;
        }

        #region Import

        private ImportBlacklistResp _import = null;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="emailAddressTypeItems"></param>
        /// <param name="mailingListTypeItems"></param>
        /// <returns></returns>
        public List<ImportBlacklistRespType> Import(EmailAddressType[] emailAddressTypeItems = null, MailingListType[] mailingListTypeItems = null)
        {
            try
            {
                if (_import == null)
                {
                    var req = new ImportBlacklistReq() { header = Client.RequestHeader };

                    if (emailAddressTypeItems != null)
                        req.emailAddressTypeItems = emailAddressTypeItems;

                    if (mailingListTypeItems != null)
                        req.mailingListTypeItems = mailingListTypeItems;

                    ImportBlacklistRequest request = new ImportBlacklistRequest() { ImportBlacklistReq = req };
                    ImportBlacklistResponse response = Client.API.ImportBlacklist(request);
                    _import = response.ImportBlacklistResp;
                }

                if (_import != null && _import.errorCode == (int)errorCode.No_error)
                    return _import.importBlacklistRespTypeItems.ToList<ImportBlacklistRespType>();
                else
                    if (_import != null) throw new FlexMailException(FlexMail.Resources.Blacklist.ResourceManager.GetString("Import_" + _import.errorCode), _import.errorCode);

            }
            catch (Exception ex)
            {
                System.Diagnostics.Trace.TraceError(ex.Message);
                throw;
            }
            finally
            {
                _import = null;
            }
        }

        #endregion

        #region IDisposable Support

        private bool disposedValue = false; // To detect redundant calls

        /// <summary>
        /// 
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {
                }

                _import = null;

                disposedValue = true;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        ~Blacklist() { Dispose(false); }

        /// <summary>
        /// 
        /// </summary>
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        #endregion


    }
}
