﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FlexMail.Service;

namespace FlexMail
{
    /// <summary>
    /// 
    /// </summary>
    public class MailingList : IDisposable
    {
        #region MailingLists

        private GetMailingListsResp _mailingLists = null;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="categoryId"></param>
        /// <returns></returns>
        public List<MailingListType> MailingLists(string categoryId = null)
        {
            try
            {
                if (_mailingLists == null)
                {
                    var req = new GetMailingListsReq() { header = Client.RequestHeader };

                    if (!string.IsNullOrWhiteSpace(categoryId))
                        req.categoryId = int.Parse(categoryId);

                    GetMailingListsRequest request = new GetMailingListsRequest() { GetMailingListsReq = req };
                    GetMailingListsResponse response = Client.API.GetMailingLists(request);
                    _mailingLists = response.GetMailingListsResp;
                }

                if (_mailingLists.errorCode == (int)errorCode.No_error)
                    return _mailingLists.mailingListTypeItems.ToList<MailingListType>();

                throw new FlexMailException(_mailingLists.errorMessage, _mailingLists.errorCode);
            }
            catch (Exception)
            {
                System.Diagnostics.Trace.TraceError(_mailingLists.errorMessage);
                throw;
            }
            finally
            {
                _mailingLists = null;
            }
        }

        #endregion

        #region Create

        private CreateMailingListResp _create = null;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="categoryId"></param>
        /// <param name="mailingListName"></param>
        /// <param name="mailingListLanguage"></param>
        /// <returns></returns>
        public int Create(string categoryId = null, string mailingListName = null, string mailingListLanguage = "NL")
        {
            try
            {
                if (_create == null)
                {
                    var req = new CreateMailingListReq() { header = Client.RequestHeader };

                    if (!string.IsNullOrWhiteSpace(categoryId))
                        req.categoryId = int.Parse(categoryId);

                    if (!string.IsNullOrWhiteSpace(mailingListName))
                        req.mailingListName = mailingListName;

                    req.mailingListLanguage = mailingListLanguage;

                    CreateMailingListRequest request = new CreateMailingListRequest() { CreateMailingListReq = req };
                    CreateMailingListResponse response = Client.API.CreateMailingList(request);
                    _create = response.CreateMailingListResp;
                }

                if(_create.errorCode == (int)errorCode.No_error)
                    return _create.mailingListId;

                throw new FlexMailException(_create.errorMessage, _create.errorCode);
            }
            catch (Exception)
            {
                System.Diagnostics.Trace.TraceError(_create.errorMessage);
                throw;
            }
            finally
            {
                _create = null;
            }
        }

        #endregion

        #region Delete

        private DeleteMailingListResp _delete = null;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="mailingListId"></param>
        public void Delete(string mailingListId = null)
        {
            try
            {

                if (_delete == null)
                {
                    var req = new DeleteMailingListReq() { header = Client.RequestHeader };

                    if (!string.IsNullOrWhiteSpace(mailingListId))
                        req.mailingListId = int.Parse(mailingListId);

                    DeleteMailingListRequest request = new DeleteMailingListRequest() { DeleteMailingListReq = req };
                    DeleteMailingListResponse response = Client.API.DeleteMailingList(request);
                    _delete = response.DeleteMailingListResp;
                }

                if(_delete.errorCode == (int)errorCode.No_error)
                    return;

                throw new FlexMailException(_delete.errorMessage, _delete.errorCode);
            }
            catch (Exception)
            {
                System.Diagnostics.Trace.TraceError(_delete.errorMessage);
                throw;
            }
            finally
            {
                _delete = null;
            }
        }

        #endregion

        #region Update

        private UpdateMailingListResp _update = null;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="mailingListId"></param>
        /// <param name="mailingListName"></param>
        public void Update(string mailingListId = null, string mailingListName = null)
        {
            try
            {
                if (_update == null)
                {
                    var req = new UpdateMailingListReq() { header = Client.RequestHeader };

                    if (!string.IsNullOrWhiteSpace(mailingListId))
                        req.mailingListId = int.Parse(mailingListId);

                    if (!string.IsNullOrWhiteSpace(mailingListName))
                        req.mailingListName = mailingListName;

                    UpdateMailingListRequest request = new UpdateMailingListRequest() { UpdateMailingListReq = req };
                    UpdateMailingListResponse response = Client.API.UpdateMailingList(request);
                    _update = response.UpdateMailingListResp;
                }

                if(_update.errorCode == (int)errorCode.No_error)
                    return;

                throw new FlexMailException(_update.errorMessage, _update.errorCode);
            }
            catch (Exception)
            {
                System.Diagnostics.Trace.TraceError(_update.errorMessage);
                throw;
            }

            finally
            {
                _update = null;
            }
        }

        #endregion

        #region Truncate

        private TruncateMailingListResp _truncate = null;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="mailingListId"></param>
        public void Truncate(string mailingListId = null)
        {
            try
            {
                if (_truncate == null)
                {
                    var req = new TruncateMailingListReq() { header = Client.RequestHeader };

                    if (!string.IsNullOrWhiteSpace(mailingListId))
                        req.mailingListId = int.Parse(mailingListId);

                    TruncateMailingListRequest request = new TruncateMailingListRequest() { TruncateMailingListReq = req };
                    TruncateMailingListResponse response = Client.API.TruncateMailingList(request);
                    _truncate = response.TruncateMailingListResp;
                }

                if(_truncate.errorCode == (int)errorCode.No_error)
                    return;

                throw new FlexMailException(_truncate.errorMessage, _truncate.errorCode);
            }
            catch (Exception)
            {
                System.Diagnostics.Trace.TraceError(_truncate.errorMessage);
                throw;
            }

            finally
            {
                _truncate = null;
            }
        }

        #endregion

        #region IDisposable Support

        private bool disposedValue = false; // To detect redundant calls

        /// <summary>
        /// 
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {
                }

                _create = null;
                _delete = null;
                _mailingLists = null;
                _truncate = null;
                _update = null;

                disposedValue = true;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        ~MailingList() { Dispose(false); }

        /// <summary>
        /// 
        /// </summary>
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        #endregion

    }
}
