﻿namespace FlexMail.Service
{
    #pragma warning disable 1591

    /// <summary>
    /// 
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.ServiceContractAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl", ConfigurationName = "FlexMail.ServiceAPIPortType")]
    public interface FlexmailAPIPortType
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [System.ServiceModel.OperationContractAttribute(Action = "CreateCategory", ReplyAction = "*")]
        [System.ServiceModel.XmlSerializerFormatAttribute(Style = System.ServiceModel.OperationFormatStyle.Rpc, SupportFaults = true, Use = System.ServiceModel.OperationFormatUse.Encoded)]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(GVSelectionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportBlacklistRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormResultType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EmailAddressHistoryActionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FileType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkHitType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ProfileUpdateType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(SubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(UnsubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(BounceType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportEmailAddressRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CustomFieldType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EfficyEventType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(MailingListType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CategoryType))]
        FlexMail.Service.CreateCategoryResponse CreateCategory(FlexMail.Service.CreateCategoryRequest request);

        /// <summary>
        /// 
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [System.ServiceModel.OperationContractAttribute(Action = "CreateCategory", ReplyAction = "*")]
        System.Threading.Tasks.Task<FlexMail.Service.CreateCategoryResponse> CreateCategoryAsync(FlexMail.Service.CreateCategoryRequest request);

        /// <summary>
        /// 
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [System.ServiceModel.OperationContractAttribute(Action = "UpdateCategory", ReplyAction = "*")]
        [System.ServiceModel.XmlSerializerFormatAttribute(Style = System.ServiceModel.OperationFormatStyle.Rpc, SupportFaults = true, Use = System.ServiceModel.OperationFormatUse.Encoded)]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(GVSelectionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportBlacklistRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormResultType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EmailAddressHistoryActionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FileType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkHitType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ProfileUpdateType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(SubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(UnsubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(BounceType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportEmailAddressRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CustomFieldType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EfficyEventType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(MailingListType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CategoryType))]
        FlexMail.Service.UpdateCategoryResponse UpdateCategory(FlexMail.Service.UpdateCategoryRequest request);

        /// <summary>
        /// 
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [System.ServiceModel.OperationContractAttribute(Action = "UpdateCategory", ReplyAction = "*")]
        System.Threading.Tasks.Task<FlexMail.Service.UpdateCategoryResponse> UpdateCategoryAsync(FlexMail.Service.UpdateCategoryRequest request);

        /// <summary>
        /// 
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [System.ServiceModel.OperationContractAttribute(Action = "DeleteCategory", ReplyAction = "*")]
        [System.ServiceModel.XmlSerializerFormatAttribute(Style = System.ServiceModel.OperationFormatStyle.Rpc, SupportFaults = true, Use = System.ServiceModel.OperationFormatUse.Encoded)]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(GVSelectionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportBlacklistRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormResultType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EmailAddressHistoryActionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FileType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkHitType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ProfileUpdateType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(SubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(UnsubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(BounceType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportEmailAddressRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CustomFieldType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EfficyEventType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(MailingListType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CategoryType))]
        FlexMail.Service.DeleteCategoryResponse DeleteCategory(FlexMail.Service.DeleteCategoryRequest request);

        /// <summary>
        /// 
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [System.ServiceModel.OperationContractAttribute(Action = "DeleteCategory", ReplyAction = "*")]
        System.Threading.Tasks.Task<FlexMail.Service.DeleteCategoryResponse> DeleteCategoryAsync(FlexMail.Service.DeleteCategoryRequest request);

        /// <summary>
        /// 
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [System.ServiceModel.OperationContractAttribute(Action = "GetCategories", ReplyAction = "*")]
        [System.ServiceModel.XmlSerializerFormatAttribute(Style = System.ServiceModel.OperationFormatStyle.Rpc, SupportFaults = true, Use = System.ServiceModel.OperationFormatUse.Encoded)]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(GVSelectionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportBlacklistRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormResultType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EmailAddressHistoryActionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FileType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkHitType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ProfileUpdateType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(SubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(UnsubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(BounceType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportEmailAddressRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CustomFieldType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EfficyEventType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(MailingListType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CategoryType))]
        FlexMail.Service.GetCategoriesResponse GetCategories(FlexMail.Service.GetCategoriesRequest request);

        /// <summary>
        /// 
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [System.ServiceModel.OperationContractAttribute(Action = "GetCategories", ReplyAction = "*")]
        System.Threading.Tasks.Task<FlexMail.Service.GetCategoriesResponse> GetCategoriesAsync(FlexMail.Service.GetCategoriesRequest request);

        /// <summary>
        /// 
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [System.ServiceModel.OperationContractAttribute(Action = "CreateMailingList", ReplyAction = "*")]
        [System.ServiceModel.XmlSerializerFormatAttribute(Style = System.ServiceModel.OperationFormatStyle.Rpc, SupportFaults = true, Use = System.ServiceModel.OperationFormatUse.Encoded)]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(GVSelectionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportBlacklistRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormResultType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EmailAddressHistoryActionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FileType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkHitType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ProfileUpdateType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(SubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(UnsubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(BounceType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportEmailAddressRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CustomFieldType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EfficyEventType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(MailingListType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CategoryType))]
        FlexMail.Service.CreateMailingListResponse CreateMailingList(FlexMail.Service.CreateMailingListRequest request);

        /// <summary>
        /// 
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [System.ServiceModel.OperationContractAttribute(Action = "CreateMailingList", ReplyAction = "*")]
        System.Threading.Tasks.Task<FlexMail.Service.CreateMailingListResponse> CreateMailingListAsync(FlexMail.Service.CreateMailingListRequest request);

        /// <summary>
        /// 
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [System.ServiceModel.OperationContractAttribute(Action = "UpdateMailingList", ReplyAction = "*")]
        [System.ServiceModel.XmlSerializerFormatAttribute(Style = System.ServiceModel.OperationFormatStyle.Rpc, SupportFaults = true, Use = System.ServiceModel.OperationFormatUse.Encoded)]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(GVSelectionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportBlacklistRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormResultType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EmailAddressHistoryActionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FileType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkHitType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ProfileUpdateType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(SubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(UnsubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(BounceType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportEmailAddressRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CustomFieldType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EfficyEventType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(MailingListType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CategoryType))]
        FlexMail.Service.UpdateMailingListResponse UpdateMailingList(FlexMail.Service.UpdateMailingListRequest request);

        /// <summary>
        /// 
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [System.ServiceModel.OperationContractAttribute(Action = "UpdateMailingList", ReplyAction = "*")]
        System.Threading.Tasks.Task<FlexMail.Service.UpdateMailingListResponse> UpdateMailingListAsync(FlexMail.Service.UpdateMailingListRequest request);

        /// <summary>
        /// 
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [System.ServiceModel.OperationContractAttribute(Action = "DeleteMailingList", ReplyAction = "*")]
        [System.ServiceModel.XmlSerializerFormatAttribute(Style = System.ServiceModel.OperationFormatStyle.Rpc, SupportFaults = true, Use = System.ServiceModel.OperationFormatUse.Encoded)]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(GVSelectionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportBlacklistRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormResultType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EmailAddressHistoryActionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FileType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkHitType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ProfileUpdateType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(SubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(UnsubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(BounceType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportEmailAddressRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CustomFieldType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EfficyEventType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(MailingListType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CategoryType))]
        FlexMail.Service.DeleteMailingListResponse DeleteMailingList(FlexMail.Service.DeleteMailingListRequest request);

        /// <summary>
        /// 
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [System.ServiceModel.OperationContractAttribute(Action = "DeleteMailingList", ReplyAction = "*")]
        System.Threading.Tasks.Task<FlexMail.Service.DeleteMailingListResponse> DeleteMailingListAsync(FlexMail.Service.DeleteMailingListRequest request);

        /// <summary>
        /// 
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [System.ServiceModel.OperationContractAttribute(Action = "TruncateMailingList", ReplyAction = "*")]
        [System.ServiceModel.XmlSerializerFormatAttribute(Style = System.ServiceModel.OperationFormatStyle.Rpc, SupportFaults = true, Use = System.ServiceModel.OperationFormatUse.Encoded)]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(GVSelectionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportBlacklistRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormResultType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EmailAddressHistoryActionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FileType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkHitType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ProfileUpdateType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(SubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(UnsubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(BounceType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportEmailAddressRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CustomFieldType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EfficyEventType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(MailingListType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CategoryType))]
        FlexMail.Service.TruncateMailingListResponse TruncateMailingList(FlexMail.Service.TruncateMailingListRequest request);

        /// <summary>
        /// 
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [System.ServiceModel.OperationContractAttribute(Action = "TruncateMailingList", ReplyAction = "*")]
        System.Threading.Tasks.Task<FlexMail.Service.TruncateMailingListResponse> TruncateMailingListAsync(FlexMail.Service.TruncateMailingListRequest request);

        /// <summary>
        /// 
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [System.ServiceModel.OperationContractAttribute(Action = "GetMailingLists", ReplyAction = "*")]
        [System.ServiceModel.XmlSerializerFormatAttribute(Style = System.ServiceModel.OperationFormatStyle.Rpc, SupportFaults = true, Use = System.ServiceModel.OperationFormatUse.Encoded)]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(GVSelectionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportBlacklistRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormResultType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EmailAddressHistoryActionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FileType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkHitType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ProfileUpdateType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(SubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(UnsubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(BounceType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportEmailAddressRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CustomFieldType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EfficyEventType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(MailingListType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CategoryType))]
        FlexMail.Service.GetMailingListsResponse GetMailingLists(FlexMail.Service.GetMailingListsRequest request);

        /// <summary>
        /// 
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [System.ServiceModel.OperationContractAttribute(Action = "GetMailingLists", ReplyAction = "*")]
        System.Threading.Tasks.Task<FlexMail.Service.GetMailingListsResponse> GetMailingListsAsync(FlexMail.Service.GetMailingListsRequest request);

        /// <summary>
        /// 
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [System.ServiceModel.OperationContractAttribute(Action = "CreateEmailAddress", ReplyAction = "*")]
        [System.ServiceModel.XmlSerializerFormatAttribute(Style = System.ServiceModel.OperationFormatStyle.Rpc, SupportFaults = true, Use = System.ServiceModel.OperationFormatUse.Encoded)]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(GVSelectionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportBlacklistRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormResultType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EmailAddressHistoryActionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FileType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkHitType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ProfileUpdateType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(SubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(UnsubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(BounceType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportEmailAddressRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CustomFieldType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EfficyEventType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(MailingListType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CategoryType))]
        FlexMail.Service.CreateEmailAddressResponse CreateEmailAddress(FlexMail.Service.CreateEmailAddressRequest request);

        /// <summary>
        /// 
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [System.ServiceModel.OperationContractAttribute(Action = "CreateEmailAddress", ReplyAction = "*")]
        System.Threading.Tasks.Task<FlexMail.Service.CreateEmailAddressResponse> CreateEmailAddressAsync(FlexMail.Service.CreateEmailAddressRequest request);

        /// <summary>
        /// 
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [System.ServiceModel.OperationContractAttribute(Action = "UpdateEmailAddress", ReplyAction = "*")]
        [System.ServiceModel.XmlSerializerFormatAttribute(Style = System.ServiceModel.OperationFormatStyle.Rpc, SupportFaults = true, Use = System.ServiceModel.OperationFormatUse.Encoded)]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(GVSelectionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportBlacklistRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormResultType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EmailAddressHistoryActionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FileType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkHitType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ProfileUpdateType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(SubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(UnsubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(BounceType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportEmailAddressRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CustomFieldType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EfficyEventType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(MailingListType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CategoryType))]
        FlexMail.Service.UpdateEmailAddressResponse UpdateEmailAddress(FlexMail.Service.UpdateEmailAddressRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "UpdateEmailAddress", ReplyAction = "*")]
        System.Threading.Tasks.Task<FlexMail.Service.UpdateEmailAddressResponse> UpdateEmailAddressAsync(FlexMail.Service.UpdateEmailAddressRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "DeleteEmailAddress", ReplyAction = "*")]
        [System.ServiceModel.XmlSerializerFormatAttribute(Style = System.ServiceModel.OperationFormatStyle.Rpc, SupportFaults = true, Use = System.ServiceModel.OperationFormatUse.Encoded)]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(GVSelectionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportBlacklistRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormResultType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EmailAddressHistoryActionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FileType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkHitType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ProfileUpdateType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(SubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(UnsubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(BounceType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportEmailAddressRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CustomFieldType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EfficyEventType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(MailingListType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CategoryType))]
        FlexMail.Service.DeleteEmailAddressResponse DeleteEmailAddress(FlexMail.Service.DeleteEmailAddressRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "DeleteEmailAddress", ReplyAction = "*")]
        System.Threading.Tasks.Task<FlexMail.Service.DeleteEmailAddressResponse> DeleteEmailAddressAsync(FlexMail.Service.DeleteEmailAddressRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "ImportEmailAddresses", ReplyAction = "*")]
        [System.ServiceModel.XmlSerializerFormatAttribute(Style = System.ServiceModel.OperationFormatStyle.Rpc, SupportFaults = true, Use = System.ServiceModel.OperationFormatUse.Encoded)]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(GVSelectionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportBlacklistRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormResultType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EmailAddressHistoryActionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FileType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkHitType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ProfileUpdateType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(SubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(UnsubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(BounceType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportEmailAddressRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CustomFieldType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EfficyEventType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(MailingListType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CategoryType))]
        FlexMail.Service.ImportEmailAddressesResponse ImportEmailAddresses(FlexMail.Service.ImportEmailAddressesRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "ImportEmailAddresses", ReplyAction = "*")]
        System.Threading.Tasks.Task<FlexMail.Service.ImportEmailAddressesResponse> ImportEmailAddressesAsync(FlexMail.Service.ImportEmailAddressesRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "GetEmailAddresses", ReplyAction = "*")]
        [System.ServiceModel.XmlSerializerFormatAttribute(Style = System.ServiceModel.OperationFormatStyle.Rpc, SupportFaults = true, Use = System.ServiceModel.OperationFormatUse.Encoded)]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(GVSelectionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportBlacklistRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormResultType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EmailAddressHistoryActionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FileType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkHitType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ProfileUpdateType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(SubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(UnsubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(BounceType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportEmailAddressRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CustomFieldType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EfficyEventType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(MailingListType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CategoryType))]
        FlexMail.Service.GetEmailAddressesResponse GetEmailAddresses(FlexMail.Service.GetEmailAddressesRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "GetEmailAddresses", ReplyAction = "*")]
        System.Threading.Tasks.Task<FlexMail.Service.GetEmailAddressesResponse> GetEmailAddressesAsync(FlexMail.Service.GetEmailAddressesRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "GetEmailAddressSubscriptions", ReplyAction = "*")]
        [System.ServiceModel.XmlSerializerFormatAttribute(Style = System.ServiceModel.OperationFormatStyle.Rpc, SupportFaults = true, Use = System.ServiceModel.OperationFormatUse.Encoded)]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(GVSelectionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportBlacklistRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormResultType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EmailAddressHistoryActionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FileType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkHitType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ProfileUpdateType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(SubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(UnsubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(BounceType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportEmailAddressRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CustomFieldType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EfficyEventType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(MailingListType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CategoryType))]
        FlexMail.Service.GetEmailAddressSubscriptionsResponse GetEmailAddressSubscriptions(FlexMail.Service.GetEmailAddressSubscriptionsRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "GetEmailAddressSubscriptions", ReplyAction = "*")]
        System.Threading.Tasks.Task<FlexMail.Service.GetEmailAddressSubscriptionsResponse> GetEmailAddressSubscriptionsAsync(FlexMail.Service.GetEmailAddressSubscriptionsRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "CreateMessage", ReplyAction = "*")]
        [System.ServiceModel.XmlSerializerFormatAttribute(Style = System.ServiceModel.OperationFormatStyle.Rpc, SupportFaults = true, Use = System.ServiceModel.OperationFormatUse.Encoded)]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(GVSelectionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportBlacklistRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormResultType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EmailAddressHistoryActionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FileType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkHitType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ProfileUpdateType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(SubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(UnsubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(BounceType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportEmailAddressRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CustomFieldType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EfficyEventType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(MailingListType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CategoryType))]
        FlexMail.Service.CreateMessageResponse CreateMessage(FlexMail.Service.CreateMessageRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "CreateMessage", ReplyAction = "*")]
        System.Threading.Tasks.Task<FlexMail.Service.CreateMessageResponse> CreateMessageAsync(FlexMail.Service.CreateMessageRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "UpdateMessage", ReplyAction = "*")]
        [System.ServiceModel.XmlSerializerFormatAttribute(Style = System.ServiceModel.OperationFormatStyle.Rpc, SupportFaults = true, Use = System.ServiceModel.OperationFormatUse.Encoded)]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(GVSelectionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportBlacklistRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormResultType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EmailAddressHistoryActionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FileType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkHitType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ProfileUpdateType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(SubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(UnsubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(BounceType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportEmailAddressRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CustomFieldType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EfficyEventType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(MailingListType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CategoryType))]
        FlexMail.Service.UpdateMessageResponse UpdateMessage(FlexMail.Service.UpdateMessageRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "UpdateMessage", ReplyAction = "*")]
        System.Threading.Tasks.Task<FlexMail.Service.UpdateMessageResponse> UpdateMessageAsync(FlexMail.Service.UpdateMessageRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "DeleteMessage", ReplyAction = "*")]
        [System.ServiceModel.XmlSerializerFormatAttribute(Style = System.ServiceModel.OperationFormatStyle.Rpc, SupportFaults = true, Use = System.ServiceModel.OperationFormatUse.Encoded)]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(GVSelectionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportBlacklistRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormResultType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EmailAddressHistoryActionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FileType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkHitType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ProfileUpdateType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(SubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(UnsubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(BounceType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportEmailAddressRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CustomFieldType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EfficyEventType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(MailingListType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CategoryType))]
        FlexMail.Service.DeleteMessageResponse DeleteMessage(FlexMail.Service.DeleteMessageRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "DeleteMessage", ReplyAction = "*")]
        System.Threading.Tasks.Task<FlexMail.Service.DeleteMessageResponse> DeleteMessageAsync(FlexMail.Service.DeleteMessageRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "GetMessages", ReplyAction = "*")]
        [System.ServiceModel.XmlSerializerFormatAttribute(Style = System.ServiceModel.OperationFormatStyle.Rpc, SupportFaults = true, Use = System.ServiceModel.OperationFormatUse.Encoded)]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(GVSelectionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportBlacklistRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormResultType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EmailAddressHistoryActionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FileType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkHitType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ProfileUpdateType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(SubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(UnsubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(BounceType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportEmailAddressRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CustomFieldType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EfficyEventType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(MailingListType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CategoryType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(MessageType))]
        FlexMail.Service.GetMessagesResponse GetMessages(FlexMail.Service.GetMessagesRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "GetMessages", ReplyAction = "*")]
        System.Threading.Tasks.Task<FlexMail.Service.GetMessagesResponse> GetMessagesAsync(FlexMail.Service.GetMessagesRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "CreateLandingPage", ReplyAction = "*")]
        [System.ServiceModel.XmlSerializerFormatAttribute(Style = System.ServiceModel.OperationFormatStyle.Rpc, SupportFaults = true, Use = System.ServiceModel.OperationFormatUse.Encoded)]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(GVSelectionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportBlacklistRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormResultType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EmailAddressHistoryActionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FileType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkHitType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ProfileUpdateType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(SubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(UnsubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(BounceType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportEmailAddressRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CustomFieldType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EfficyEventType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(MailingListType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CategoryType))]
        FlexMail.Service.CreateLandingPageResponse CreateLandingPage(FlexMail.Service.CreateLandingPageRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "CreateLandingPage", ReplyAction = "*")]
        System.Threading.Tasks.Task<FlexMail.Service.CreateLandingPageResponse> CreateLandingPageAsync(FlexMail.Service.CreateLandingPageRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "UpdateLandingPage", ReplyAction = "*")]
        [System.ServiceModel.XmlSerializerFormatAttribute(Style = System.ServiceModel.OperationFormatStyle.Rpc, SupportFaults = true, Use = System.ServiceModel.OperationFormatUse.Encoded)]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(GVSelectionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportBlacklistRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormResultType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EmailAddressHistoryActionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FileType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkHitType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ProfileUpdateType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(SubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(UnsubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(BounceType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportEmailAddressRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CustomFieldType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EfficyEventType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(MailingListType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CategoryType))]
        FlexMail.Service.UpdateLandingPageResponse UpdateLandingPage(FlexMail.Service.UpdateLandingPageRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "UpdateLandingPage", ReplyAction = "*")]
        System.Threading.Tasks.Task<FlexMail.Service.UpdateLandingPageResponse> UpdateLandingPageAsync(FlexMail.Service.UpdateLandingPageRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "DeleteLandingPage", ReplyAction = "*")]
        [System.ServiceModel.XmlSerializerFormatAttribute(Style = System.ServiceModel.OperationFormatStyle.Rpc, SupportFaults = true, Use = System.ServiceModel.OperationFormatUse.Encoded)]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(GVSelectionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportBlacklistRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormResultType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EmailAddressHistoryActionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FileType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkHitType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ProfileUpdateType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(SubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(UnsubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(BounceType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportEmailAddressRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CustomFieldType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EfficyEventType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(MailingListType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CategoryType))]
        FlexMail.Service.DeleteLandingPageResponse DeleteLandingPage(FlexMail.Service.DeleteLandingPageRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "DeleteLandingPage", ReplyAction = "*")]
        System.Threading.Tasks.Task<FlexMail.Service.DeleteLandingPageResponse> DeleteLandingPageAsync(FlexMail.Service.DeleteLandingPageRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "GetLandingPages", ReplyAction = "*")]
        [System.ServiceModel.XmlSerializerFormatAttribute(Style = System.ServiceModel.OperationFormatStyle.Rpc, SupportFaults = true, Use = System.ServiceModel.OperationFormatUse.Encoded)]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(GVSelectionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportBlacklistRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormResultType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EmailAddressHistoryActionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FileType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkHitType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ProfileUpdateType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(SubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(UnsubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(BounceType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportEmailAddressRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CustomFieldType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EfficyEventType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(MailingListType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CategoryType))]
        FlexMail.Service.GetLandingPagesResponse GetLandingPages(FlexMail.Service.GetLandingPagesRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "GetLandingPages", ReplyAction = "*")]
        System.Threading.Tasks.Task<FlexMail.Service.GetLandingPagesResponse> GetLandingPagesAsync(FlexMail.Service.GetLandingPagesRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "CreateTemplate", ReplyAction = "*")]
        [System.ServiceModel.XmlSerializerFormatAttribute(Style = System.ServiceModel.OperationFormatStyle.Rpc, SupportFaults = true, Use = System.ServiceModel.OperationFormatUse.Encoded)]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(GVSelectionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportBlacklistRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormResultType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EmailAddressHistoryActionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FileType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkHitType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ProfileUpdateType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(SubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(UnsubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(BounceType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportEmailAddressRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CustomFieldType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EfficyEventType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(MailingListType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CategoryType))]
        FlexMail.Service.CreateTemplateResponse CreateTemplate(FlexMail.Service.CreateTemplateRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "CreateTemplate", ReplyAction = "*")]
        System.Threading.Tasks.Task<FlexMail.Service.CreateTemplateResponse> CreateTemplateAsync(FlexMail.Service.CreateTemplateRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "UpdateTemplate", ReplyAction = "*")]
        [System.ServiceModel.XmlSerializerFormatAttribute(Style = System.ServiceModel.OperationFormatStyle.Rpc, SupportFaults = true, Use = System.ServiceModel.OperationFormatUse.Encoded)]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(GVSelectionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportBlacklistRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormResultType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EmailAddressHistoryActionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FileType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkHitType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ProfileUpdateType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(SubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(UnsubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(BounceType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportEmailAddressRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CustomFieldType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EfficyEventType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(MailingListType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CategoryType))]
        FlexMail.Service.UpdateTemplateResponse UpdateTemplate(FlexMail.Service.UpdateTemplateRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "UpdateTemplate", ReplyAction = "*")]
        System.Threading.Tasks.Task<FlexMail.Service.UpdateTemplateResponse> UpdateTemplateAsync(FlexMail.Service.UpdateTemplateRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "DeleteTemplate", ReplyAction = "*")]
        [System.ServiceModel.XmlSerializerFormatAttribute(Style = System.ServiceModel.OperationFormatStyle.Rpc, SupportFaults = true, Use = System.ServiceModel.OperationFormatUse.Encoded)]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(GVSelectionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportBlacklistRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormResultType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EmailAddressHistoryActionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FileType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkHitType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ProfileUpdateType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(SubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(UnsubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(BounceType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportEmailAddressRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CustomFieldType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EfficyEventType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(MailingListType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CategoryType))]
        FlexMail.Service.DeleteTemplateResponse DeleteTemplate(FlexMail.Service.DeleteTemplateRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "DeleteTemplate", ReplyAction = "*")]
        System.Threading.Tasks.Task<FlexMail.Service.DeleteTemplateResponse> DeleteTemplateAsync(FlexMail.Service.DeleteTemplateRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "GetTemplates", ReplyAction = "*")]
        [System.ServiceModel.XmlSerializerFormatAttribute(Style = System.ServiceModel.OperationFormatStyle.Rpc, SupportFaults = true, Use = System.ServiceModel.OperationFormatUse.Encoded)]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(GVSelectionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportBlacklistRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormResultType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EmailAddressHistoryActionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FileType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkHitType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ProfileUpdateType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(SubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(UnsubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(BounceType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportEmailAddressRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CustomFieldType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EfficyEventType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(MailingListType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CategoryType))]
        FlexMail.Service.GetTemplatesResponse GetTemplates(FlexMail.Service.GetTemplatesRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "GetTemplates", ReplyAction = "*")]
        System.Threading.Tasks.Task<FlexMail.Service.GetTemplatesResponse> GetTemplatesAsync(FlexMail.Service.GetTemplatesRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "CreatePreference", ReplyAction = "*")]
        [System.ServiceModel.XmlSerializerFormatAttribute(Style = System.ServiceModel.OperationFormatStyle.Rpc, SupportFaults = true, Use = System.ServiceModel.OperationFormatUse.Encoded)]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(GVSelectionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportBlacklistRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormResultType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EmailAddressHistoryActionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FileType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkHitType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ProfileUpdateType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(SubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(UnsubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(BounceType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportEmailAddressRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CustomFieldType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EfficyEventType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(MailingListType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CategoryType))]
        FlexMail.Service.CreatePreferenceResponse CreatePreference(FlexMail.Service.CreatePreferenceRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "CreatePreference", ReplyAction = "*")]
        System.Threading.Tasks.Task<FlexMail.Service.CreatePreferenceResponse> CreatePreferenceAsync(FlexMail.Service.CreatePreferenceRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "UpdatePreference", ReplyAction = "*")]
        [System.ServiceModel.XmlSerializerFormatAttribute(Style = System.ServiceModel.OperationFormatStyle.Rpc, SupportFaults = true, Use = System.ServiceModel.OperationFormatUse.Encoded)]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(GVSelectionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportBlacklistRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormResultType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EmailAddressHistoryActionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FileType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkHitType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ProfileUpdateType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(SubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(UnsubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(BounceType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportEmailAddressRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CustomFieldType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EfficyEventType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(MailingListType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CategoryType))]
        FlexMail.Service.UpdatePreferenceResponse UpdatePreference(FlexMail.Service.UpdatePreferenceRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "UpdatePreference", ReplyAction = "*")]
        System.Threading.Tasks.Task<FlexMail.Service.UpdatePreferenceResponse> UpdatePreferenceAsync(FlexMail.Service.UpdatePreferenceRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "DeletePreference", ReplyAction = "*")]
        [System.ServiceModel.XmlSerializerFormatAttribute(Style = System.ServiceModel.OperationFormatStyle.Rpc, SupportFaults = true, Use = System.ServiceModel.OperationFormatUse.Encoded)]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(GVSelectionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportBlacklistRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormResultType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EmailAddressHistoryActionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FileType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkHitType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ProfileUpdateType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(SubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(UnsubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(BounceType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportEmailAddressRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CustomFieldType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EfficyEventType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(MailingListType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CategoryType))]
        FlexMail.Service.DeletePreferenceResponse DeletePreference(FlexMail.Service.DeletePreferenceRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "DeletePreference", ReplyAction = "*")]
        System.Threading.Tasks.Task<FlexMail.Service.DeletePreferenceResponse> DeletePreferenceAsync(FlexMail.Service.DeletePreferenceRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "GetPreferences", ReplyAction = "*")]
        [System.ServiceModel.XmlSerializerFormatAttribute(Style = System.ServiceModel.OperationFormatStyle.Rpc, SupportFaults = true, Use = System.ServiceModel.OperationFormatUse.Encoded)]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(GVSelectionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportBlacklistRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormResultType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EmailAddressHistoryActionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FileType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkHitType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ProfileUpdateType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(SubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(UnsubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(BounceType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportEmailAddressRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CustomFieldType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EfficyEventType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(MailingListType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CategoryType))]
        FlexMail.Service.GetPreferencesResponse GetPreferences(FlexMail.Service.GetPreferencesRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "GetPreferences", ReplyAction = "*")]
        System.Threading.Tasks.Task<FlexMail.Service.GetPreferencesResponse> GetPreferencesAsync(FlexMail.Service.GetPreferencesRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "CreateGroup", ReplyAction = "*")]
        [System.ServiceModel.XmlSerializerFormatAttribute(Style = System.ServiceModel.OperationFormatStyle.Rpc, SupportFaults = true, Use = System.ServiceModel.OperationFormatUse.Encoded)]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(GVSelectionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportBlacklistRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormResultType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EmailAddressHistoryActionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FileType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkHitType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ProfileUpdateType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(SubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(UnsubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(BounceType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportEmailAddressRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CustomFieldType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EfficyEventType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(MailingListType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CategoryType))]
        FlexMail.Service.CreateGroupResponse CreateGroup(FlexMail.Service.CreateGroupRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "CreateGroup", ReplyAction = "*")]
        System.Threading.Tasks.Task<FlexMail.Service.CreateGroupResponse> CreateGroupAsync(FlexMail.Service.CreateGroupRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "UpdateGroup", ReplyAction = "*")]
        [System.ServiceModel.XmlSerializerFormatAttribute(Style = System.ServiceModel.OperationFormatStyle.Rpc, SupportFaults = true, Use = System.ServiceModel.OperationFormatUse.Encoded)]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(GVSelectionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportBlacklistRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormResultType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EmailAddressHistoryActionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FileType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkHitType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ProfileUpdateType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(SubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(UnsubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(BounceType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportEmailAddressRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CustomFieldType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EfficyEventType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(MailingListType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CategoryType))]
        FlexMail.Service.UpdateGroupResponse UpdateGroup(FlexMail.Service.UpdateGroupRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "UpdateGroup", ReplyAction = "*")]
        System.Threading.Tasks.Task<FlexMail.Service.UpdateGroupResponse> UpdateGroupAsync(FlexMail.Service.UpdateGroupRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "DeleteGroup", ReplyAction = "*")]
        [System.ServiceModel.XmlSerializerFormatAttribute(Style = System.ServiceModel.OperationFormatStyle.Rpc, SupportFaults = true, Use = System.ServiceModel.OperationFormatUse.Encoded)]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(GVSelectionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportBlacklistRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormResultType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EmailAddressHistoryActionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FileType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkHitType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ProfileUpdateType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(SubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(UnsubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(BounceType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportEmailAddressRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CustomFieldType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EfficyEventType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(MailingListType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CategoryType))]
        FlexMail.Service.DeleteGroupResponse DeleteGroup(FlexMail.Service.DeleteGroupRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "DeleteGroup", ReplyAction = "*")]
        System.Threading.Tasks.Task<FlexMail.Service.DeleteGroupResponse> DeleteGroupAsync(FlexMail.Service.DeleteGroupRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "GetGroups", ReplyAction = "*")]
        [System.ServiceModel.XmlSerializerFormatAttribute(Style = System.ServiceModel.OperationFormatStyle.Rpc, SupportFaults = true, Use = System.ServiceModel.OperationFormatUse.Encoded)]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(GVSelectionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportBlacklistRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormResultType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EmailAddressHistoryActionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FileType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkHitType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ProfileUpdateType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(SubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(UnsubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(BounceType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportEmailAddressRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CustomFieldType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EfficyEventType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(MailingListType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CategoryType))]
        FlexMail.Service.GetGroupsResponse GetGroups(FlexMail.Service.GetGroupsRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "GetGroups", ReplyAction = "*")]
        System.Threading.Tasks.Task<FlexMail.Service.GetGroupsResponse> GetGroupsAsync(FlexMail.Service.GetGroupsRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "ImportGroupSubscriptions", ReplyAction = "*")]
        [System.ServiceModel.XmlSerializerFormatAttribute(Style = System.ServiceModel.OperationFormatStyle.Rpc, SupportFaults = true, Use = System.ServiceModel.OperationFormatUse.Encoded)]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(GVSelectionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportBlacklistRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormResultType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EmailAddressHistoryActionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FileType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkHitType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ProfileUpdateType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(SubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(UnsubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(BounceType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportEmailAddressRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CustomFieldType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EfficyEventType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(MailingListType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CategoryType))]
        FlexMail.Service.ImportGroupSubscriptionsResponse ImportGroupSubscriptions(FlexMail.Service.ImportGroupSubscriptionsRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "ImportGroupSubscriptions", ReplyAction = "*")]
        System.Threading.Tasks.Task<FlexMail.Service.ImportGroupSubscriptionsResponse> ImportGroupSubscriptionsAsync(FlexMail.Service.ImportGroupSubscriptionsRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "CreateGroupSubscription", ReplyAction = "*")]
        [System.ServiceModel.XmlSerializerFormatAttribute(Style = System.ServiceModel.OperationFormatStyle.Rpc, SupportFaults = true, Use = System.ServiceModel.OperationFormatUse.Encoded)]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(GVSelectionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportBlacklistRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormResultType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EmailAddressHistoryActionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FileType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkHitType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ProfileUpdateType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(SubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(UnsubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(BounceType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportEmailAddressRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CustomFieldType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EfficyEventType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(MailingListType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CategoryType))]
        FlexMail.Service.CreateGroupSubscriptionResponse CreateGroupSubscription(FlexMail.Service.CreateGroupSubscriptionRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "CreateGroupSubscription", ReplyAction = "*")]
        System.Threading.Tasks.Task<FlexMail.Service.CreateGroupSubscriptionResponse> CreateGroupSubscriptionAsync(FlexMail.Service.CreateGroupSubscriptionRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "DeleteGroupSubscription", ReplyAction = "*")]
        [System.ServiceModel.XmlSerializerFormatAttribute(Style = System.ServiceModel.OperationFormatStyle.Rpc, SupportFaults = true, Use = System.ServiceModel.OperationFormatUse.Encoded)]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(GVSelectionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportBlacklistRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormResultType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EmailAddressHistoryActionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FileType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkHitType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ProfileUpdateType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(SubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(UnsubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(BounceType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportEmailAddressRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CustomFieldType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EfficyEventType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(MailingListType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CategoryType))]
        FlexMail.Service.DeleteGroupSubscriptionResponse DeleteGroupSubscription(FlexMail.Service.DeleteGroupSubscriptionRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "DeleteGroupSubscription", ReplyAction = "*")]
        System.Threading.Tasks.Task<FlexMail.Service.DeleteGroupSubscriptionResponse> DeleteGroupSubscriptionAsync(FlexMail.Service.DeleteGroupSubscriptionRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "CreateCampaign", ReplyAction = "*")]
        [System.ServiceModel.XmlSerializerFormatAttribute(Style = System.ServiceModel.OperationFormatStyle.Rpc, SupportFaults = true, Use = System.ServiceModel.OperationFormatUse.Encoded)]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(GVSelectionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportBlacklistRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormResultType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EmailAddressHistoryActionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FileType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkHitType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ProfileUpdateType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(SubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(UnsubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(BounceType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportEmailAddressRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CustomFieldType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EfficyEventType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(MailingListType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CategoryType))]
        FlexMail.Service.CreateCampaignResponse CreateCampaign(FlexMail.Service.CreateCampaignRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "CreateCampaign", ReplyAction = "*")]
        System.Threading.Tasks.Task<FlexMail.Service.CreateCampaignResponse> CreateCampaignAsync(FlexMail.Service.CreateCampaignRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "UpdateCampaign", ReplyAction = "*")]
        [System.ServiceModel.XmlSerializerFormatAttribute(Style = System.ServiceModel.OperationFormatStyle.Rpc, SupportFaults = true, Use = System.ServiceModel.OperationFormatUse.Encoded)]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(GVSelectionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportBlacklistRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormResultType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EmailAddressHistoryActionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FileType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkHitType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ProfileUpdateType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(SubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(UnsubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(BounceType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportEmailAddressRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CustomFieldType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EfficyEventType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(MailingListType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CategoryType))]
        FlexMail.Service.UpdateCampaignResponse UpdateCampaign(FlexMail.Service.UpdateCampaignRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "UpdateCampaign", ReplyAction = "*")]
        System.Threading.Tasks.Task<FlexMail.Service.UpdateCampaignResponse> UpdateCampaignAsync(FlexMail.Service.UpdateCampaignRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "DeleteCampaign", ReplyAction = "*")]
        [System.ServiceModel.XmlSerializerFormatAttribute(Style = System.ServiceModel.OperationFormatStyle.Rpc, SupportFaults = true, Use = System.ServiceModel.OperationFormatUse.Encoded)]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(GVSelectionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportBlacklistRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormResultType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EmailAddressHistoryActionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FileType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkHitType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ProfileUpdateType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(SubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(UnsubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(BounceType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportEmailAddressRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CustomFieldType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EfficyEventType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(MailingListType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CategoryType))]
        FlexMail.Service.DeleteCampaignResponse DeleteCampaign(FlexMail.Service.DeleteCampaignRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "DeleteCampaign", ReplyAction = "*")]
        System.Threading.Tasks.Task<FlexMail.Service.DeleteCampaignResponse> DeleteCampaignAsync(FlexMail.Service.DeleteCampaignRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "GetCampaigns", ReplyAction = "*")]
        [System.ServiceModel.XmlSerializerFormatAttribute(Style = System.ServiceModel.OperationFormatStyle.Rpc, SupportFaults = true, Use = System.ServiceModel.OperationFormatUse.Encoded)]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(GVSelectionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportBlacklistRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormResultType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EmailAddressHistoryActionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FileType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkHitType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ProfileUpdateType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(SubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(UnsubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(BounceType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportEmailAddressRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CustomFieldType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EfficyEventType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(MailingListType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CategoryType))]
        FlexMail.Service.GetCampaignsResponse GetCampaigns(FlexMail.Service.GetCampaignsRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "GetCampaigns", ReplyAction = "*")]
        System.Threading.Tasks.Task<FlexMail.Service.GetCampaignsResponse> GetCampaignsAsync(FlexMail.Service.GetCampaignsRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "SendCampaign", ReplyAction = "*")]
        [System.ServiceModel.XmlSerializerFormatAttribute(Style = System.ServiceModel.OperationFormatStyle.Rpc, SupportFaults = true, Use = System.ServiceModel.OperationFormatUse.Encoded)]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(GVSelectionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportBlacklistRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormResultType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EmailAddressHistoryActionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FileType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkHitType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ProfileUpdateType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(SubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(UnsubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(BounceType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportEmailAddressRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CustomFieldType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EfficyEventType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(MailingListType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CategoryType))]
        FlexMail.Service.SendCampaignResponse SendCampaign(FlexMail.Service.SendCampaignRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "SendCampaign", ReplyAction = "*")]
        System.Threading.Tasks.Task<FlexMail.Service.SendCampaignResponse> SendCampaignAsync(FlexMail.Service.SendCampaignRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "SendTestCampaign", ReplyAction = "*")]
        [System.ServiceModel.XmlSerializerFormatAttribute(Style = System.ServiceModel.OperationFormatStyle.Rpc, SupportFaults = true, Use = System.ServiceModel.OperationFormatUse.Encoded)]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(GVSelectionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportBlacklistRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormResultType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EmailAddressHistoryActionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FileType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkHitType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ProfileUpdateType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(SubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(UnsubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(BounceType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportEmailAddressRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CustomFieldType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EfficyEventType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(MailingListType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CategoryType))]
        FlexMail.Service.SendTestCampaignResponse SendTestCampaign(FlexMail.Service.SendTestCampaignRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "SendTestCampaign", ReplyAction = "*")]
        System.Threading.Tasks.Task<FlexMail.Service.SendTestCampaignResponse> SendTestCampaignAsync(FlexMail.Service.SendTestCampaignRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "GetBounces", ReplyAction = "*")]
        [System.ServiceModel.XmlSerializerFormatAttribute(Style = System.ServiceModel.OperationFormatStyle.Rpc, SupportFaults = true, Use = System.ServiceModel.OperationFormatUse.Encoded)]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(GVSelectionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportBlacklistRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormResultType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EmailAddressHistoryActionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FileType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkHitType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ProfileUpdateType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(SubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(UnsubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(BounceType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportEmailAddressRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CustomFieldType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EfficyEventType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(MailingListType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CategoryType))]
        FlexMail.Service.GetBouncesResponse GetBounces(FlexMail.Service.GetBouncesRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "GetBounces", ReplyAction = "*")]
        System.Threading.Tasks.Task<FlexMail.Service.GetBouncesResponse> GetBouncesAsync(FlexMail.Service.GetBouncesRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "GetUnsubscriptions", ReplyAction = "*")]
        [System.ServiceModel.XmlSerializerFormatAttribute(Style = System.ServiceModel.OperationFormatStyle.Rpc, SupportFaults = true, Use = System.ServiceModel.OperationFormatUse.Encoded)]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(GVSelectionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportBlacklistRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormResultType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EmailAddressHistoryActionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FileType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkHitType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ProfileUpdateType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(SubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(UnsubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(BounceType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportEmailAddressRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CustomFieldType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EfficyEventType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(MailingListType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CategoryType))]
        FlexMail.Service.GetUnsubscriptionsResponse GetUnsubscriptions(FlexMail.Service.GetUnsubscriptionsRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "GetUnsubscriptions", ReplyAction = "*")]
        System.Threading.Tasks.Task<FlexMail.Service.GetUnsubscriptionsResponse> GetUnsubscriptionsAsync(FlexMail.Service.GetUnsubscriptionsRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "GetSubscriptions", ReplyAction = "*")]
        [System.ServiceModel.XmlSerializerFormatAttribute(Style = System.ServiceModel.OperationFormatStyle.Rpc, SupportFaults = true, Use = System.ServiceModel.OperationFormatUse.Encoded)]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(GVSelectionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportBlacklistRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormResultType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EmailAddressHistoryActionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FileType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkHitType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ProfileUpdateType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(SubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(UnsubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(BounceType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportEmailAddressRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CustomFieldType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EfficyEventType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(MailingListType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CategoryType))]
        FlexMail.Service.GetSubscriptionsResponse GetSubscriptions(FlexMail.Service.GetSubscriptionsRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "GetSubscriptions", ReplyAction = "*")]
        System.Threading.Tasks.Task<FlexMail.Service.GetSubscriptionsResponse> GetSubscriptionsAsync(FlexMail.Service.GetSubscriptionsRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "GetProfileUpdates", ReplyAction = "*")]
        [System.ServiceModel.XmlSerializerFormatAttribute(Style = System.ServiceModel.OperationFormatStyle.Rpc, SupportFaults = true, Use = System.ServiceModel.OperationFormatUse.Encoded)]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(GVSelectionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportBlacklistRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormResultType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EmailAddressHistoryActionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FileType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkHitType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ProfileUpdateType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(SubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(UnsubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(BounceType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportEmailAddressRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CustomFieldType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EfficyEventType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(MailingListType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CategoryType))]
        FlexMail.Service.GetProfileUpdatesResponse GetProfileUpdates(FlexMail.Service.GetProfileUpdatesRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "GetProfileUpdates", ReplyAction = "*")]
        System.Threading.Tasks.Task<FlexMail.Service.GetProfileUpdatesResponse> GetProfileUpdatesAsync(FlexMail.Service.GetProfileUpdatesRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "GetCampaignTrackingLinks", ReplyAction = "*")]
        [System.ServiceModel.XmlSerializerFormatAttribute(Style = System.ServiceModel.OperationFormatStyle.Rpc, SupportFaults = true, Use = System.ServiceModel.OperationFormatUse.Encoded)]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(GVSelectionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportBlacklistRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormResultType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EmailAddressHistoryActionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FileType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkHitType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ProfileUpdateType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(SubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(UnsubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(BounceType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportEmailAddressRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CustomFieldType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EfficyEventType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(MailingListType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CategoryType))]
        FlexMail.Service.GetCampaignTrackingLinksResponse GetCampaignTrackingLinks(FlexMail.Service.GetCampaignTrackingLinksRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "GetCampaignTrackingLinks", ReplyAction = "*")]
        System.Threading.Tasks.Task<FlexMail.Service.GetCampaignTrackingLinksResponse> GetCampaignTrackingLinksAsync(FlexMail.Service.GetCampaignTrackingLinksRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "GetTrackingLinkHits", ReplyAction = "*")]
        [System.ServiceModel.XmlSerializerFormatAttribute(Style = System.ServiceModel.OperationFormatStyle.Rpc, SupportFaults = true, Use = System.ServiceModel.OperationFormatUse.Encoded)]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(GVSelectionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportBlacklistRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormResultType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EmailAddressHistoryActionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FileType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkHitType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ProfileUpdateType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(SubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(UnsubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(BounceType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportEmailAddressRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CustomFieldType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EfficyEventType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(MailingListType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CategoryType))]
        FlexMail.Service.GetTrackingLinkHitsResponse GetTrackingLinkHits(FlexMail.Service.GetTrackingLinkHitsRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "GetTrackingLinkHits", ReplyAction = "*")]
        System.Threading.Tasks.Task<FlexMail.Service.GetTrackingLinkHitsResponse> GetTrackingLinkHitsAsync(FlexMail.Service.GetTrackingLinkHitsRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "GetCampaignReport", ReplyAction = "*")]
        [System.ServiceModel.XmlSerializerFormatAttribute(Style = System.ServiceModel.OperationFormatStyle.Rpc, SupportFaults = true, Use = System.ServiceModel.OperationFormatUse.Encoded)]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(GVSelectionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportBlacklistRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormResultType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EmailAddressHistoryActionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FileType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkHitType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ProfileUpdateType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(SubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(UnsubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(BounceType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportEmailAddressRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CustomFieldType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EfficyEventType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(MailingListType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CategoryType))]
        FlexMail.Service.GetCampaignReportResponse GetCampaignReport(FlexMail.Service.GetCampaignReportRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "GetCampaignReport", ReplyAction = "*")]
        System.Threading.Tasks.Task<FlexMail.Service.GetCampaignReportResponse> GetCampaignReportAsync(FlexMail.Service.GetCampaignReportRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "PutFiles", ReplyAction = "*")]
        [System.ServiceModel.XmlSerializerFormatAttribute(Style = System.ServiceModel.OperationFormatStyle.Rpc, SupportFaults = true, Use = System.ServiceModel.OperationFormatUse.Encoded)]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(GVSelectionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportBlacklistRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormResultType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EmailAddressHistoryActionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FileType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkHitType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ProfileUpdateType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(SubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(UnsubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(BounceType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportEmailAddressRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CustomFieldType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EfficyEventType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(MailingListType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CategoryType))]
        FlexMail.Service.PutFilesResponse PutFiles(FlexMail.Service.PutFilesRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "PutFiles", ReplyAction = "*")]
        System.Threading.Tasks.Task<FlexMail.Service.PutFilesResponse> PutFilesAsync(FlexMail.Service.PutFilesRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "CreateEfficyActivity", ReplyAction = "*")]
        [System.ServiceModel.XmlSerializerFormatAttribute(Style = System.ServiceModel.OperationFormatStyle.Rpc, SupportFaults = true, Use = System.ServiceModel.OperationFormatUse.Encoded)]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(GVSelectionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportBlacklistRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormResultType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EmailAddressHistoryActionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FileType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkHitType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ProfileUpdateType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(SubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(UnsubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(BounceType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportEmailAddressRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CustomFieldType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EfficyEventType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(MailingListType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CategoryType))]
        FlexMail.Service.CreateEfficyActivityResponse CreateEfficyActivity(FlexMail.Service.CreateEfficyActivityRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "CreateEfficyActivity", ReplyAction = "*")]
        System.Threading.Tasks.Task<FlexMail.Service.CreateEfficyActivityResponse> CreateEfficyActivityAsync(FlexMail.Service.CreateEfficyActivityRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "UpdateEfficyActivity", ReplyAction = "*")]
        [System.ServiceModel.XmlSerializerFormatAttribute(Style = System.ServiceModel.OperationFormatStyle.Rpc, SupportFaults = true, Use = System.ServiceModel.OperationFormatUse.Encoded)]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(GVSelectionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportBlacklistRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormResultType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EmailAddressHistoryActionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FileType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkHitType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ProfileUpdateType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(SubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(UnsubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(BounceType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportEmailAddressRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CustomFieldType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EfficyEventType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(MailingListType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CategoryType))]
        FlexMail.Service.UpdateEfficyActivityResponse UpdateEfficyActivity(FlexMail.Service.UpdateEfficyActivityRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "UpdateEfficyActivity", ReplyAction = "*")]
        System.Threading.Tasks.Task<FlexMail.Service.UpdateEfficyActivityResponse> UpdateEfficyActivityAsync(FlexMail.Service.UpdateEfficyActivityRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "DeleteEfficyActivity", ReplyAction = "*")]
        [System.ServiceModel.XmlSerializerFormatAttribute(Style = System.ServiceModel.OperationFormatStyle.Rpc, SupportFaults = true, Use = System.ServiceModel.OperationFormatUse.Encoded)]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(GVSelectionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportBlacklistRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormResultType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EmailAddressHistoryActionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FileType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkHitType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ProfileUpdateType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(SubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(UnsubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(BounceType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportEmailAddressRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CustomFieldType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EfficyEventType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(MailingListType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CategoryType))]
        FlexMail.Service.DeleteEfficyActivityResponse DeleteEfficyActivity(FlexMail.Service.DeleteEfficyActivityRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "DeleteEfficyActivity", ReplyAction = "*")]
        System.Threading.Tasks.Task<FlexMail.Service.DeleteEfficyActivityResponse> DeleteEfficyActivityAsync(FlexMail.Service.DeleteEfficyActivityRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "GetEfficyActivities", ReplyAction = "*")]
        [System.ServiceModel.XmlSerializerFormatAttribute(Style = System.ServiceModel.OperationFormatStyle.Rpc, SupportFaults = true, Use = System.ServiceModel.OperationFormatUse.Encoded)]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(GVSelectionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportBlacklistRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormResultType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EmailAddressHistoryActionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FileType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkHitType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ProfileUpdateType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(SubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(UnsubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(BounceType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportEmailAddressRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CustomFieldType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EfficyEventType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(MailingListType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CategoryType))]
        FlexMail.Service.GetEfficyActivitiesResponse GetEfficyActivities(FlexMail.Service.GetEfficyActivitiesRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "GetEfficyActivities", ReplyAction = "*")]
        System.Threading.Tasks.Task<FlexMail.Service.GetEfficyActivitiesResponse> GetEfficyActivitiesAsync(FlexMail.Service.GetEfficyActivitiesRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "GetEmailAddressHistory", ReplyAction = "*")]
        [System.ServiceModel.XmlSerializerFormatAttribute(Style = System.ServiceModel.OperationFormatStyle.Rpc, SupportFaults = true, Use = System.ServiceModel.OperationFormatUse.Encoded)]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(GVSelectionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportBlacklistRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormResultType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EmailAddressHistoryActionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FileType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkHitType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ProfileUpdateType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(SubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(UnsubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(BounceType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportEmailAddressRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CustomFieldType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EfficyEventType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(MailingListType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CategoryType))]
        FlexMail.Service.GetEmailAddressHistoryResponse GetEmailAddressHistory(FlexMail.Service.GetEmailAddressHistoryRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "GetEmailAddressHistory", ReplyAction = "*")]
        System.Threading.Tasks.Task<FlexMail.Service.GetEmailAddressHistoryResponse> GetEmailAddressHistoryAsync(FlexMail.Service.GetEmailAddressHistoryRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "GetCampaignHistory", ReplyAction = "*")]
        [System.ServiceModel.XmlSerializerFormatAttribute(Style = System.ServiceModel.OperationFormatStyle.Rpc, SupportFaults = true, Use = System.ServiceModel.OperationFormatUse.Encoded)]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(GVSelectionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportBlacklistRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormResultType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EmailAddressHistoryActionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FileType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkHitType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ProfileUpdateType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(SubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(UnsubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(BounceType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportEmailAddressRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CustomFieldType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EfficyEventType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(MailingListType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CategoryType))]
        FlexMail.Service.GetCampaignHistoryResponse GetCampaignHistory(FlexMail.Service.GetCampaignHistoryRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "GetCampaignHistory", ReplyAction = "*")]
        System.Threading.Tasks.Task<FlexMail.Service.GetCampaignHistoryResponse> GetCampaignHistoryAsync(FlexMail.Service.GetCampaignHistoryRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "GetHistory", ReplyAction = "*")]
        [System.ServiceModel.XmlSerializerFormatAttribute(Style = System.ServiceModel.OperationFormatStyle.Rpc, SupportFaults = true, Use = System.ServiceModel.OperationFormatUse.Encoded)]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(GVSelectionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportBlacklistRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormResultType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EmailAddressHistoryActionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FileType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkHitType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ProfileUpdateType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(SubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(UnsubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(BounceType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportEmailAddressRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CustomFieldType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EfficyEventType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(MailingListType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CategoryType))]
        FlexMail.Service.GetHistoryResponse GetHistory(FlexMail.Service.GetHistoryRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "GetHistory", ReplyAction = "*")]
        System.Threading.Tasks.Task<FlexMail.Service.GetHistoryResponse> GetHistoryAsync(FlexMail.Service.GetHistoryRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "GetFormResults", ReplyAction = "*")]
        [System.ServiceModel.XmlSerializerFormatAttribute(Style = System.ServiceModel.OperationFormatStyle.Rpc, SupportFaults = true, Use = System.ServiceModel.OperationFormatUse.Encoded)]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(GVSelectionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportBlacklistRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormResultType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EmailAddressHistoryActionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FileType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkHitType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ProfileUpdateType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(SubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(UnsubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(BounceType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportEmailAddressRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CustomFieldType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EfficyEventType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(MailingListType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CategoryType))]
        FlexMail.Service.GetFormResultsResponse GetFormResults(FlexMail.Service.GetFormResultsRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "GetFormResults", ReplyAction = "*")]
        System.Threading.Tasks.Task<FlexMail.Service.GetFormResultsResponse> GetFormResultsAsync(FlexMail.Service.GetFormResultsRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "GetForms", ReplyAction = "*")]
        [System.ServiceModel.XmlSerializerFormatAttribute(Style = System.ServiceModel.OperationFormatStyle.Rpc, SupportFaults = true, Use = System.ServiceModel.OperationFormatUse.Encoded)]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(GVSelectionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportBlacklistRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormResultType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EmailAddressHistoryActionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FileType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkHitType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ProfileUpdateType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(SubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(UnsubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(BounceType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportEmailAddressRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CustomFieldType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EfficyEventType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(MailingListType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CategoryType))]
        FlexMail.Service.GetFormsResponse GetForms(FlexMail.Service.GetFormsRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "GetForms", ReplyAction = "*")]
        System.Threading.Tasks.Task<FlexMail.Service.GetFormsResponse> GetFormsAsync(FlexMail.Service.GetFormsRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "GetBalance", ReplyAction = "*")]
        [System.ServiceModel.XmlSerializerFormatAttribute(Style = System.ServiceModel.OperationFormatStyle.Rpc, SupportFaults = true, Use = System.ServiceModel.OperationFormatUse.Encoded)]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(GVSelectionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportBlacklistRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormResultType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EmailAddressHistoryActionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FileType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkHitType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ProfileUpdateType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(SubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(UnsubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(BounceType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportEmailAddressRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CustomFieldType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EfficyEventType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(MailingListType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CategoryType))]
        FlexMail.Service.GetBalanceResponse GetBalance(FlexMail.Service.GetBalanceRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "GetBalance", ReplyAction = "*")]
        System.Threading.Tasks.Task<FlexMail.Service.GetBalanceResponse> GetBalanceAsync(FlexMail.Service.GetBalanceRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "GetCampaignSummary", ReplyAction = "*")]
        [System.ServiceModel.XmlSerializerFormatAttribute(Style = System.ServiceModel.OperationFormatStyle.Rpc, SupportFaults = true, Use = System.ServiceModel.OperationFormatUse.Encoded)]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(GVSelectionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportBlacklistRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormResultType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EmailAddressHistoryActionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FileType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkHitType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ProfileUpdateType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(SubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(UnsubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(BounceType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportEmailAddressRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CustomFieldType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EfficyEventType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(MailingListType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CategoryType))]
        FlexMail.Service.GetCampaignSummaryResponse GetCampaignSummary(FlexMail.Service.GetCampaignSummaryRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "GetCampaignSummary", ReplyAction = "*")]
        System.Threading.Tasks.Task<FlexMail.Service.GetCampaignSummaryResponse> GetCampaignSummaryAsync(FlexMail.Service.GetCampaignSummaryRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "ImportBlacklist", ReplyAction = "*")]
        [System.ServiceModel.XmlSerializerFormatAttribute(Style = System.ServiceModel.OperationFormatStyle.Rpc, SupportFaults = true, Use = System.ServiceModel.OperationFormatUse.Encoded)]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(GVSelectionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportBlacklistRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormResultType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EmailAddressHistoryActionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FileType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkHitType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ProfileUpdateType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(SubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(UnsubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(BounceType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportEmailAddressRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CustomFieldType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EfficyEventType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(MailingListType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CategoryType))]
        FlexMail.Service.ImportBlacklistResponse ImportBlacklist(FlexMail.Service.ImportBlacklistRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "ImportBlacklist", ReplyAction = "*")]
        System.Threading.Tasks.Task<FlexMail.Service.ImportBlacklistResponse> ImportBlacklistAsync(FlexMail.Service.ImportBlacklistRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "CreateAccount", ReplyAction = "*")]
        [System.ServiceModel.XmlSerializerFormatAttribute(Style = System.ServiceModel.OperationFormatStyle.Rpc, SupportFaults = true, Use = System.ServiceModel.OperationFormatUse.Encoded)]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(GVSelectionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportBlacklistRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormResultType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EmailAddressHistoryActionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FileType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkHitType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ProfileUpdateType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(SubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(UnsubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(BounceType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportEmailAddressRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CustomFieldType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EfficyEventType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(MailingListType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CategoryType))]
        FlexMail.Service.CreateAccountResponse CreateAccount(FlexMail.Service.CreateAccountRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "CreateAccount", ReplyAction = "*")]
        System.Threading.Tasks.Task<FlexMail.Service.CreateAccountResponse> CreateAccountAsync(FlexMail.Service.CreateAccountRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "UpdateAccount", ReplyAction = "*")]
        [System.ServiceModel.XmlSerializerFormatAttribute(Style = System.ServiceModel.OperationFormatStyle.Rpc, SupportFaults = true, Use = System.ServiceModel.OperationFormatUse.Encoded)]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(GVSelectionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportBlacklistRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormResultType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EmailAddressHistoryActionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FileType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkHitType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ProfileUpdateType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(SubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(UnsubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(BounceType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportEmailAddressRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CustomFieldType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EfficyEventType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(MailingListType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CategoryType))]
        FlexMail.Service.UpdateAccountResponse UpdateAccount(FlexMail.Service.UpdateAccountRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "UpdateAccount", ReplyAction = "*")]
        System.Threading.Tasks.Task<FlexMail.Service.UpdateAccountResponse> UpdateAccountAsync(FlexMail.Service.UpdateAccountRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "DeleteAccount", ReplyAction = "*")]
        [System.ServiceModel.XmlSerializerFormatAttribute(Style = System.ServiceModel.OperationFormatStyle.Rpc, SupportFaults = true, Use = System.ServiceModel.OperationFormatUse.Encoded)]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(GVSelectionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportBlacklistRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormResultType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EmailAddressHistoryActionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FileType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkHitType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ProfileUpdateType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(SubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(UnsubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(BounceType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportEmailAddressRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CustomFieldType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EfficyEventType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(MailingListType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CategoryType))]
        FlexMail.Service.DeleteAccountResponse DeleteAccount(FlexMail.Service.DeleteAccountRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "DeleteAccount", ReplyAction = "*")]
        System.Threading.Tasks.Task<FlexMail.Service.DeleteAccountResponse> DeleteAccountAsync(FlexMail.Service.DeleteAccountRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "GetAccounts", ReplyAction = "*")]
        [System.ServiceModel.XmlSerializerFormatAttribute(Style = System.ServiceModel.OperationFormatStyle.Rpc, SupportFaults = true, Use = System.ServiceModel.OperationFormatUse.Encoded)]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(GVSelectionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportBlacklistRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormResultType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EmailAddressHistoryActionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FileType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkHitType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ProfileUpdateType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(SubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(UnsubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(BounceType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportEmailAddressRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CustomFieldType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EfficyEventType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(MailingListType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CategoryType))]
        FlexMail.Service.GetAccountsResponse GetAccounts(FlexMail.Service.GetAccountsRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "GetAccounts", ReplyAction = "*")]
        System.Threading.Tasks.Task<FlexMail.Service.GetAccountsResponse> GetAccountsAsync(FlexMail.Service.GetAccountsRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "AccountAddCredits", ReplyAction = "*")]
        [System.ServiceModel.XmlSerializerFormatAttribute(Style = System.ServiceModel.OperationFormatStyle.Rpc, SupportFaults = true, Use = System.ServiceModel.OperationFormatUse.Encoded)]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(GVSelectionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportBlacklistRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormResultType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EmailAddressHistoryActionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FileType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkHitType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ProfileUpdateType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(SubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(UnsubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(BounceType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportEmailAddressRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CustomFieldType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EfficyEventType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(MailingListType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CategoryType))]
        FlexMail.Service.AccountAddCreditsResponse AccountAddCredits(FlexMail.Service.AccountAddCreditsRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "AccountAddCredits", ReplyAction = "*")]
        System.Threading.Tasks.Task<FlexMail.Service.AccountAddCreditsResponse> AccountAddCreditsAsync(FlexMail.Service.AccountAddCreditsRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "AccountRevokeCredits", ReplyAction = "*")]
        [System.ServiceModel.XmlSerializerFormatAttribute(Style = System.ServiceModel.OperationFormatStyle.Rpc, SupportFaults = true, Use = System.ServiceModel.OperationFormatUse.Encoded)]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(GVSelectionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportBlacklistRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormResultType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EmailAddressHistoryActionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FileType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkHitType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ProfileUpdateType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(SubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(UnsubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(BounceType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportEmailAddressRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CustomFieldType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EfficyEventType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(MailingListType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CategoryType))]
        FlexMail.Service.AccountRevokeCreditsResponse AccountRevokeCredits(FlexMail.Service.AccountRevokeCreditsRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "AccountRevokeCredits", ReplyAction = "*")]
        System.Threading.Tasks.Task<FlexMail.Service.AccountRevokeCreditsResponse> AccountRevokeCreditsAsync(FlexMail.Service.AccountRevokeCreditsRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "GetCustomReport", ReplyAction = "*")]
        [System.ServiceModel.XmlSerializerFormatAttribute(Style = System.ServiceModel.OperationFormatStyle.Rpc, SupportFaults = true, Use = System.ServiceModel.OperationFormatUse.Encoded)]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(GVSelectionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportBlacklistRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormResultType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EmailAddressHistoryActionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FileType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkHitType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ProfileUpdateType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(SubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(UnsubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(BounceType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportEmailAddressRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CustomFieldType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EfficyEventType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(MailingListType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CategoryType))]
        FlexMail.Service.GetCustomReportResponse GetCustomReport(FlexMail.Service.GetCustomReportRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "GetCustomReport", ReplyAction = "*")]
        System.Threading.Tasks.Task<FlexMail.Service.GetCustomReportResponse> GetCustomReportAsync(FlexMail.Service.GetCustomReportRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "RegisterTransactionEnd", ReplyAction = "*")]
        [System.ServiceModel.XmlSerializerFormatAttribute(Style = System.ServiceModel.OperationFormatStyle.Rpc, SupportFaults = true, Use = System.ServiceModel.OperationFormatUse.Encoded)]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(GVSelectionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportBlacklistRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormResultType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EmailAddressHistoryActionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FileType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkHitType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ProfileUpdateType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(SubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(UnsubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(BounceType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportEmailAddressRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CustomFieldType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EfficyEventType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(MailingListType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CategoryType))]
        FlexMail.Service.RegisterTransactionEndResponse RegisterTransactionEnd(FlexMail.Service.RegisterTransactionEndRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "RegisterTransactionEnd", ReplyAction = "*")]
        System.Threading.Tasks.Task<FlexMail.Service.RegisterTransactionEndResponse> RegisterTransactionEndAsync(FlexMail.Service.RegisterTransactionEndRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "UpdateTruvoOrder", ReplyAction = "*")]
        [System.ServiceModel.XmlSerializerFormatAttribute(Style = System.ServiceModel.OperationFormatStyle.Rpc, SupportFaults = true, Use = System.ServiceModel.OperationFormatUse.Encoded)]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(GVSelectionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportBlacklistRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormResultType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EmailAddressHistoryActionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FileType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkHitType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ProfileUpdateType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(SubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(UnsubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(BounceType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportEmailAddressRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CustomFieldType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EfficyEventType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(MailingListType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CategoryType))]
        FlexMail.Service.UpdateTruvoOrderResponse UpdateTruvoOrder(FlexMail.Service.UpdateTruvoOrderRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "UpdateTruvoOrder", ReplyAction = "*")]
        System.Threading.Tasks.Task<FlexMail.Service.UpdateTruvoOrderResponse> UpdateTruvoOrderAsync(FlexMail.Service.UpdateTruvoOrderRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "GVImportSelection", ReplyAction = "*")]
        [System.ServiceModel.XmlSerializerFormatAttribute(Style = System.ServiceModel.OperationFormatStyle.Rpc, SupportFaults = true, Use = System.ServiceModel.OperationFormatUse.Encoded)]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(GVSelectionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportBlacklistRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FormResultType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EmailAddressHistoryActionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(FileType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkHitType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(TrackingLinkType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ProfileUpdateType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(SubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(UnsubscriptionType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(BounceType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(ImportEmailAddressRespType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CustomFieldType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(EfficyEventType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(MailingListType))]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(CategoryType))]
        FlexMail.Service.GVImportSelectionResponse GVImportSelection(FlexMail.Service.GVImportSelectionRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "GVImportSelection", ReplyAction = "*")]
        System.Threading.Tasks.Task<FlexMail.Service.GVImportSelectionResponse> GVImportSelectionAsync(FlexMail.Service.GVImportSelectionRequest request);
    }

    /// <summary>
    /// 
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class CreateCategoryReq : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIRequestHeader headerField;

        private string categoryNameField;

        /// <remarks/>
        public APIRequestHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public string categoryName
        {
            get
            {
                return this.categoryNameField;
            }
            set
            {
                this.categoryNameField = value;
                this.RaisePropertyChanged("categoryName");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <summary>
    /// 
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class APIRequestHeader : object, System.ComponentModel.INotifyPropertyChanged
    {

        private int userIdField;

        private string userTokenField;

        /// <remarks/>
        public int userId
        {
            get
            {
                return this.userIdField;
            }
            set
            {
                this.userIdField = value;
                this.RaisePropertyChanged("userId");
            }
        }

        /// <remarks/>
        public string userToken
        {
            get
            {
                return this.userTokenField;
            }
            set
            {
                this.userTokenField = value;
                this.RaisePropertyChanged("userToken");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <summary>
    /// 
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class GVImportSelectionResp : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIResponseHeader headerField;

        private int errorCodeField;

        private string errorMessageField;

        /// <remarks/>
        public APIResponseHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public int errorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
                this.RaisePropertyChanged("errorCode");
            }
        }

        /// <remarks/>
        public string errorMessage
        {
            get
            {
                return this.errorMessageField;
            }
            set
            {
                this.errorMessageField = value;
                this.RaisePropertyChanged("errorMessage");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <summary>
    /// 
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class APIResponseHeader : object, System.ComponentModel.INotifyPropertyChanged
    {

        private int errorCodeField;

        private string errorMessageField;

        private string timestampField;

        /// <remarks/>
        public int errorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
                this.RaisePropertyChanged("errorCode");
            }
        }

        /// <remarks/>
        public string errorMessage
        {
            get
            {
                return this.errorMessageField;
            }
            set
            {
                this.errorMessageField = value;
                this.RaisePropertyChanged("errorMessage");
            }
        }

        /// <remarks/>
        public string timestamp
        {
            get
            {
                return this.timestampField;
            }
            set
            {
                this.timestampField = value;
                this.RaisePropertyChanged("timestamp");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <summary>
    /// 
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class GVSelectionType : object, System.ComponentModel.INotifyPropertyChanged
    {

        private string mailingListNameField;

        private string contactKeyField;

        /// <remarks/>
        public string mailingListName
        {
            get
            {
                return this.mailingListNameField;
            }
            set
            {
                this.mailingListNameField = value;
                this.RaisePropertyChanged("mailingListName");
            }
        }

        /// <remarks/>
        public string contactKey
        {
            get
            {
                return this.contactKeyField;
            }
            set
            {
                this.contactKeyField = value;
                this.RaisePropertyChanged("contactKey");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <summary>
    /// 
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class GVImportSelectionReq : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIRequestHeader headerField;

        private GVSelectionType[] selectionField;

        /// <remarks/>
        public APIRequestHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public GVSelectionType[] selection
        {
            get
            {
                return this.selectionField;
            }
            set
            {
                this.selectionField = value;
                this.RaisePropertyChanged("selection");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <summary>
    /// 
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class UpdateTruvoOrderResp : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIResponseHeader headerField;

        private int errorCodeField;

        private string errorMessageField;

        /// <remarks/>
        public APIResponseHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public int errorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
                this.RaisePropertyChanged("errorCode");
            }
        }

        /// <remarks/>
        public string errorMessage
        {
            get
            {
                return this.errorMessageField;
            }
            set
            {
                this.errorMessageField = value;
                this.RaisePropertyChanged("errorMessage");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <summary>
    /// 
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class UpdateTruvoOrderReq : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIRequestHeader headerField;

        private int orderIdField;

        /// <remarks/>
        public APIRequestHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public int orderId
        {
            get
            {
                return this.orderIdField;
            }
            set
            {
                this.orderIdField = value;
                this.RaisePropertyChanged("orderId");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <summary>
    /// 
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class RegisterTransactionEndResp : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIResponseHeader headerField;

        private int errorCodeField;

        private string errorMessageField;

        /// <remarks/>
        public APIResponseHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public int errorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
                this.RaisePropertyChanged("errorCode");
            }
        }

        /// <remarks/>
        public string errorMessage
        {
            get
            {
                return this.errorMessageField;
            }
            set
            {
                this.errorMessageField = value;
                this.RaisePropertyChanged("errorMessage");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <summary>
    /// 
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class RegisterTransactionEndReq : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIRequestHeader headerField;

        private string transactionIdField;

        /// <remarks/>
        public APIRequestHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public string transactionId
        {
            get
            {
                return this.transactionIdField;
            }
            set
            {
                this.transactionIdField = value;
                this.RaisePropertyChanged("transactionId");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <summary>
    /// 
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class GetCustomReportResp : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIResponseHeader headerField;

        private int errorCodeField;

        private string errorMessageField;

        private string resultField;

        /// <remarks/>
        public APIResponseHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public int errorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
                this.RaisePropertyChanged("errorCode");
            }
        }

        /// <remarks/>
        public string errorMessage
        {
            get
            {
                return this.errorMessageField;
            }
            set
            {
                this.errorMessageField = value;
                this.RaisePropertyChanged("errorMessage");
            }
        }

        /// <remarks/>
        public string result
        {
            get
            {
                return this.resultField;
            }
            set
            {
                this.resultField = value;
                this.RaisePropertyChanged("result");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <summary>
    /// 
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class GetCustomReportReq : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIRequestHeader headerField;

        private int reportIdField;

        /// <remarks/>
        public APIRequestHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public int reportId
        {
            get
            {
                return this.reportIdField;
            }
            set
            {
                this.reportIdField = value;
                this.RaisePropertyChanged("reportId");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class AccountRevokeCreditsResp : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIResponseHeader headerField;

        private int errorCodeField;

        private string errorMessageField;

        /// <remarks/>
        public APIResponseHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public int errorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
                this.RaisePropertyChanged("errorCode");
            }
        }

        /// <remarks/>
        public string errorMessage
        {
            get
            {
                return this.errorMessageField;
            }
            set
            {
                this.errorMessageField = value;
                this.RaisePropertyChanged("errorMessage");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class AccountRevokeCreditsReq : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIRequestHeader headerField;

        private AccountType accountTypeField;

        private CreditsType typeField;

        private int amountField;

        /// <remarks/>
        public APIRequestHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public AccountType accountType
        {
            get
            {
                return this.accountTypeField;
            }
            set
            {
                this.accountTypeField = value;
                this.RaisePropertyChanged("accountType");
            }
        }

        /// <remarks/>
        public CreditsType type
        {
            get
            {
                return this.typeField;
            }
            set
            {
                this.typeField = value;
                this.RaisePropertyChanged("type");
            }
        }

        /// <remarks/>
        public int amount
        {
            get
            {
                return this.amountField;
            }
            set
            {
                this.amountField = value;
                this.RaisePropertyChanged("amount");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class AccountType : object, System.ComponentModel.INotifyPropertyChanged
    {

        private string userIdField;

        private string userTokenField;

        private string typeField;

        private string usernameField;

        private string passwordField;

        private int creditsField;

        private bool creditsFieldSpecified;

        private int previewCreditsField;

        private bool previewCreditsFieldSpecified;

        private int truvoDataCreditsField;

        private bool truvoDataCreditsFieldSpecified;

        private string truvoAppTokenField;

        private string companyField;

        private string nameField;

        private string surnameField;

        private string emailAddressField;

        private string websiteField;

        private string addressField;

        private string zipCityField;

        private string phoneField;

        private string faxField;

        private string mobileField;

        private string languageField;

        private string countryCodeField;

        private string defaultCampaignSenderFromNameField;

        private string defaultCampaignSenderEmailAddressField;

        private string defaultCampaignReplyEmailAddressField;

        private bool allowProfileField;

        private bool allowProfileFieldSpecified;

        private bool allowSettingsField;

        private bool allowSettingsFieldSpecified;

        private bool allowContactsField;

        private bool allowContactsFieldSpecified;

        private bool allowMessagesField;

        private bool allowMessagesFieldSpecified;

        private bool allowCampaignsField;

        private bool allowCampaignsFieldSpecified;

        private bool allowReportsField;

        private bool allowReportsFieldSpecified;

        /// <remarks/>
        public string userId
        {
            get
            {
                return this.userIdField;
            }
            set
            {
                this.userIdField = value;
                this.RaisePropertyChanged("userId");
            }
        }

        /// <remarks/>
        public string userToken
        {
            get
            {
                return this.userTokenField;
            }
            set
            {
                this.userTokenField = value;
                this.RaisePropertyChanged("userToken");
            }
        }

        /// <remarks/>
        public string type
        {
            get
            {
                return this.typeField;
            }
            set
            {
                this.typeField = value;
                this.RaisePropertyChanged("type");
            }
        }

        /// <remarks/>
        public string username
        {
            get
            {
                return this.usernameField;
            }
            set
            {
                this.usernameField = value;
                this.RaisePropertyChanged("username");
            }
        }

        /// <remarks/>
        public string password
        {
            get
            {
                return this.passwordField;
            }
            set
            {
                this.passwordField = value;
                this.RaisePropertyChanged("password");
            }
        }

        /// <remarks/>
        public int credits
        {
            get
            {
                return this.creditsField;
            }
            set
            {
                this.creditsField = value;
                this.RaisePropertyChanged("credits");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool creditsSpecified
        {
            get
            {
                return this.creditsFieldSpecified;
            }
            set
            {
                this.creditsFieldSpecified = value;
                this.RaisePropertyChanged("creditsSpecified");
            }
        }

        /// <remarks/>
        public int previewCredits
        {
            get
            {
                return this.previewCreditsField;
            }
            set
            {
                this.previewCreditsField = value;
                this.RaisePropertyChanged("previewCredits");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool previewCreditsSpecified
        {
            get
            {
                return this.previewCreditsFieldSpecified;
            }
            set
            {
                this.previewCreditsFieldSpecified = value;
                this.RaisePropertyChanged("previewCreditsSpecified");
            }
        }

        /// <remarks/>
        public int truvoDataCredits
        {
            get
            {
                return this.truvoDataCreditsField;
            }
            set
            {
                this.truvoDataCreditsField = value;
                this.RaisePropertyChanged("truvoDataCredits");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool truvoDataCreditsSpecified
        {
            get
            {
                return this.truvoDataCreditsFieldSpecified;
            }
            set
            {
                this.truvoDataCreditsFieldSpecified = value;
                this.RaisePropertyChanged("truvoDataCreditsSpecified");
            }
        }

        /// <remarks/>
        public string truvoAppToken
        {
            get
            {
                return this.truvoAppTokenField;
            }
            set
            {
                this.truvoAppTokenField = value;
                this.RaisePropertyChanged("truvoAppToken");
            }
        }

        /// <remarks/>
        public string company
        {
            get
            {
                return this.companyField;
            }
            set
            {
                this.companyField = value;
                this.RaisePropertyChanged("company");
            }
        }

        /// <remarks/>
        public string name
        {
            get
            {
                return this.nameField;
            }
            set
            {
                this.nameField = value;
                this.RaisePropertyChanged("name");
            }
        }

        /// <remarks/>
        public string surname
        {
            get
            {
                return this.surnameField;
            }
            set
            {
                this.surnameField = value;
                this.RaisePropertyChanged("surname");
            }
        }

        /// <remarks/>
        public string emailAddress
        {
            get
            {
                return this.emailAddressField;
            }
            set
            {
                this.emailAddressField = value;
                this.RaisePropertyChanged("emailAddress");
            }
        }

        /// <remarks/>
        public string website
        {
            get
            {
                return this.websiteField;
            }
            set
            {
                this.websiteField = value;
                this.RaisePropertyChanged("website");
            }
        }

        /// <remarks/>
        public string address
        {
            get
            {
                return this.addressField;
            }
            set
            {
                this.addressField = value;
                this.RaisePropertyChanged("address");
            }
        }

        /// <remarks/>
        public string zipCity
        {
            get
            {
                return this.zipCityField;
            }
            set
            {
                this.zipCityField = value;
                this.RaisePropertyChanged("zipCity");
            }
        }

        /// <remarks/>
        public string phone
        {
            get
            {
                return this.phoneField;
            }
            set
            {
                this.phoneField = value;
                this.RaisePropertyChanged("phone");
            }
        }

        /// <remarks/>
        public string fax
        {
            get
            {
                return this.faxField;
            }
            set
            {
                this.faxField = value;
                this.RaisePropertyChanged("fax");
            }
        }

        /// <remarks/>
        public string mobile
        {
            get
            {
                return this.mobileField;
            }
            set
            {
                this.mobileField = value;
                this.RaisePropertyChanged("mobile");
            }
        }

        /// <remarks/>
        public string language
        {
            get
            {
                return this.languageField;
            }
            set
            {
                this.languageField = value;
                this.RaisePropertyChanged("language");
            }
        }

        /// <remarks/>
        public string countryCode
        {
            get
            {
                return this.countryCodeField;
            }
            set
            {
                this.countryCodeField = value;
                this.RaisePropertyChanged("countryCode");
            }
        }

        /// <remarks/>
        public string defaultCampaignSenderFromName
        {
            get
            {
                return this.defaultCampaignSenderFromNameField;
            }
            set
            {
                this.defaultCampaignSenderFromNameField = value;
                this.RaisePropertyChanged("defaultCampaignSenderFromName");
            }
        }

        /// <remarks/>
        public string defaultCampaignSenderEmailAddress
        {
            get
            {
                return this.defaultCampaignSenderEmailAddressField;
            }
            set
            {
                this.defaultCampaignSenderEmailAddressField = value;
                this.RaisePropertyChanged("defaultCampaignSenderEmailAddress");
            }
        }

        /// <remarks/>
        public string defaultCampaignReplyEmailAddress
        {
            get
            {
                return this.defaultCampaignReplyEmailAddressField;
            }
            set
            {
                this.defaultCampaignReplyEmailAddressField = value;
                this.RaisePropertyChanged("defaultCampaignReplyEmailAddress");
            }
        }

        /// <remarks/>
        public bool allowProfile
        {
            get
            {
                return this.allowProfileField;
            }
            set
            {
                this.allowProfileField = value;
                this.RaisePropertyChanged("allowProfile");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool allowProfileSpecified
        {
            get
            {
                return this.allowProfileFieldSpecified;
            }
            set
            {
                this.allowProfileFieldSpecified = value;
                this.RaisePropertyChanged("allowProfileSpecified");
            }
        }

        /// <remarks/>
        public bool allowSettings
        {
            get
            {
                return this.allowSettingsField;
            }
            set
            {
                this.allowSettingsField = value;
                this.RaisePropertyChanged("allowSettings");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool allowSettingsSpecified
        {
            get
            {
                return this.allowSettingsFieldSpecified;
            }
            set
            {
                this.allowSettingsFieldSpecified = value;
                this.RaisePropertyChanged("allowSettingsSpecified");
            }
        }

        /// <remarks/>
        public bool allowContacts
        {
            get
            {
                return this.allowContactsField;
            }
            set
            {
                this.allowContactsField = value;
                this.RaisePropertyChanged("allowContacts");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool allowContactsSpecified
        {
            get
            {
                return this.allowContactsFieldSpecified;
            }
            set
            {
                this.allowContactsFieldSpecified = value;
                this.RaisePropertyChanged("allowContactsSpecified");
            }
        }

        /// <remarks/>
        public bool allowMessages
        {
            get
            {
                return this.allowMessagesField;
            }
            set
            {
                this.allowMessagesField = value;
                this.RaisePropertyChanged("allowMessages");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool allowMessagesSpecified
        {
            get
            {
                return this.allowMessagesFieldSpecified;
            }
            set
            {
                this.allowMessagesFieldSpecified = value;
                this.RaisePropertyChanged("allowMessagesSpecified");
            }
        }

        /// <remarks/>
        public bool allowCampaigns
        {
            get
            {
                return this.allowCampaignsField;
            }
            set
            {
                this.allowCampaignsField = value;
                this.RaisePropertyChanged("allowCampaigns");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool allowCampaignsSpecified
        {
            get
            {
                return this.allowCampaignsFieldSpecified;
            }
            set
            {
                this.allowCampaignsFieldSpecified = value;
                this.RaisePropertyChanged("allowCampaignsSpecified");
            }
        }

        /// <remarks/>
        public bool allowReports
        {
            get
            {
                return this.allowReportsField;
            }
            set
            {
                this.allowReportsField = value;
                this.RaisePropertyChanged("allowReports");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool allowReportsSpecified
        {
            get
            {
                return this.allowReportsFieldSpecified;
            }
            set
            {
                this.allowReportsFieldSpecified = value;
                this.RaisePropertyChanged("allowReportsSpecified");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public enum CreditsType
    {

        /// <remarks/>
        email,

        /// <remarks/>
        preview,

        /// <remarks/>
        truvoData,
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class AccountAddCreditsResp : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIResponseHeader headerField;

        private int errorCodeField;

        private string errorMessageField;

        /// <remarks/>
        public APIResponseHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public int errorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
                this.RaisePropertyChanged("errorCode");
            }
        }

        /// <remarks/>
        public string errorMessage
        {
            get
            {
                return this.errorMessageField;
            }
            set
            {
                this.errorMessageField = value;
                this.RaisePropertyChanged("errorMessage");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class AccountAddCreditsReq : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIRequestHeader headerField;

        private AccountType accountTypeField;

        private CreditsType typeField;

        private int amountField;

        /// <remarks/>
        public APIRequestHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public AccountType accountType
        {
            get
            {
                return this.accountTypeField;
            }
            set
            {
                this.accountTypeField = value;
                this.RaisePropertyChanged("accountType");
            }
        }

        /// <remarks/>
        public CreditsType type
        {
            get
            {
                return this.typeField;
            }
            set
            {
                this.typeField = value;
                this.RaisePropertyChanged("type");
            }
        }

        /// <remarks/>
        public int amount
        {
            get
            {
                return this.amountField;
            }
            set
            {
                this.amountField = value;
                this.RaisePropertyChanged("amount");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class GetAccountsResp : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIResponseHeader headerField;

        private int errorCodeField;

        private bool errorCodeFieldSpecified;

        private string errorMessageField;

        private AccountType[] accountTypeItemsField;

        /// <remarks/>
        public APIResponseHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public int errorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
                this.RaisePropertyChanged("errorCode");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool errorCodeSpecified
        {
            get
            {
                return this.errorCodeFieldSpecified;
            }
            set
            {
                this.errorCodeFieldSpecified = value;
                this.RaisePropertyChanged("errorCodeSpecified");
            }
        }

        /// <remarks/>
        public string errorMessage
        {
            get
            {
                return this.errorMessageField;
            }
            set
            {
                this.errorMessageField = value;
                this.RaisePropertyChanged("errorMessage");
            }
        }

        /// <remarks/>
        public AccountType[] accountTypeItems
        {
            get
            {
                return this.accountTypeItemsField;
            }
            set
            {
                this.accountTypeItemsField = value;
                this.RaisePropertyChanged("accountTypeItems");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class GetAccountsReq : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIRequestHeader headerField;

        /// <remarks/>
        public APIRequestHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class DeleteAccountResp : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIResponseHeader headerField;

        private int errorCodeField;

        private string errorMessageField;

        /// <remarks/>
        public APIResponseHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public int errorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
                this.RaisePropertyChanged("errorCode");
            }
        }

        /// <remarks/>
        public string errorMessage
        {
            get
            {
                return this.errorMessageField;
            }
            set
            {
                this.errorMessageField = value;
                this.RaisePropertyChanged("errorMessage");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class DeleteAccountReq : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIRequestHeader headerField;

        private AccountType accountTypeField;

        /// <remarks/>
        public APIRequestHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public AccountType accountType
        {
            get
            {
                return this.accountTypeField;
            }
            set
            {
                this.accountTypeField = value;
                this.RaisePropertyChanged("accountType");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class UpdateAccountResp : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIResponseHeader headerField;

        private int errorCodeField;

        private string errorMessageField;

        private AccountType accountTypeField;

        /// <remarks/>
        public APIResponseHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public int errorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
                this.RaisePropertyChanged("errorCode");
            }
        }

        /// <remarks/>
        public string errorMessage
        {
            get
            {
                return this.errorMessageField;
            }
            set
            {
                this.errorMessageField = value;
                this.RaisePropertyChanged("errorMessage");
            }
        }

        /// <remarks/>
        public AccountType accountType
        {
            get
            {
                return this.accountTypeField;
            }
            set
            {
                this.accountTypeField = value;
                this.RaisePropertyChanged("accountType");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class UpdateAccountReq : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIRequestHeader headerField;

        private AccountType accountTypeField;

        /// <remarks/>
        public APIRequestHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public AccountType accountType
        {
            get
            {
                return this.accountTypeField;
            }
            set
            {
                this.accountTypeField = value;
                this.RaisePropertyChanged("accountType");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class CreateAccountResp : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIResponseHeader headerField;

        private int errorCodeField;

        private string errorMessageField;

        private AccountType accountTypeField;

        /// <remarks/>
        public APIResponseHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public int errorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
                this.RaisePropertyChanged("errorCode");
            }
        }

        /// <remarks/>
        public string errorMessage
        {
            get
            {
                return this.errorMessageField;
            }
            set
            {
                this.errorMessageField = value;
                this.RaisePropertyChanged("errorMessage");
            }
        }

        /// <remarks/>
        public AccountType accountType
        {
            get
            {
                return this.accountTypeField;
            }
            set
            {
                this.accountTypeField = value;
                this.RaisePropertyChanged("accountType");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class CreateAccountReq : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIRequestHeader headerField;

        private AccountType accountTypeField;

        /// <remarks/>
        public APIRequestHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public AccountType accountType
        {
            get
            {
                return this.accountTypeField;
            }
            set
            {
                this.accountTypeField = value;
                this.RaisePropertyChanged("accountType");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class ImportBlacklistRespType : object, System.ComponentModel.INotifyPropertyChanged
    {

        private string emailAddressField;

        private int errorCodeField;

        private string errorMessageField;

        /// <remarks/>
        public string emailAddress
        {
            get
            {
                return this.emailAddressField;
            }
            set
            {
                this.emailAddressField = value;
                this.RaisePropertyChanged("emailAddress");
            }
        }

        /// <remarks/>
        public int errorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
                this.RaisePropertyChanged("errorCode");
            }
        }

        /// <remarks/>
        public string errorMessage
        {
            get
            {
                return this.errorMessageField;
            }
            set
            {
                this.errorMessageField = value;
                this.RaisePropertyChanged("errorMessage");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class ImportBlacklistResp : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIResponseHeader headerField;

        private int errorCodeField;

        private string errorMessageField;

        private ImportBlacklistRespType[] importBlacklistRespTypeItemsField;

        /// <remarks/>
        public APIResponseHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public int errorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
                this.RaisePropertyChanged("errorCode");
            }
        }

        /// <remarks/>
        public string errorMessage
        {
            get
            {
                return this.errorMessageField;
            }
            set
            {
                this.errorMessageField = value;
                this.RaisePropertyChanged("errorMessage");
            }
        }

        /// <remarks/>
        public ImportBlacklistRespType[] importBlacklistRespTypeItems
        {
            get
            {
                return this.importBlacklistRespTypeItemsField;
            }
            set
            {
                this.importBlacklistRespTypeItemsField = value;
                this.RaisePropertyChanged("importBlacklistRespTypeItems");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class ImportBlacklistReq : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIRequestHeader headerField;

        private EmailAddressType[] emailAddressTypeItemsField;

        private MailingListType[] mailingListTypeItemsField;

        /// <remarks/>
        public APIRequestHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public EmailAddressType[] emailAddressTypeItems
        {
            get
            {
                return this.emailAddressTypeItemsField;
            }
            set
            {
                this.emailAddressTypeItemsField = value;
                this.RaisePropertyChanged("emailAddressTypeItems");
            }
        }

        /// <remarks/>
        public MailingListType[] mailingListTypeItems
        {
            get
            {
                return this.mailingListTypeItemsField;
            }
            set
            {
                this.mailingListTypeItemsField = value;
                this.RaisePropertyChanged("mailingListTypeItems");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class EmailAddressType : object, System.ComponentModel.INotifyPropertyChanged
    {

        private string flexmailIdField;

        private string emailAddressField;

        private string titleField;

        private string nameField;

        private string surnameField;

        private string streetField;

        private string zipField;

        private string cityField;

        private string provinceField;

        private string countryField;

        private string phoneField;

        private string faxField;

        private string mobileField;

        private string websiteField;

        private string languageField;

        private string genderField;

        private string birthdayField;

        private string companyField;

        private string jobtitleField;

        private string marketField;

        private string activitiesField;

        private string employeesField;

        private string naceField;

        private string turnoverField;

        private string vatField;

        private string keywordsField;

        private string free_field_1Field;

        private string free_field_2Field;

        private string free_field_3Field;

        private string free_field_4Field;

        private string free_field_5Field;

        private string free_field_6Field;

        private string barcodeField;

        private string referenceIdField;

        private EfficyEventType[] eventsField;

        private CustomFieldType[] customField;

        private string stateField;

        private int errorCodeField;

        private bool errorCodeFieldSpecified;

        private string errorMessageField;

        private int mailingListIdField;

        private bool mailingListIdFieldSpecified;

        private int[] preferencesField;

        private string zipcodeField;

        private string addressField;

        private string functionField;

        /// <remarks/>
        public string flexmailId
        {
            get
            {
                return this.flexmailIdField;
            }
            set
            {
                this.flexmailIdField = value;
                this.RaisePropertyChanged("flexmailId");
            }
        }

        /// <remarks/>
        public string emailAddress
        {
            get
            {
                return this.emailAddressField;
            }
            set
            {
                this.emailAddressField = value;
                this.RaisePropertyChanged("emailAddress");
            }
        }

        /// <remarks/>
        public string title
        {
            get
            {
                return this.titleField;
            }
            set
            {
                this.titleField = value;
                this.RaisePropertyChanged("title");
            }
        }

        /// <remarks/>
        public string name
        {
            get
            {
                return this.nameField;
            }
            set
            {
                this.nameField = value;
                this.RaisePropertyChanged("name");
            }
        }

        /// <remarks/>
        public string surname
        {
            get
            {
                return this.surnameField;
            }
            set
            {
                this.surnameField = value;
                this.RaisePropertyChanged("surname");
            }
        }

        /// <remarks/>
        public string street
        {
            get
            {
                return this.streetField;
            }
            set
            {
                this.streetField = value;
                this.RaisePropertyChanged("street");
            }
        }

        /// <remarks/>
        public string zip
        {
            get
            {
                return this.zipField;
            }
            set
            {
                this.zipField = value;
                this.RaisePropertyChanged("zip");
            }
        }

        /// <remarks/>
        public string city
        {
            get
            {
                return this.cityField;
            }
            set
            {
                this.cityField = value;
                this.RaisePropertyChanged("city");
            }
        }

        /// <remarks/>
        public string province
        {
            get
            {
                return this.provinceField;
            }
            set
            {
                this.provinceField = value;
                this.RaisePropertyChanged("province");
            }
        }

        /// <remarks/>
        public string country
        {
            get
            {
                return this.countryField;
            }
            set
            {
                this.countryField = value;
                this.RaisePropertyChanged("country");
            }
        }

        /// <remarks/>
        public string phone
        {
            get
            {
                return this.phoneField;
            }
            set
            {
                this.phoneField = value;
                this.RaisePropertyChanged("phone");
            }
        }

        /// <remarks/>
        public string fax
        {
            get
            {
                return this.faxField;
            }
            set
            {
                this.faxField = value;
                this.RaisePropertyChanged("fax");
            }
        }

        /// <remarks/>
        public string mobile
        {
            get
            {
                return this.mobileField;
            }
            set
            {
                this.mobileField = value;
                this.RaisePropertyChanged("mobile");
            }
        }

        /// <remarks/>
        public string website
        {
            get
            {
                return this.websiteField;
            }
            set
            {
                this.websiteField = value;
                this.RaisePropertyChanged("website");
            }
        }

        /// <remarks/>
        public string language
        {
            get
            {
                return this.languageField;
            }
            set
            {
                this.languageField = value;
                this.RaisePropertyChanged("language");
            }
        }

        /// <remarks/>
        public string gender
        {
            get
            {
                return this.genderField;
            }
            set
            {
                this.genderField = value;
                this.RaisePropertyChanged("gender");
            }
        }

        /// <remarks/>
        public string birthday
        {
            get
            {
                return this.birthdayField;
            }
            set
            {
                this.birthdayField = value;
                this.RaisePropertyChanged("birthday");
            }
        }

        /// <remarks/>
        public string company
        {
            get
            {
                return this.companyField;
            }
            set
            {
                this.companyField = value;
                this.RaisePropertyChanged("company");
            }
        }

        /// <remarks/>
        public string jobtitle
        {
            get
            {
                return this.jobtitleField;
            }
            set
            {
                this.jobtitleField = value;
                this.RaisePropertyChanged("jobtitle");
            }
        }

        /// <remarks/>
        public string market
        {
            get
            {
                return this.marketField;
            }
            set
            {
                this.marketField = value;
                this.RaisePropertyChanged("market");
            }
        }

        /// <remarks/>
        public string activities
        {
            get
            {
                return this.activitiesField;
            }
            set
            {
                this.activitiesField = value;
                this.RaisePropertyChanged("activities");
            }
        }

        /// <remarks/>
        public string employees
        {
            get
            {
                return this.employeesField;
            }
            set
            {
                this.employeesField = value;
                this.RaisePropertyChanged("employees");
            }
        }

        /// <remarks/>
        public string nace
        {
            get
            {
                return this.naceField;
            }
            set
            {
                this.naceField = value;
                this.RaisePropertyChanged("nace");
            }
        }

        /// <remarks/>
        public string turnover
        {
            get
            {
                return this.turnoverField;
            }
            set
            {
                this.turnoverField = value;
                this.RaisePropertyChanged("turnover");
            }
        }

        /// <remarks/>
        public string vat
        {
            get
            {
                return this.vatField;
            }
            set
            {
                this.vatField = value;
                this.RaisePropertyChanged("vat");
            }
        }

        /// <remarks/>
        public string keywords
        {
            get
            {
                return this.keywordsField;
            }
            set
            {
                this.keywordsField = value;
                this.RaisePropertyChanged("keywords");
            }
        }

        /// <remarks/>
        public string free_field_1
        {
            get
            {
                return this.free_field_1Field;
            }
            set
            {
                this.free_field_1Field = value;
                this.RaisePropertyChanged("free_field_1");
            }
        }

        /// <remarks/>
        public string free_field_2
        {
            get
            {
                return this.free_field_2Field;
            }
            set
            {
                this.free_field_2Field = value;
                this.RaisePropertyChanged("free_field_2");
            }
        }

        /// <remarks/>
        public string free_field_3
        {
            get
            {
                return this.free_field_3Field;
            }
            set
            {
                this.free_field_3Field = value;
                this.RaisePropertyChanged("free_field_3");
            }
        }

        /// <remarks/>
        public string free_field_4
        {
            get
            {
                return this.free_field_4Field;
            }
            set
            {
                this.free_field_4Field = value;
                this.RaisePropertyChanged("free_field_4");
            }
        }

        /// <remarks/>
        public string free_field_5
        {
            get
            {
                return this.free_field_5Field;
            }
            set
            {
                this.free_field_5Field = value;
                this.RaisePropertyChanged("free_field_5");
            }
        }

        /// <remarks/>
        public string free_field_6
        {
            get
            {
                return this.free_field_6Field;
            }
            set
            {
                this.free_field_6Field = value;
                this.RaisePropertyChanged("free_field_6");
            }
        }

        /// <remarks/>
        public string barcode
        {
            get
            {
                return this.barcodeField;
            }
            set
            {
                this.barcodeField = value;
                this.RaisePropertyChanged("barcode");
            }
        }

        /// <remarks/>
        public string referenceId
        {
            get
            {
                return this.referenceIdField;
            }
            set
            {
                this.referenceIdField = value;
                this.RaisePropertyChanged("referenceId");
            }
        }

        /// <remarks/>
        public EfficyEventType[] events
        {
            get
            {
                return this.eventsField;
            }
            set
            {
                this.eventsField = value;
                this.RaisePropertyChanged("events");
            }
        }

        /// <remarks/>
        public CustomFieldType[] custom
        {
            get
            {
                return this.customField;
            }
            set
            {
                this.customField = value;
                this.RaisePropertyChanged("custom");
            }
        }

        /// <remarks/>
        public string state
        {
            get
            {
                return this.stateField;
            }
            set
            {
                this.stateField = value;
                this.RaisePropertyChanged("state");
            }
        }

        /// <remarks/>
        public int errorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
                this.RaisePropertyChanged("errorCode");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool errorCodeSpecified
        {
            get
            {
                return this.errorCodeFieldSpecified;
            }
            set
            {
                this.errorCodeFieldSpecified = value;
                this.RaisePropertyChanged("errorCodeSpecified");
            }
        }

        /// <remarks/>
        public string errorMessage
        {
            get
            {
                return this.errorMessageField;
            }
            set
            {
                this.errorMessageField = value;
                this.RaisePropertyChanged("errorMessage");
            }
        }

        /// <remarks/>
        public int mailingListId
        {
            get
            {
                return this.mailingListIdField;
            }
            set
            {
                this.mailingListIdField = value;
                this.RaisePropertyChanged("mailingListId");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool mailingListIdSpecified
        {
            get
            {
                return this.mailingListIdFieldSpecified;
            }
            set
            {
                this.mailingListIdFieldSpecified = value;
                this.RaisePropertyChanged("mailingListIdSpecified");
            }
        }

        /// <remarks/>
        public int[] preferences
        {
            get
            {
                return this.preferencesField;
            }
            set
            {
                this.preferencesField = value;
                this.RaisePropertyChanged("preferences");
            }
        }

        /// <remarks/>
        public string zipcode
        {
            get
            {
                return this.zipcodeField;
            }
            set
            {
                this.zipcodeField = value;
                this.RaisePropertyChanged("zipcode");
            }
        }

        /// <remarks/>
        public string address
        {
            get
            {
                return this.addressField;
            }
            set
            {
                this.addressField = value;
                this.RaisePropertyChanged("address");
            }
        }

        /// <remarks/>
        public string function
        {
            get
            {
                return this.functionField;
            }
            set
            {
                this.functionField = value;
                this.RaisePropertyChanged("function");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class EfficyEventType : object, System.ComponentModel.INotifyPropertyChanged
    {

        private int idField;

        private string valueField;

        /// <remarks/>
        public int id
        {
            get
            {
                return this.idField;
            }
            set
            {
                this.idField = value;
                this.RaisePropertyChanged("id");
            }
        }

        /// <remarks/>
        public string value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
                this.RaisePropertyChanged("value");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class CustomFieldType : object, System.ComponentModel.INotifyPropertyChanged
    {

        private string variableNameField;

        private string valueField;

        /// <remarks/>
        public string variableName
        {
            get
            {
                return this.variableNameField;
            }
            set
            {
                this.variableNameField = value;
                this.RaisePropertyChanged("variableName");
            }
        }

        /// <remarks/>
        public string value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
                this.RaisePropertyChanged("value");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class MailingListType : object, System.ComponentModel.INotifyPropertyChanged
    {

        private int categoryIdField;

        private bool categoryIdFieldSpecified;

        private int mailingListIdField;

        private bool mailingListIdFieldSpecified;

        private string mailingListNameField;

        private string mailingListLanguageField;

        private int mailingListCountField;

        private bool mailingListCountFieldSpecified;

        private string mailingListTypeField;

        private int mailingListParentListIdField;

        private bool mailingListParentListIdFieldSpecified;

        /// <remarks/>
        public int categoryId
        {
            get
            {
                return this.categoryIdField;
            }
            set
            {
                this.categoryIdField = value;
                this.RaisePropertyChanged("categoryId");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool categoryIdSpecified
        {
            get
            {
                return this.categoryIdFieldSpecified;
            }
            set
            {
                this.categoryIdFieldSpecified = value;
                this.RaisePropertyChanged("categoryIdSpecified");
            }
        }

        /// <remarks/>
        public int mailingListId
        {
            get
            {
                return this.mailingListIdField;
            }
            set
            {
                this.mailingListIdField = value;
                this.RaisePropertyChanged("mailingListId");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool mailingListIdSpecified
        {
            get
            {
                return this.mailingListIdFieldSpecified;
            }
            set
            {
                this.mailingListIdFieldSpecified = value;
                this.RaisePropertyChanged("mailingListIdSpecified");
            }
        }

        /// <remarks/>
        public string mailingListName
        {
            get
            {
                return this.mailingListNameField;
            }
            set
            {
                this.mailingListNameField = value;
                this.RaisePropertyChanged("mailingListName");
            }
        }

        /// <remarks/>
        public string mailingListLanguage
        {
            get
            {
                return this.mailingListLanguageField;
            }
            set
            {
                this.mailingListLanguageField = value;
                this.RaisePropertyChanged("mailingListLanguage");
            }
        }

        /// <remarks/>
        public int mailingListCount
        {
            get
            {
                return this.mailingListCountField;
            }
            set
            {
                this.mailingListCountField = value;
                this.RaisePropertyChanged("mailingListCount");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool mailingListCountSpecified
        {
            get
            {
                return this.mailingListCountFieldSpecified;
            }
            set
            {
                this.mailingListCountFieldSpecified = value;
                this.RaisePropertyChanged("mailingListCountSpecified");
            }
        }

        /// <remarks/>
        public string mailingListType
        {
            get
            {
                return this.mailingListTypeField;
            }
            set
            {
                this.mailingListTypeField = value;
                this.RaisePropertyChanged("mailingListType");
            }
        }

        /// <remarks/>
        public int mailingListParentListId
        {
            get
            {
                return this.mailingListParentListIdField;
            }
            set
            {
                this.mailingListParentListIdField = value;
                this.RaisePropertyChanged("mailingListParentListId");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool mailingListParentListIdSpecified
        {
            get
            {
                return this.mailingListParentListIdFieldSpecified;
            }
            set
            {
                this.mailingListParentListIdFieldSpecified = value;
                this.RaisePropertyChanged("mailingListParentListIdSpecified");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class CampaignSummaryType : object, System.ComponentModel.INotifyPropertyChanged
    {

        private string campaignNameField;

        private string campaignReceiversField;

        private string campaignSenderNameField;

        private string campaignSenderEmailAddressField;

        private string campaignReplyEmailAddressField;

        private string campaignSubjectField;

        private string campaignMessageNameField;

        /// <remarks/>
        public string campaignName
        {
            get
            {
                return this.campaignNameField;
            }
            set
            {
                this.campaignNameField = value;
                this.RaisePropertyChanged("campaignName");
            }
        }

        /// <remarks/>
        public string campaignReceivers
        {
            get
            {
                return this.campaignReceiversField;
            }
            set
            {
                this.campaignReceiversField = value;
                this.RaisePropertyChanged("campaignReceivers");
            }
        }

        /// <remarks/>
        public string campaignSenderName
        {
            get
            {
                return this.campaignSenderNameField;
            }
            set
            {
                this.campaignSenderNameField = value;
                this.RaisePropertyChanged("campaignSenderName");
            }
        }

        /// <remarks/>
        public string campaignSenderEmailAddress
        {
            get
            {
                return this.campaignSenderEmailAddressField;
            }
            set
            {
                this.campaignSenderEmailAddressField = value;
                this.RaisePropertyChanged("campaignSenderEmailAddress");
            }
        }

        /// <remarks/>
        public string campaignReplyEmailAddress
        {
            get
            {
                return this.campaignReplyEmailAddressField;
            }
            set
            {
                this.campaignReplyEmailAddressField = value;
                this.RaisePropertyChanged("campaignReplyEmailAddress");
            }
        }

        /// <remarks/>
        public string campaignSubject
        {
            get
            {
                return this.campaignSubjectField;
            }
            set
            {
                this.campaignSubjectField = value;
                this.RaisePropertyChanged("campaignSubject");
            }
        }

        /// <remarks/>
        public string campaignMessageName
        {
            get
            {
                return this.campaignMessageNameField;
            }
            set
            {
                this.campaignMessageNameField = value;
                this.RaisePropertyChanged("campaignMessageName");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class GetCampaignSummaryResp : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIResponseHeader headerField;

        private int errorCodeField;

        private string errorMessageField;

        private CampaignSummaryType campaignSummaryTypeField;

        /// <remarks/>
        public APIResponseHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public int errorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
                this.RaisePropertyChanged("errorCode");
            }
        }

        /// <remarks/>
        public string errorMessage
        {
            get
            {
                return this.errorMessageField;
            }
            set
            {
                this.errorMessageField = value;
                this.RaisePropertyChanged("errorMessage");
            }
        }

        /// <remarks/>
        public CampaignSummaryType campaignSummaryType
        {
            get
            {
                return this.campaignSummaryTypeField;
            }
            set
            {
                this.campaignSummaryTypeField = value;
                this.RaisePropertyChanged("campaignSummaryType");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class GetCampaignSummaryReq : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIRequestHeader headerField;

        private string campaignIdField;

        /// <remarks/>
        public APIRequestHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapElementAttribute(DataType = "nonNegativeInteger")]
        public string campaignId
        {
            get
            {
                return this.campaignIdField;
            }
            set
            {
                this.campaignIdField = value;
                this.RaisePropertyChanged("campaignId");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class GetBalanceResp : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIResponseHeader headerField;

        private int emailField;

        private int faxField;

        private int smsField;

        /// <remarks/>
        public APIResponseHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public int email
        {
            get
            {
                return this.emailField;
            }
            set
            {
                this.emailField = value;
                this.RaisePropertyChanged("email");
            }
        }

        /// <remarks/>
        public int fax
        {
            get
            {
                return this.faxField;
            }
            set
            {
                this.faxField = value;
                this.RaisePropertyChanged("fax");
            }
        }

        /// <remarks/>
        public int sms
        {
            get
            {
                return this.smsField;
            }
            set
            {
                this.smsField = value;
                this.RaisePropertyChanged("sms");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class GetBalanceReq : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIRequestHeader headerField;

        /// <remarks/>
        public APIRequestHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class FormType : object, System.ComponentModel.INotifyPropertyChanged
    {

        private int formIdField;

        private string formNameField;

        private string formWebLinkField;

        /// <remarks/>
        public int formId
        {
            get
            {
                return this.formIdField;
            }
            set
            {
                this.formIdField = value;
                this.RaisePropertyChanged("formId");
            }
        }

        /// <remarks/>
        public string formName
        {
            get
            {
                return this.formNameField;
            }
            set
            {
                this.formNameField = value;
                this.RaisePropertyChanged("formName");
            }
        }

        /// <remarks/>
        public string formWebLink
        {
            get
            {
                return this.formWebLinkField;
            }
            set
            {
                this.formWebLinkField = value;
                this.RaisePropertyChanged("formWebLink");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class GetFormsResp : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIResponseHeader headerField;

        private int errorCodeField;

        private string errorMessageField;

        private FormType[] formTypeItemsField;

        /// <remarks/>
        public APIResponseHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public int errorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
                this.RaisePropertyChanged("errorCode");
            }
        }

        /// <remarks/>
        public string errorMessage
        {
            get
            {
                return this.errorMessageField;
            }
            set
            {
                this.errorMessageField = value;
                this.RaisePropertyChanged("errorMessage");
            }
        }

        /// <remarks/>
        public FormType[] formTypeItems
        {
            get
            {
                return this.formTypeItemsField;
            }
            set
            {
                this.formTypeItemsField = value;
                this.RaisePropertyChanged("formTypeItems");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class GetFormsReq : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIRequestHeader headerField;

        /// <remarks/>
        public APIRequestHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class FormResultType : object, System.ComponentModel.INotifyPropertyChanged
    {

        private bool anonymousField;

        private bool anonymousFieldSpecified;

        private string referenceIdField;

        private string flexmailIdField;

        private string formResultIdField;

        private string timestampField;

        private KeyValueType[] formResultsField;

        /// <remarks/>
        public bool anonymous
        {
            get
            {
                return this.anonymousField;
            }
            set
            {
                this.anonymousField = value;
                this.RaisePropertyChanged("anonymous");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool anonymousSpecified
        {
            get
            {
                return this.anonymousFieldSpecified;
            }
            set
            {
                this.anonymousFieldSpecified = value;
                this.RaisePropertyChanged("anonymousSpecified");
            }
        }

        /// <remarks/>
        public string referenceId
        {
            get
            {
                return this.referenceIdField;
            }
            set
            {
                this.referenceIdField = value;
                this.RaisePropertyChanged("referenceId");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapElementAttribute(DataType = "nonNegativeInteger")]
        public string flexmailId
        {
            get
            {
                return this.flexmailIdField;
            }
            set
            {
                this.flexmailIdField = value;
                this.RaisePropertyChanged("flexmailId");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapElementAttribute(DataType = "nonNegativeInteger")]
        public string formResultId
        {
            get
            {
                return this.formResultIdField;
            }
            set
            {
                this.formResultIdField = value;
                this.RaisePropertyChanged("formResultId");
            }
        }

        /// <remarks/>
        public string timestamp
        {
            get
            {
                return this.timestampField;
            }
            set
            {
                this.timestampField = value;
                this.RaisePropertyChanged("timestamp");
            }
        }

        /// <remarks/>
        public KeyValueType[] formResults
        {
            get
            {
                return this.formResultsField;
            }
            set
            {
                this.formResultsField = value;
                this.RaisePropertyChanged("formResults");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class KeyValueType : object, System.ComponentModel.INotifyPropertyChanged
    {

        private string keyField;

        private string valueField;

        /// <remarks/>
        public string key
        {
            get
            {
                return this.keyField;
            }
            set
            {
                this.keyField = value;
                this.RaisePropertyChanged("key");
            }
        }

        /// <remarks/>
        public string value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
                this.RaisePropertyChanged("value");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class GetFormResultsResp : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIResponseHeader headerField;

        private int errorCodeField;

        private string errorMessageField;

        private string formIdField;

        private FormResultType[] formResultTypeItemsField;

        /// <remarks/>
        public APIResponseHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public int errorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
                this.RaisePropertyChanged("errorCode");
            }
        }

        /// <remarks/>
        public string errorMessage
        {
            get
            {
                return this.errorMessageField;
            }
            set
            {
                this.errorMessageField = value;
                this.RaisePropertyChanged("errorMessage");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapElementAttribute(DataType = "nonNegativeInteger")]
        public string formId
        {
            get
            {
                return this.formIdField;
            }
            set
            {
                this.formIdField = value;
                this.RaisePropertyChanged("formId");
            }
        }

        /// <remarks/>
        public FormResultType[] formResultTypeItems
        {
            get
            {
                return this.formResultTypeItemsField;
            }
            set
            {
                this.formResultTypeItemsField = value;
                this.RaisePropertyChanged("formResultTypeItems");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class GetFormResultsReq : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIRequestHeader headerField;

        private string formIdField;

        private string campaignIdField;

        private string timestampSinceField;

        /// <remarks/>
        public APIRequestHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapElementAttribute(DataType = "nonNegativeInteger")]
        public string formId
        {
            get
            {
                return this.formIdField;
            }
            set
            {
                this.formIdField = value;
                this.RaisePropertyChanged("formId");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapElementAttribute(DataType = "nonNegativeInteger")]
        public string campaignId
        {
            get
            {
                return this.campaignIdField;
            }
            set
            {
                this.campaignIdField = value;
                this.RaisePropertyChanged("campaignId");
            }
        }

        /// <remarks/>
        public string timestampSince
        {
            get
            {
                return this.timestampSinceField;
            }
            set
            {
                this.timestampSinceField = value;
                this.RaisePropertyChanged("timestampSince");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class HistoryType : object, System.ComponentModel.INotifyPropertyChanged
    {

        private EmailAddressHistoryType[] emailAddressHistoryTypeItemsField;

        /// <remarks/>
        public EmailAddressHistoryType[] emailAddressHistoryTypeItems
        {
            get
            {
                return this.emailAddressHistoryTypeItemsField;
            }
            set
            {
                this.emailAddressHistoryTypeItemsField = value;
                this.RaisePropertyChanged("emailAddressHistoryTypeItems");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class EmailAddressHistoryType : object, System.ComponentModel.INotifyPropertyChanged
    {

        private string emailAddressField;

        private EmailAddressType emailAddressTypeField;

        private EmailAddressHistoryActionType[] emailAddressHistoryActionTypeItemsField;

        /// <remarks/>
        public string emailAddress
        {
            get
            {
                return this.emailAddressField;
            }
            set
            {
                this.emailAddressField = value;
                this.RaisePropertyChanged("emailAddress");
            }
        }

        /// <remarks/>
        public EmailAddressType emailAddressType
        {
            get
            {
                return this.emailAddressTypeField;
            }
            set
            {
                this.emailAddressTypeField = value;
                this.RaisePropertyChanged("emailAddressType");
            }
        }

        /// <remarks/>
        public EmailAddressHistoryActionType[] emailAddressHistoryActionTypeItems
        {
            get
            {
                return this.emailAddressHistoryActionTypeItemsField;
            }
            set
            {
                this.emailAddressHistoryActionTypeItemsField = value;
                this.RaisePropertyChanged("emailAddressHistoryActionTypeItems");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class EmailAddressHistoryActionType : object, System.ComponentModel.INotifyPropertyChanged
    {

        private string actionIdField;

        private string timestampField;

        private KeyValueType mailingListField;

        private KeyValueType campaignField;

        private KeyValueType groupField;

        private KeyValueType infopageField;

        private KeyValueType surveyField;

        private KeyValueType formField;

        private KeyValueType linkField;

        private KeyValueType bounceField;

        private EmailAddressType emailAddressTypeField;

        /// <remarks/>
        [System.Xml.Serialization.SoapElementAttribute(DataType = "nonNegativeInteger")]
        public string actionId
        {
            get
            {
                return this.actionIdField;
            }
            set
            {
                this.actionIdField = value;
                this.RaisePropertyChanged("actionId");
            }
        }

        /// <remarks/>
        public string timestamp
        {
            get
            {
                return this.timestampField;
            }
            set
            {
                this.timestampField = value;
                this.RaisePropertyChanged("timestamp");
            }
        }

        /// <remarks/>
        public KeyValueType mailingList
        {
            get
            {
                return this.mailingListField;
            }
            set
            {
                this.mailingListField = value;
                this.RaisePropertyChanged("mailingList");
            }
        }

        /// <remarks/>
        public KeyValueType campaign
        {
            get
            {
                return this.campaignField;
            }
            set
            {
                this.campaignField = value;
                this.RaisePropertyChanged("campaign");
            }
        }

        /// <remarks/>
        public KeyValueType group
        {
            get
            {
                return this.groupField;
            }
            set
            {
                this.groupField = value;
                this.RaisePropertyChanged("group");
            }
        }

        /// <remarks/>
        public KeyValueType infopage
        {
            get
            {
                return this.infopageField;
            }
            set
            {
                this.infopageField = value;
                this.RaisePropertyChanged("infopage");
            }
        }

        /// <remarks/>
        public KeyValueType survey
        {
            get
            {
                return this.surveyField;
            }
            set
            {
                this.surveyField = value;
                this.RaisePropertyChanged("survey");
            }
        }

        /// <remarks/>
        public KeyValueType form
        {
            get
            {
                return this.formField;
            }
            set
            {
                this.formField = value;
                this.RaisePropertyChanged("form");
            }
        }

        /// <remarks/>
        public KeyValueType link
        {
            get
            {
                return this.linkField;
            }
            set
            {
                this.linkField = value;
                this.RaisePropertyChanged("link");
            }
        }

        /// <remarks/>
        public KeyValueType bounce
        {
            get
            {
                return this.bounceField;
            }
            set
            {
                this.bounceField = value;
                this.RaisePropertyChanged("bounce");
            }
        }

        /// <remarks/>
        public EmailAddressType emailAddressType
        {
            get
            {
                return this.emailAddressTypeField;
            }
            set
            {
                this.emailAddressTypeField = value;
                this.RaisePropertyChanged("emailAddressType");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class GetHistoryResp : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIResponseHeader headerField;

        private int errorCodeField;

        private string errorMessageField;

        private HistoryType historyTypeField;

        /// <remarks/>
        public APIResponseHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public int errorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
                this.RaisePropertyChanged("errorCode");
            }
        }

        /// <remarks/>
        public string errorMessage
        {
            get
            {
                return this.errorMessageField;
            }
            set
            {
                this.errorMessageField = value;
                this.RaisePropertyChanged("errorMessage");
            }
        }

        /// <remarks/>
        public HistoryType historyType
        {
            get
            {
                return this.historyTypeField;
            }
            set
            {
                this.historyTypeField = value;
                this.RaisePropertyChanged("historyType");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class HistoryOptionsType : object, System.ComponentModel.INotifyPropertyChanged
    {

        private bool campaignSentField;

        private bool campaignSentFieldSpecified;

        private bool campaignReadField;

        private bool campaignReadFieldSpecified;

        private bool campaignReadOnlineField;

        private bool campaignReadOnlineFieldSpecified;

        private bool campaignLinkClickedField;

        private bool campaignLinkClickedFieldSpecified;

        private bool campaignLinkGroupClickedField;

        private bool campaignLinkGroupClickedFieldSpecified;

        private bool campaignReadInfopageField;

        private bool campaignReadInfopageFieldSpecified;

        private bool campaignFormVisitedField;

        private bool campaignFormVisitedFieldSpecified;

        private bool campaignFormSubmittedField;

        private bool campaignFormSubmittedFieldSpecified;

        private bool campaignSurveyVisitedField;

        private bool campaignSurveyVisitedFieldSpecified;

        private bool campaignSurveySubmittedField;

        private bool campaignSurveySubmittedFieldSpecified;

        private bool campaignForwardVisitedField;

        private bool campaignForwardVisitedFieldSpecified;

        private bool campaignForwardSubmittedField;

        private bool campaignForwardSubmittedFieldSpecified;

        /// <remarks/>
        public bool campaignSent
        {
            get
            {
                return this.campaignSentField;
            }
            set
            {
                this.campaignSentField = value;
                this.RaisePropertyChanged("campaignSent");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool campaignSentSpecified
        {
            get
            {
                return this.campaignSentFieldSpecified;
            }
            set
            {
                this.campaignSentFieldSpecified = value;
                this.RaisePropertyChanged("campaignSentSpecified");
            }
        }

        /// <remarks/>
        public bool campaignRead
        {
            get
            {
                return this.campaignReadField;
            }
            set
            {
                this.campaignReadField = value;
                this.RaisePropertyChanged("campaignRead");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool campaignReadSpecified
        {
            get
            {
                return this.campaignReadFieldSpecified;
            }
            set
            {
                this.campaignReadFieldSpecified = value;
                this.RaisePropertyChanged("campaignReadSpecified");
            }
        }

        /// <remarks/>
        public bool campaignReadOnline
        {
            get
            {
                return this.campaignReadOnlineField;
            }
            set
            {
                this.campaignReadOnlineField = value;
                this.RaisePropertyChanged("campaignReadOnline");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool campaignReadOnlineSpecified
        {
            get
            {
                return this.campaignReadOnlineFieldSpecified;
            }
            set
            {
                this.campaignReadOnlineFieldSpecified = value;
                this.RaisePropertyChanged("campaignReadOnlineSpecified");
            }
        }

        /// <remarks/>
        public bool campaignLinkClicked
        {
            get
            {
                return this.campaignLinkClickedField;
            }
            set
            {
                this.campaignLinkClickedField = value;
                this.RaisePropertyChanged("campaignLinkClicked");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool campaignLinkClickedSpecified
        {
            get
            {
                return this.campaignLinkClickedFieldSpecified;
            }
            set
            {
                this.campaignLinkClickedFieldSpecified = value;
                this.RaisePropertyChanged("campaignLinkClickedSpecified");
            }
        }

        /// <remarks/>
        public bool campaignLinkGroupClicked
        {
            get
            {
                return this.campaignLinkGroupClickedField;
            }
            set
            {
                this.campaignLinkGroupClickedField = value;
                this.RaisePropertyChanged("campaignLinkGroupClicked");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool campaignLinkGroupClickedSpecified
        {
            get
            {
                return this.campaignLinkGroupClickedFieldSpecified;
            }
            set
            {
                this.campaignLinkGroupClickedFieldSpecified = value;
                this.RaisePropertyChanged("campaignLinkGroupClickedSpecified");
            }
        }

        /// <remarks/>
        public bool campaignReadInfopage
        {
            get
            {
                return this.campaignReadInfopageField;
            }
            set
            {
                this.campaignReadInfopageField = value;
                this.RaisePropertyChanged("campaignReadInfopage");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool campaignReadInfopageSpecified
        {
            get
            {
                return this.campaignReadInfopageFieldSpecified;
            }
            set
            {
                this.campaignReadInfopageFieldSpecified = value;
                this.RaisePropertyChanged("campaignReadInfopageSpecified");
            }
        }

        /// <remarks/>
        public bool campaignFormVisited
        {
            get
            {
                return this.campaignFormVisitedField;
            }
            set
            {
                this.campaignFormVisitedField = value;
                this.RaisePropertyChanged("campaignFormVisited");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool campaignFormVisitedSpecified
        {
            get
            {
                return this.campaignFormVisitedFieldSpecified;
            }
            set
            {
                this.campaignFormVisitedFieldSpecified = value;
                this.RaisePropertyChanged("campaignFormVisitedSpecified");
            }
        }

        /// <remarks/>
        public bool campaignFormSubmitted
        {
            get
            {
                return this.campaignFormSubmittedField;
            }
            set
            {
                this.campaignFormSubmittedField = value;
                this.RaisePropertyChanged("campaignFormSubmitted");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool campaignFormSubmittedSpecified
        {
            get
            {
                return this.campaignFormSubmittedFieldSpecified;
            }
            set
            {
                this.campaignFormSubmittedFieldSpecified = value;
                this.RaisePropertyChanged("campaignFormSubmittedSpecified");
            }
        }

        /// <remarks/>
        public bool campaignSurveyVisited
        {
            get
            {
                return this.campaignSurveyVisitedField;
            }
            set
            {
                this.campaignSurveyVisitedField = value;
                this.RaisePropertyChanged("campaignSurveyVisited");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool campaignSurveyVisitedSpecified
        {
            get
            {
                return this.campaignSurveyVisitedFieldSpecified;
            }
            set
            {
                this.campaignSurveyVisitedFieldSpecified = value;
                this.RaisePropertyChanged("campaignSurveyVisitedSpecified");
            }
        }

        /// <remarks/>
        public bool campaignSurveySubmitted
        {
            get
            {
                return this.campaignSurveySubmittedField;
            }
            set
            {
                this.campaignSurveySubmittedField = value;
                this.RaisePropertyChanged("campaignSurveySubmitted");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool campaignSurveySubmittedSpecified
        {
            get
            {
                return this.campaignSurveySubmittedFieldSpecified;
            }
            set
            {
                this.campaignSurveySubmittedFieldSpecified = value;
                this.RaisePropertyChanged("campaignSurveySubmittedSpecified");
            }
        }

        /// <remarks/>
        public bool campaignForwardVisited
        {
            get
            {
                return this.campaignForwardVisitedField;
            }
            set
            {
                this.campaignForwardVisitedField = value;
                this.RaisePropertyChanged("campaignForwardVisited");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool campaignForwardVisitedSpecified
        {
            get
            {
                return this.campaignForwardVisitedFieldSpecified;
            }
            set
            {
                this.campaignForwardVisitedFieldSpecified = value;
                this.RaisePropertyChanged("campaignForwardVisitedSpecified");
            }
        }

        /// <remarks/>
        public bool campaignForwardSubmitted
        {
            get
            {
                return this.campaignForwardSubmittedField;
            }
            set
            {
                this.campaignForwardSubmittedField = value;
                this.RaisePropertyChanged("campaignForwardSubmitted");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool campaignForwardSubmittedSpecified
        {
            get
            {
                return this.campaignForwardSubmittedFieldSpecified;
            }
            set
            {
                this.campaignForwardSubmittedFieldSpecified = value;
                this.RaisePropertyChanged("campaignForwardSubmittedSpecified");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class GetHistoryReq : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIRequestHeader headerField;

        private string sortField;

        private string timestampFromField;

        private string timestampTillField;

        private HistoryOptionsType historyOptionsTypeField;

        /// <remarks/>
        public APIRequestHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapElementAttribute(DataType = "nonNegativeInteger")]
        public string sort
        {
            get
            {
                return this.sortField;
            }
            set
            {
                this.sortField = value;
                this.RaisePropertyChanged("sort");
            }
        }

        /// <remarks/>
        public string timestampFrom
        {
            get
            {
                return this.timestampFromField;
            }
            set
            {
                this.timestampFromField = value;
                this.RaisePropertyChanged("timestampFrom");
            }
        }

        /// <remarks/>
        public string timestampTill
        {
            get
            {
                return this.timestampTillField;
            }
            set
            {
                this.timestampTillField = value;
                this.RaisePropertyChanged("timestampTill");
            }
        }

        /// <remarks/>
        public HistoryOptionsType historyOptionsType
        {
            get
            {
                return this.historyOptionsTypeField;
            }
            set
            {
                this.historyOptionsTypeField = value;
                this.RaisePropertyChanged("historyOptionsType");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class CampaignHistoryType : object, System.ComponentModel.INotifyPropertyChanged
    {

        private EmailAddressHistoryType[] emailAddressHistoryTypeItemsField;

        /// <remarks/>
        public EmailAddressHistoryType[] emailAddressHistoryTypeItems
        {
            get
            {
                return this.emailAddressHistoryTypeItemsField;
            }
            set
            {
                this.emailAddressHistoryTypeItemsField = value;
                this.RaisePropertyChanged("emailAddressHistoryTypeItems");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class GetCampaignHistoryResp : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIResponseHeader headerField;

        private int errorCodeField;

        private string errorMessageField;

        private CampaignHistoryType campaignHistoryTypeField;

        /// <remarks/>
        public APIResponseHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public int errorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
                this.RaisePropertyChanged("errorCode");
            }
        }

        /// <remarks/>
        public string errorMessage
        {
            get
            {
                return this.errorMessageField;
            }
            set
            {
                this.errorMessageField = value;
                this.RaisePropertyChanged("errorMessage");
            }
        }

        /// <remarks/>
        public CampaignHistoryType campaignHistoryType
        {
            get
            {
                return this.campaignHistoryTypeField;
            }
            set
            {
                this.campaignHistoryTypeField = value;
                this.RaisePropertyChanged("campaignHistoryType");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class CampaignHistoryOptionsType : object, System.ComponentModel.INotifyPropertyChanged
    {

        private bool campaignSentField;

        private bool campaignSentFieldSpecified;

        private bool campaignNotSentField;

        private bool campaignNotSentFieldSpecified;

        private bool campaignReadField;

        private bool campaignReadFieldSpecified;

        private bool campaignReadOnlineField;

        private bool campaignReadOnlineFieldSpecified;

        private bool campaignLinkClickedField;

        private bool campaignLinkClickedFieldSpecified;

        private bool campaignLinkGroupClickedField;

        private bool campaignLinkGroupClickedFieldSpecified;

        private bool campaignReadInfopageField;

        private bool campaignReadInfopageFieldSpecified;

        private bool campaignFormVisitedField;

        private bool campaignFormVisitedFieldSpecified;

        private bool campaignFormSubmittedField;

        private bool campaignFormSubmittedFieldSpecified;

        private bool campaignSurveyVisitedField;

        private bool campaignSurveyVisitedFieldSpecified;

        private bool campaignSurveySubmittedField;

        private bool campaignSurveySubmittedFieldSpecified;

        private bool campaignForwardVisitedField;

        private bool campaignForwardVisitedFieldSpecified;

        private bool campaignForwardSubmittedField;

        private bool campaignForwardSubmittedFieldSpecified;

        /// <remarks/>
        public bool campaignSent
        {
            get
            {
                return this.campaignSentField;
            }
            set
            {
                this.campaignSentField = value;
                this.RaisePropertyChanged("campaignSent");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool campaignSentSpecified
        {
            get
            {
                return this.campaignSentFieldSpecified;
            }
            set
            {
                this.campaignSentFieldSpecified = value;
                this.RaisePropertyChanged("campaignSentSpecified");
            }
        }

        /// <remarks/>
        public bool campaignNotSent
        {
            get
            {
                return this.campaignNotSentField;
            }
            set
            {
                this.campaignNotSentField = value;
                this.RaisePropertyChanged("campaignNotSent");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool campaignNotSentSpecified
        {
            get
            {
                return this.campaignNotSentFieldSpecified;
            }
            set
            {
                this.campaignNotSentFieldSpecified = value;
                this.RaisePropertyChanged("campaignNotSentSpecified");
            }
        }

        /// <remarks/>
        public bool campaignRead
        {
            get
            {
                return this.campaignReadField;
            }
            set
            {
                this.campaignReadField = value;
                this.RaisePropertyChanged("campaignRead");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool campaignReadSpecified
        {
            get
            {
                return this.campaignReadFieldSpecified;
            }
            set
            {
                this.campaignReadFieldSpecified = value;
                this.RaisePropertyChanged("campaignReadSpecified");
            }
        }

        /// <remarks/>
        public bool campaignReadOnline
        {
            get
            {
                return this.campaignReadOnlineField;
            }
            set
            {
                this.campaignReadOnlineField = value;
                this.RaisePropertyChanged("campaignReadOnline");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool campaignReadOnlineSpecified
        {
            get
            {
                return this.campaignReadOnlineFieldSpecified;
            }
            set
            {
                this.campaignReadOnlineFieldSpecified = value;
                this.RaisePropertyChanged("campaignReadOnlineSpecified");
            }
        }

        /// <remarks/>
        public bool campaignLinkClicked
        {
            get
            {
                return this.campaignLinkClickedField;
            }
            set
            {
                this.campaignLinkClickedField = value;
                this.RaisePropertyChanged("campaignLinkClicked");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool campaignLinkClickedSpecified
        {
            get
            {
                return this.campaignLinkClickedFieldSpecified;
            }
            set
            {
                this.campaignLinkClickedFieldSpecified = value;
                this.RaisePropertyChanged("campaignLinkClickedSpecified");
            }
        }

        /// <remarks/>
        public bool campaignLinkGroupClicked
        {
            get
            {
                return this.campaignLinkGroupClickedField;
            }
            set
            {
                this.campaignLinkGroupClickedField = value;
                this.RaisePropertyChanged("campaignLinkGroupClicked");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool campaignLinkGroupClickedSpecified
        {
            get
            {
                return this.campaignLinkGroupClickedFieldSpecified;
            }
            set
            {
                this.campaignLinkGroupClickedFieldSpecified = value;
                this.RaisePropertyChanged("campaignLinkGroupClickedSpecified");
            }
        }

        /// <remarks/>
        public bool campaignReadInfopage
        {
            get
            {
                return this.campaignReadInfopageField;
            }
            set
            {
                this.campaignReadInfopageField = value;
                this.RaisePropertyChanged("campaignReadInfopage");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool campaignReadInfopageSpecified
        {
            get
            {
                return this.campaignReadInfopageFieldSpecified;
            }
            set
            {
                this.campaignReadInfopageFieldSpecified = value;
                this.RaisePropertyChanged("campaignReadInfopageSpecified");
            }
        }

        /// <remarks/>
        public bool campaignFormVisited
        {
            get
            {
                return this.campaignFormVisitedField;
            }
            set
            {
                this.campaignFormVisitedField = value;
                this.RaisePropertyChanged("campaignFormVisited");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool campaignFormVisitedSpecified
        {
            get
            {
                return this.campaignFormVisitedFieldSpecified;
            }
            set
            {
                this.campaignFormVisitedFieldSpecified = value;
                this.RaisePropertyChanged("campaignFormVisitedSpecified");
            }
        }

        /// <remarks/>
        public bool campaignFormSubmitted
        {
            get
            {
                return this.campaignFormSubmittedField;
            }
            set
            {
                this.campaignFormSubmittedField = value;
                this.RaisePropertyChanged("campaignFormSubmitted");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool campaignFormSubmittedSpecified
        {
            get
            {
                return this.campaignFormSubmittedFieldSpecified;
            }
            set
            {
                this.campaignFormSubmittedFieldSpecified = value;
                this.RaisePropertyChanged("campaignFormSubmittedSpecified");
            }
        }

        /// <remarks/>
        public bool campaignSurveyVisited
        {
            get
            {
                return this.campaignSurveyVisitedField;
            }
            set
            {
                this.campaignSurveyVisitedField = value;
                this.RaisePropertyChanged("campaignSurveyVisited");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool campaignSurveyVisitedSpecified
        {
            get
            {
                return this.campaignSurveyVisitedFieldSpecified;
            }
            set
            {
                this.campaignSurveyVisitedFieldSpecified = value;
                this.RaisePropertyChanged("campaignSurveyVisitedSpecified");
            }
        }

        /// <remarks/>
        public bool campaignSurveySubmitted
        {
            get
            {
                return this.campaignSurveySubmittedField;
            }
            set
            {
                this.campaignSurveySubmittedField = value;
                this.RaisePropertyChanged("campaignSurveySubmitted");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool campaignSurveySubmittedSpecified
        {
            get
            {
                return this.campaignSurveySubmittedFieldSpecified;
            }
            set
            {
                this.campaignSurveySubmittedFieldSpecified = value;
                this.RaisePropertyChanged("campaignSurveySubmittedSpecified");
            }
        }

        /// <remarks/>
        public bool campaignForwardVisited
        {
            get
            {
                return this.campaignForwardVisitedField;
            }
            set
            {
                this.campaignForwardVisitedField = value;
                this.RaisePropertyChanged("campaignForwardVisited");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool campaignForwardVisitedSpecified
        {
            get
            {
                return this.campaignForwardVisitedFieldSpecified;
            }
            set
            {
                this.campaignForwardVisitedFieldSpecified = value;
                this.RaisePropertyChanged("campaignForwardVisitedSpecified");
            }
        }

        /// <remarks/>
        public bool campaignForwardSubmitted
        {
            get
            {
                return this.campaignForwardSubmittedField;
            }
            set
            {
                this.campaignForwardSubmittedField = value;
                this.RaisePropertyChanged("campaignForwardSubmitted");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool campaignForwardSubmittedSpecified
        {
            get
            {
                return this.campaignForwardSubmittedFieldSpecified;
            }
            set
            {
                this.campaignForwardSubmittedFieldSpecified = value;
                this.RaisePropertyChanged("campaignForwardSubmittedSpecified");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class GetCampaignHistoryReq : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIRequestHeader headerField;

        private string campaignIdField;

        private string sortField;

        private string timestampFromField;

        private string timestampTillField;

        private CampaignHistoryOptionsType campaignHistoryOptionsTypeField;

        /// <remarks/>
        public APIRequestHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapElementAttribute(DataType = "nonNegativeInteger")]
        public string campaignId
        {
            get
            {
                return this.campaignIdField;
            }
            set
            {
                this.campaignIdField = value;
                this.RaisePropertyChanged("campaignId");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapElementAttribute(DataType = "nonNegativeInteger")]
        public string sort
        {
            get
            {
                return this.sortField;
            }
            set
            {
                this.sortField = value;
                this.RaisePropertyChanged("sort");
            }
        }

        /// <remarks/>
        public string timestampFrom
        {
            get
            {
                return this.timestampFromField;
            }
            set
            {
                this.timestampFromField = value;
                this.RaisePropertyChanged("timestampFrom");
            }
        }

        /// <remarks/>
        public string timestampTill
        {
            get
            {
                return this.timestampTillField;
            }
            set
            {
                this.timestampTillField = value;
                this.RaisePropertyChanged("timestampTill");
            }
        }

        /// <remarks/>
        public CampaignHistoryOptionsType campaignHistoryOptionsType
        {
            get
            {
                return this.campaignHistoryOptionsTypeField;
            }
            set
            {
                this.campaignHistoryOptionsTypeField = value;
                this.RaisePropertyChanged("campaignHistoryOptionsType");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class GetEmailAddressHistoryResp : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIResponseHeader headerField;

        private int errorCodeField;

        private string errorMessageField;

        private EmailAddressHistoryType emailAddressHistoryTypeField;

        /// <remarks/>
        public APIResponseHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public int errorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
                this.RaisePropertyChanged("errorCode");
            }
        }

        /// <remarks/>
        public string errorMessage
        {
            get
            {
                return this.errorMessageField;
            }
            set
            {
                this.errorMessageField = value;
                this.RaisePropertyChanged("errorMessage");
            }
        }

        /// <remarks/>
        public EmailAddressHistoryType emailAddressHistoryType
        {
            get
            {
                return this.emailAddressHistoryTypeField;
            }
            set
            {
                this.emailAddressHistoryTypeField = value;
                this.RaisePropertyChanged("emailAddressHistoryType");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class EmailAddressHistoryOptionsType : object, System.ComponentModel.INotifyPropertyChanged
    {

        private bool createdField;

        private bool createdFieldSpecified;

        private bool deletedField;

        private bool deletedFieldSpecified;

        private bool profileUpdateVisitedField;

        private bool profileUpdateVisitedFieldSpecified;

        private bool profileUpdateSubmittedField;

        private bool profileUpdateSubmittedFieldSpecified;

        private bool subscribedField;

        private bool subscribedFieldSpecified;

        private bool unsubscribeVisitedField;

        private bool unsubscribeVisitedFieldSpecified;

        private bool unsubscribedField;

        private bool unsubscribedFieldSpecified;

        private bool addedToGroupField;

        private bool addedToGroupFieldSpecified;

        private bool removedFromGroupField;

        private bool removedFromGroupFieldSpecified;

        private bool addedToAccountBlackListField;

        private bool addedToAccountBlackListFieldSpecified;

        private bool removedFromAccountBlackListField;

        private bool removedFromAccountBlackListFieldSpecified;

        private bool addedToMailingListBlackListField;

        private bool addedToMailingListBlackListFieldSpecified;

        private bool removedFromMailingListBlackListField;

        private bool removedFromMailingListBlackListFieldSpecified;

        private bool bouncedField;

        private bool bouncedFieldSpecified;

        private bool bouncedOutField;

        private bool bouncedOutFieldSpecified;

        private bool campaignSentField;

        private bool campaignSentFieldSpecified;

        private bool campaignReadField;

        private bool campaignReadFieldSpecified;

        private bool campaignReadOnlineField;

        private bool campaignReadOnlineFieldSpecified;

        private bool campaignLinkClickedField;

        private bool campaignLinkClickedFieldSpecified;

        private bool campaignLinkGroupClickedField;

        private bool campaignLinkGroupClickedFieldSpecified;

        private bool campaignReadInfopageField;

        private bool campaignReadInfopageFieldSpecified;

        private bool campaignFormVisitedField;

        private bool campaignFormVisitedFieldSpecified;

        private bool campaignFormSubmittedField;

        private bool campaignFormSubmittedFieldSpecified;

        private bool campaignSurveyVisitedField;

        private bool campaignSurveyVisitedFieldSpecified;

        private bool campaignSurveySubmittedField;

        private bool campaignSurveySubmittedFieldSpecified;

        private bool campaignForwardVisitedField;

        private bool campaignForwardVisitedFieldSpecified;

        private bool campaignForwardSubmittedField;

        private bool campaignForwardSubmittedFieldSpecified;

        /// <remarks/>
        public bool created
        {
            get
            {
                return this.createdField;
            }
            set
            {
                this.createdField = value;
                this.RaisePropertyChanged("created");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool createdSpecified
        {
            get
            {
                return this.createdFieldSpecified;
            }
            set
            {
                this.createdFieldSpecified = value;
                this.RaisePropertyChanged("createdSpecified");
            }
        }

        /// <remarks/>
        public bool deleted
        {
            get
            {
                return this.deletedField;
            }
            set
            {
                this.deletedField = value;
                this.RaisePropertyChanged("deleted");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool deletedSpecified
        {
            get
            {
                return this.deletedFieldSpecified;
            }
            set
            {
                this.deletedFieldSpecified = value;
                this.RaisePropertyChanged("deletedSpecified");
            }
        }

        /// <remarks/>
        public bool profileUpdateVisited
        {
            get
            {
                return this.profileUpdateVisitedField;
            }
            set
            {
                this.profileUpdateVisitedField = value;
                this.RaisePropertyChanged("profileUpdateVisited");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool profileUpdateVisitedSpecified
        {
            get
            {
                return this.profileUpdateVisitedFieldSpecified;
            }
            set
            {
                this.profileUpdateVisitedFieldSpecified = value;
                this.RaisePropertyChanged("profileUpdateVisitedSpecified");
            }
        }

        /// <remarks/>
        public bool profileUpdateSubmitted
        {
            get
            {
                return this.profileUpdateSubmittedField;
            }
            set
            {
                this.profileUpdateSubmittedField = value;
                this.RaisePropertyChanged("profileUpdateSubmitted");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool profileUpdateSubmittedSpecified
        {
            get
            {
                return this.profileUpdateSubmittedFieldSpecified;
            }
            set
            {
                this.profileUpdateSubmittedFieldSpecified = value;
                this.RaisePropertyChanged("profileUpdateSubmittedSpecified");
            }
        }

        /// <remarks/>
        public bool subscribed
        {
            get
            {
                return this.subscribedField;
            }
            set
            {
                this.subscribedField = value;
                this.RaisePropertyChanged("subscribed");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool subscribedSpecified
        {
            get
            {
                return this.subscribedFieldSpecified;
            }
            set
            {
                this.subscribedFieldSpecified = value;
                this.RaisePropertyChanged("subscribedSpecified");
            }
        }

        /// <remarks/>
        public bool unsubscribeVisited
        {
            get
            {
                return this.unsubscribeVisitedField;
            }
            set
            {
                this.unsubscribeVisitedField = value;
                this.RaisePropertyChanged("unsubscribeVisited");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool unsubscribeVisitedSpecified
        {
            get
            {
                return this.unsubscribeVisitedFieldSpecified;
            }
            set
            {
                this.unsubscribeVisitedFieldSpecified = value;
                this.RaisePropertyChanged("unsubscribeVisitedSpecified");
            }
        }

        /// <remarks/>
        public bool unsubscribed
        {
            get
            {
                return this.unsubscribedField;
            }
            set
            {
                this.unsubscribedField = value;
                this.RaisePropertyChanged("unsubscribed");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool unsubscribedSpecified
        {
            get
            {
                return this.unsubscribedFieldSpecified;
            }
            set
            {
                this.unsubscribedFieldSpecified = value;
                this.RaisePropertyChanged("unsubscribedSpecified");
            }
        }

        /// <remarks/>
        public bool addedToGroup
        {
            get
            {
                return this.addedToGroupField;
            }
            set
            {
                this.addedToGroupField = value;
                this.RaisePropertyChanged("addedToGroup");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool addedToGroupSpecified
        {
            get
            {
                return this.addedToGroupFieldSpecified;
            }
            set
            {
                this.addedToGroupFieldSpecified = value;
                this.RaisePropertyChanged("addedToGroupSpecified");
            }
        }

        /// <remarks/>
        public bool removedFromGroup
        {
            get
            {
                return this.removedFromGroupField;
            }
            set
            {
                this.removedFromGroupField = value;
                this.RaisePropertyChanged("removedFromGroup");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool removedFromGroupSpecified
        {
            get
            {
                return this.removedFromGroupFieldSpecified;
            }
            set
            {
                this.removedFromGroupFieldSpecified = value;
                this.RaisePropertyChanged("removedFromGroupSpecified");
            }
        }

        /// <remarks/>
        public bool addedToAccountBlackList
        {
            get
            {
                return this.addedToAccountBlackListField;
            }
            set
            {
                this.addedToAccountBlackListField = value;
                this.RaisePropertyChanged("addedToAccountBlackList");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool addedToAccountBlackListSpecified
        {
            get
            {
                return this.addedToAccountBlackListFieldSpecified;
            }
            set
            {
                this.addedToAccountBlackListFieldSpecified = value;
                this.RaisePropertyChanged("addedToAccountBlackListSpecified");
            }
        }

        /// <remarks/>
        public bool removedFromAccountBlackList
        {
            get
            {
                return this.removedFromAccountBlackListField;
            }
            set
            {
                this.removedFromAccountBlackListField = value;
                this.RaisePropertyChanged("removedFromAccountBlackList");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool removedFromAccountBlackListSpecified
        {
            get
            {
                return this.removedFromAccountBlackListFieldSpecified;
            }
            set
            {
                this.removedFromAccountBlackListFieldSpecified = value;
                this.RaisePropertyChanged("removedFromAccountBlackListSpecified");
            }
        }

        /// <remarks/>
        public bool addedToMailingListBlackList
        {
            get
            {
                return this.addedToMailingListBlackListField;
            }
            set
            {
                this.addedToMailingListBlackListField = value;
                this.RaisePropertyChanged("addedToMailingListBlackList");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool addedToMailingListBlackListSpecified
        {
            get
            {
                return this.addedToMailingListBlackListFieldSpecified;
            }
            set
            {
                this.addedToMailingListBlackListFieldSpecified = value;
                this.RaisePropertyChanged("addedToMailingListBlackListSpecified");
            }
        }

        /// <remarks/>
        public bool removedFromMailingListBlackList
        {
            get
            {
                return this.removedFromMailingListBlackListField;
            }
            set
            {
                this.removedFromMailingListBlackListField = value;
                this.RaisePropertyChanged("removedFromMailingListBlackList");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool removedFromMailingListBlackListSpecified
        {
            get
            {
                return this.removedFromMailingListBlackListFieldSpecified;
            }
            set
            {
                this.removedFromMailingListBlackListFieldSpecified = value;
                this.RaisePropertyChanged("removedFromMailingListBlackListSpecified");
            }
        }

        /// <remarks/>
        public bool bounced
        {
            get
            {
                return this.bouncedField;
            }
            set
            {
                this.bouncedField = value;
                this.RaisePropertyChanged("bounced");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool bouncedSpecified
        {
            get
            {
                return this.bouncedFieldSpecified;
            }
            set
            {
                this.bouncedFieldSpecified = value;
                this.RaisePropertyChanged("bouncedSpecified");
            }
        }

        /// <remarks/>
        public bool bouncedOut
        {
            get
            {
                return this.bouncedOutField;
            }
            set
            {
                this.bouncedOutField = value;
                this.RaisePropertyChanged("bouncedOut");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool bouncedOutSpecified
        {
            get
            {
                return this.bouncedOutFieldSpecified;
            }
            set
            {
                this.bouncedOutFieldSpecified = value;
                this.RaisePropertyChanged("bouncedOutSpecified");
            }
        }

        /// <remarks/>
        public bool campaignSent
        {
            get
            {
                return this.campaignSentField;
            }
            set
            {
                this.campaignSentField = value;
                this.RaisePropertyChanged("campaignSent");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool campaignSentSpecified
        {
            get
            {
                return this.campaignSentFieldSpecified;
            }
            set
            {
                this.campaignSentFieldSpecified = value;
                this.RaisePropertyChanged("campaignSentSpecified");
            }
        }

        /// <remarks/>
        public bool campaignRead
        {
            get
            {
                return this.campaignReadField;
            }
            set
            {
                this.campaignReadField = value;
                this.RaisePropertyChanged("campaignRead");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool campaignReadSpecified
        {
            get
            {
                return this.campaignReadFieldSpecified;
            }
            set
            {
                this.campaignReadFieldSpecified = value;
                this.RaisePropertyChanged("campaignReadSpecified");
            }
        }

        /// <remarks/>
        public bool campaignReadOnline
        {
            get
            {
                return this.campaignReadOnlineField;
            }
            set
            {
                this.campaignReadOnlineField = value;
                this.RaisePropertyChanged("campaignReadOnline");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool campaignReadOnlineSpecified
        {
            get
            {
                return this.campaignReadOnlineFieldSpecified;
            }
            set
            {
                this.campaignReadOnlineFieldSpecified = value;
                this.RaisePropertyChanged("campaignReadOnlineSpecified");
            }
        }

        /// <remarks/>
        public bool campaignLinkClicked
        {
            get
            {
                return this.campaignLinkClickedField;
            }
            set
            {
                this.campaignLinkClickedField = value;
                this.RaisePropertyChanged("campaignLinkClicked");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool campaignLinkClickedSpecified
        {
            get
            {
                return this.campaignLinkClickedFieldSpecified;
            }
            set
            {
                this.campaignLinkClickedFieldSpecified = value;
                this.RaisePropertyChanged("campaignLinkClickedSpecified");
            }
        }

        /// <remarks/>
        public bool campaignLinkGroupClicked
        {
            get
            {
                return this.campaignLinkGroupClickedField;
            }
            set
            {
                this.campaignLinkGroupClickedField = value;
                this.RaisePropertyChanged("campaignLinkGroupClicked");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool campaignLinkGroupClickedSpecified
        {
            get
            {
                return this.campaignLinkGroupClickedFieldSpecified;
            }
            set
            {
                this.campaignLinkGroupClickedFieldSpecified = value;
                this.RaisePropertyChanged("campaignLinkGroupClickedSpecified");
            }
        }

        /// <remarks/>
        public bool campaignReadInfopage
        {
            get
            {
                return this.campaignReadInfopageField;
            }
            set
            {
                this.campaignReadInfopageField = value;
                this.RaisePropertyChanged("campaignReadInfopage");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool campaignReadInfopageSpecified
        {
            get
            {
                return this.campaignReadInfopageFieldSpecified;
            }
            set
            {
                this.campaignReadInfopageFieldSpecified = value;
                this.RaisePropertyChanged("campaignReadInfopageSpecified");
            }
        }

        /// <remarks/>
        public bool campaignFormVisited
        {
            get
            {
                return this.campaignFormVisitedField;
            }
            set
            {
                this.campaignFormVisitedField = value;
                this.RaisePropertyChanged("campaignFormVisited");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool campaignFormVisitedSpecified
        {
            get
            {
                return this.campaignFormVisitedFieldSpecified;
            }
            set
            {
                this.campaignFormVisitedFieldSpecified = value;
                this.RaisePropertyChanged("campaignFormVisitedSpecified");
            }
        }

        /// <remarks/>
        public bool campaignFormSubmitted
        {
            get
            {
                return this.campaignFormSubmittedField;
            }
            set
            {
                this.campaignFormSubmittedField = value;
                this.RaisePropertyChanged("campaignFormSubmitted");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool campaignFormSubmittedSpecified
        {
            get
            {
                return this.campaignFormSubmittedFieldSpecified;
            }
            set
            {
                this.campaignFormSubmittedFieldSpecified = value;
                this.RaisePropertyChanged("campaignFormSubmittedSpecified");
            }
        }

        /// <remarks/>
        public bool campaignSurveyVisited
        {
            get
            {
                return this.campaignSurveyVisitedField;
            }
            set
            {
                this.campaignSurveyVisitedField = value;
                this.RaisePropertyChanged("campaignSurveyVisited");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool campaignSurveyVisitedSpecified
        {
            get
            {
                return this.campaignSurveyVisitedFieldSpecified;
            }
            set
            {
                this.campaignSurveyVisitedFieldSpecified = value;
                this.RaisePropertyChanged("campaignSurveyVisitedSpecified");
            }
        }

        /// <remarks/>
        public bool campaignSurveySubmitted
        {
            get
            {
                return this.campaignSurveySubmittedField;
            }
            set
            {
                this.campaignSurveySubmittedField = value;
                this.RaisePropertyChanged("campaignSurveySubmitted");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool campaignSurveySubmittedSpecified
        {
            get
            {
                return this.campaignSurveySubmittedFieldSpecified;
            }
            set
            {
                this.campaignSurveySubmittedFieldSpecified = value;
                this.RaisePropertyChanged("campaignSurveySubmittedSpecified");
            }
        }

        /// <remarks/>
        public bool campaignForwardVisited
        {
            get
            {
                return this.campaignForwardVisitedField;
            }
            set
            {
                this.campaignForwardVisitedField = value;
                this.RaisePropertyChanged("campaignForwardVisited");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool campaignForwardVisitedSpecified
        {
            get
            {
                return this.campaignForwardVisitedFieldSpecified;
            }
            set
            {
                this.campaignForwardVisitedFieldSpecified = value;
                this.RaisePropertyChanged("campaignForwardVisitedSpecified");
            }
        }

        /// <remarks/>
        public bool campaignForwardSubmitted
        {
            get
            {
                return this.campaignForwardSubmittedField;
            }
            set
            {
                this.campaignForwardSubmittedField = value;
                this.RaisePropertyChanged("campaignForwardSubmitted");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool campaignForwardSubmittedSpecified
        {
            get
            {
                return this.campaignForwardSubmittedFieldSpecified;
            }
            set
            {
                this.campaignForwardSubmittedFieldSpecified = value;
                this.RaisePropertyChanged("campaignForwardSubmittedSpecified");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class GetEmailAddressHistoryReq : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIRequestHeader headerField;

        private string emailAddressField;

        private EmailAddressHistoryOptionsType emailAddressHistoryOptionsTypeField;

        private string timestampFromField;

        private string timestampTillField;

        private string sortField;

        /// <remarks/>
        public APIRequestHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public string emailAddress
        {
            get
            {
                return this.emailAddressField;
            }
            set
            {
                this.emailAddressField = value;
                this.RaisePropertyChanged("emailAddress");
            }
        }

        /// <remarks/>
        public EmailAddressHistoryOptionsType emailAddressHistoryOptionsType
        {
            get
            {
                return this.emailAddressHistoryOptionsTypeField;
            }
            set
            {
                this.emailAddressHistoryOptionsTypeField = value;
                this.RaisePropertyChanged("emailAddressHistoryOptionsType");
            }
        }

        /// <remarks/>
        public string timestampFrom
        {
            get
            {
                return this.timestampFromField;
            }
            set
            {
                this.timestampFromField = value;
                this.RaisePropertyChanged("timestampFrom");
            }
        }

        /// <remarks/>
        public string timestampTill
        {
            get
            {
                return this.timestampTillField;
            }
            set
            {
                this.timestampTillField = value;
                this.RaisePropertyChanged("timestampTill");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapElementAttribute(DataType = "nonNegativeInteger")]
        public string sort
        {
            get
            {
                return this.sortField;
            }
            set
            {
                this.sortField = value;
                this.RaisePropertyChanged("sort");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class GetEfficyActivitiesResp : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIResponseHeader headerField;

        private int errorCodeField;

        private string errorMessageField;

        private EfficyActivityType[] efficyActivityTypeItemsField;

        /// <remarks/>
        public APIResponseHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public int errorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
                this.RaisePropertyChanged("errorCode");
            }
        }

        /// <remarks/>
        public string errorMessage
        {
            get
            {
                return this.errorMessageField;
            }
            set
            {
                this.errorMessageField = value;
                this.RaisePropertyChanged("errorMessage");
            }
        }

        /// <remarks/>
        public EfficyActivityType[] efficyActivityTypeItems
        {
            get
            {
                return this.efficyActivityTypeItemsField;
            }
            set
            {
                this.efficyActivityTypeItemsField = value;
                this.RaisePropertyChanged("efficyActivityTypeItems");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class EfficyActivityType : object, System.ComponentModel.INotifyPropertyChanged
    {

        private int idField;

        private bool idFieldSpecified;

        private string nameField;

        private string labelField;

        private int userIdField;

        private bool userIdFieldSpecified;

        private int freeFieldIdField;

        private bool freeFieldIdFieldSpecified;

        private int eventIdField;

        private bool eventIdFieldSpecified;

        /// <remarks/>
        public int id
        {
            get
            {
                return this.idField;
            }
            set
            {
                this.idField = value;
                this.RaisePropertyChanged("id");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool idSpecified
        {
            get
            {
                return this.idFieldSpecified;
            }
            set
            {
                this.idFieldSpecified = value;
                this.RaisePropertyChanged("idSpecified");
            }
        }

        /// <remarks/>
        public string name
        {
            get
            {
                return this.nameField;
            }
            set
            {
                this.nameField = value;
                this.RaisePropertyChanged("name");
            }
        }

        /// <remarks/>
        public string label
        {
            get
            {
                return this.labelField;
            }
            set
            {
                this.labelField = value;
                this.RaisePropertyChanged("label");
            }
        }

        /// <remarks/>
        public int userId
        {
            get
            {
                return this.userIdField;
            }
            set
            {
                this.userIdField = value;
                this.RaisePropertyChanged("userId");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool userIdSpecified
        {
            get
            {
                return this.userIdFieldSpecified;
            }
            set
            {
                this.userIdFieldSpecified = value;
                this.RaisePropertyChanged("userIdSpecified");
            }
        }

        /// <remarks/>
        public int freeFieldId
        {
            get
            {
                return this.freeFieldIdField;
            }
            set
            {
                this.freeFieldIdField = value;
                this.RaisePropertyChanged("freeFieldId");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool freeFieldIdSpecified
        {
            get
            {
                return this.freeFieldIdFieldSpecified;
            }
            set
            {
                this.freeFieldIdFieldSpecified = value;
                this.RaisePropertyChanged("freeFieldIdSpecified");
            }
        }

        /// <remarks/>
        public int eventId
        {
            get
            {
                return this.eventIdField;
            }
            set
            {
                this.eventIdField = value;
                this.RaisePropertyChanged("eventId");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool eventIdSpecified
        {
            get
            {
                return this.eventIdFieldSpecified;
            }
            set
            {
                this.eventIdFieldSpecified = value;
                this.RaisePropertyChanged("eventIdSpecified");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class GetEfficyActivitiesReq : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIRequestHeader headerField;

        /// <remarks/>
        public APIRequestHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class DeleteEfficyActivityResp : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIResponseHeader headerField;

        private int errorCodeField;

        private string errorMessageField;

        /// <remarks/>
        public APIResponseHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public int errorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
                this.RaisePropertyChanged("errorCode");
            }
        }

        /// <remarks/>
        public string errorMessage
        {
            get
            {
                return this.errorMessageField;
            }
            set
            {
                this.errorMessageField = value;
                this.RaisePropertyChanged("errorMessage");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class DeleteEfficyActivityReq : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIRequestHeader headerField;

        private EfficyActivityType efficyActivityTypeField;

        /// <remarks/>
        public APIRequestHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public EfficyActivityType efficyActivityType
        {
            get
            {
                return this.efficyActivityTypeField;
            }
            set
            {
                this.efficyActivityTypeField = value;
                this.RaisePropertyChanged("efficyActivityType");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class UpdateEfficyActivityResp : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIResponseHeader headerField;

        private int errorCodeField;

        private string errorMessageField;

        /// <remarks/>
        public APIResponseHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public int errorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
                this.RaisePropertyChanged("errorCode");
            }
        }

        /// <remarks/>
        public string errorMessage
        {
            get
            {
                return this.errorMessageField;
            }
            set
            {
                this.errorMessageField = value;
                this.RaisePropertyChanged("errorMessage");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class UpdateEfficyActivityReq : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIRequestHeader headerField;

        private EfficyActivityType efficyActivityTypeField;

        /// <remarks/>
        public APIRequestHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public EfficyActivityType efficyActivityType
        {
            get
            {
                return this.efficyActivityTypeField;
            }
            set
            {
                this.efficyActivityTypeField = value;
                this.RaisePropertyChanged("efficyActivityType");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class CreateEfficyActivityResp : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIResponseHeader headerField;

        private int errorCodeField;

        private string errorMessageField;

        private int efficyActivityIdField;

        /// <remarks/>
        public APIResponseHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public int errorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
                this.RaisePropertyChanged("errorCode");
            }
        }

        /// <remarks/>
        public string errorMessage
        {
            get
            {
                return this.errorMessageField;
            }
            set
            {
                this.errorMessageField = value;
                this.RaisePropertyChanged("errorMessage");
            }
        }

        /// <remarks/>
        public int efficyActivityId
        {
            get
            {
                return this.efficyActivityIdField;
            }
            set
            {
                this.efficyActivityIdField = value;
                this.RaisePropertyChanged("efficyActivityId");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class CreateEfficyActivityReq : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIRequestHeader headerField;

        private EfficyActivityType efficyActivityTypeField;

        /// <remarks/>
        public APIRequestHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public EfficyActivityType efficyActivityType
        {
            get
            {
                return this.efficyActivityTypeField;
            }
            set
            {
                this.efficyActivityTypeField = value;
                this.RaisePropertyChanged("efficyActivityType");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class PutFilesResp : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIRequestHeader headerField;

        private FileType[] fileTypeItemsField;

        private int errorCodeField;

        private string errorMessageField;

        /// <remarks/>
        public APIRequestHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public FileType[] fileTypeItems
        {
            get
            {
                return this.fileTypeItemsField;
            }
            set
            {
                this.fileTypeItemsField = value;
                this.RaisePropertyChanged("fileTypeItems");
            }
        }

        /// <remarks/>
        public int errorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
                this.RaisePropertyChanged("errorCode");
            }
        }

        /// <remarks/>
        public string errorMessage
        {
            get
            {
                return this.errorMessageField;
            }
            set
            {
                this.errorMessageField = value;
                this.RaisePropertyChanged("errorMessage");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class FileType : object, System.ComponentModel.INotifyPropertyChanged
    {

        private string typeField;

        private string nameField;

        private string dataField;

        private int errorCodeField;

        private bool errorCodeFieldSpecified;

        private string errorMessageField;

        /// <remarks/>
        public string type
        {
            get
            {
                return this.typeField;
            }
            set
            {
                this.typeField = value;
                this.RaisePropertyChanged("type");
            }
        }

        /// <remarks/>
        public string name
        {
            get
            {
                return this.nameField;
            }
            set
            {
                this.nameField = value;
                this.RaisePropertyChanged("name");
            }
        }

        /// <remarks/>
        public string data
        {
            get
            {
                return this.dataField;
            }
            set
            {
                this.dataField = value;
                this.RaisePropertyChanged("data");
            }
        }

        /// <remarks/>
        public int errorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
                this.RaisePropertyChanged("errorCode");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool errorCodeSpecified
        {
            get
            {
                return this.errorCodeFieldSpecified;
            }
            set
            {
                this.errorCodeFieldSpecified = value;
                this.RaisePropertyChanged("errorCodeSpecified");
            }
        }

        /// <remarks/>
        public string errorMessage
        {
            get
            {
                return this.errorMessageField;
            }
            set
            {
                this.errorMessageField = value;
                this.RaisePropertyChanged("errorMessage");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class PutFilesReq : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIRequestHeader headerField;

        private FileType[] fileTypeItemsField;

        /// <remarks/>
        public APIRequestHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public FileType[] fileTypeItems
        {
            get
            {
                return this.fileTypeItemsField;
            }
            set
            {
                this.fileTypeItemsField = value;
                this.RaisePropertyChanged("fileTypeItems");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class CampaignReportType : object, System.ComponentModel.INotifyPropertyChanged
    {

        private int campaignIdField;

        private string campaignTimestampStartField;

        private string campaignTimestampStopField;

        private int campaignTotalEmailAddressesSendField;

        private int campaignTotalEmailAddressesBouncedField;

        private int campaignTotalEmailAddressesDeliveredField;

        private int campaignTotalEmailAddressesReadField;

        private int campaignTotalEmailAddressesUnreadField;

        private int campaignTotalEmailAddressesClickedField;

        private int campaignTotalEmailAddressesUnsubscribedField;

        private int campaignTotalEmailAddressesProfileUpdatedField;

        private float campaignRatioDeliveredField;

        private float campaignRatioUnsubscribedField;

        private float campaignRatioReadField;

        private float campaignRatioBouncedField;

        private float campaignRatioClickedField;

        private string campaignPdfReportLinkField;

        private string campaignLinkMapField;

        /// <remarks/>
        public int campaignId
        {
            get
            {
                return this.campaignIdField;
            }
            set
            {
                this.campaignIdField = value;
                this.RaisePropertyChanged("campaignId");
            }
        }

        /// <remarks/>
        public string campaignTimestampStart
        {
            get
            {
                return this.campaignTimestampStartField;
            }
            set
            {
                this.campaignTimestampStartField = value;
                this.RaisePropertyChanged("campaignTimestampStart");
            }
        }

        /// <remarks/>
        public string campaignTimestampStop
        {
            get
            {
                return this.campaignTimestampStopField;
            }
            set
            {
                this.campaignTimestampStopField = value;
                this.RaisePropertyChanged("campaignTimestampStop");
            }
        }

        /// <remarks/>
        public int campaignTotalEmailAddressesSend
        {
            get
            {
                return this.campaignTotalEmailAddressesSendField;
            }
            set
            {
                this.campaignTotalEmailAddressesSendField = value;
                this.RaisePropertyChanged("campaignTotalEmailAddressesSend");
            }
        }

        /// <remarks/>
        public int campaignTotalEmailAddressesBounced
        {
            get
            {
                return this.campaignTotalEmailAddressesBouncedField;
            }
            set
            {
                this.campaignTotalEmailAddressesBouncedField = value;
                this.RaisePropertyChanged("campaignTotalEmailAddressesBounced");
            }
        }

        /// <remarks/>
        public int campaignTotalEmailAddressesDelivered
        {
            get
            {
                return this.campaignTotalEmailAddressesDeliveredField;
            }
            set
            {
                this.campaignTotalEmailAddressesDeliveredField = value;
                this.RaisePropertyChanged("campaignTotalEmailAddressesDelivered");
            }
        }

        /// <remarks/>
        public int campaignTotalEmailAddressesRead
        {
            get
            {
                return this.campaignTotalEmailAddressesReadField;
            }
            set
            {
                this.campaignTotalEmailAddressesReadField = value;
                this.RaisePropertyChanged("campaignTotalEmailAddressesRead");
            }
        }

        /// <remarks/>
        public int campaignTotalEmailAddressesUnread
        {
            get
            {
                return this.campaignTotalEmailAddressesUnreadField;
            }
            set
            {
                this.campaignTotalEmailAddressesUnreadField = value;
                this.RaisePropertyChanged("campaignTotalEmailAddressesUnread");
            }
        }

        /// <remarks/>
        public int campaignTotalEmailAddressesClicked
        {
            get
            {
                return this.campaignTotalEmailAddressesClickedField;
            }
            set
            {
                this.campaignTotalEmailAddressesClickedField = value;
                this.RaisePropertyChanged("campaignTotalEmailAddressesClicked");
            }
        }

        /// <remarks/>
        public int campaignTotalEmailAddressesUnsubscribed
        {
            get
            {
                return this.campaignTotalEmailAddressesUnsubscribedField;
            }
            set
            {
                this.campaignTotalEmailAddressesUnsubscribedField = value;
                this.RaisePropertyChanged("campaignTotalEmailAddressesUnsubscribed");
            }
        }

        /// <remarks/>
        public int campaignTotalEmailAddressesProfileUpdated
        {
            get
            {
                return this.campaignTotalEmailAddressesProfileUpdatedField;
            }
            set
            {
                this.campaignTotalEmailAddressesProfileUpdatedField = value;
                this.RaisePropertyChanged("campaignTotalEmailAddressesProfileUpdated");
            }
        }

        /// <remarks/>
        public float campaignRatioDelivered
        {
            get
            {
                return this.campaignRatioDeliveredField;
            }
            set
            {
                this.campaignRatioDeliveredField = value;
                this.RaisePropertyChanged("campaignRatioDelivered");
            }
        }

        /// <remarks/>
        public float campaignRatioUnsubscribed
        {
            get
            {
                return this.campaignRatioUnsubscribedField;
            }
            set
            {
                this.campaignRatioUnsubscribedField = value;
                this.RaisePropertyChanged("campaignRatioUnsubscribed");
            }
        }

        /// <remarks/>
        public float campaignRatioRead
        {
            get
            {
                return this.campaignRatioReadField;
            }
            set
            {
                this.campaignRatioReadField = value;
                this.RaisePropertyChanged("campaignRatioRead");
            }
        }

        /// <remarks/>
        public float campaignRatioBounced
        {
            get
            {
                return this.campaignRatioBouncedField;
            }
            set
            {
                this.campaignRatioBouncedField = value;
                this.RaisePropertyChanged("campaignRatioBounced");
            }
        }

        /// <remarks/>
        public float campaignRatioClicked
        {
            get
            {
                return this.campaignRatioClickedField;
            }
            set
            {
                this.campaignRatioClickedField = value;
                this.RaisePropertyChanged("campaignRatioClicked");
            }
        }

        /// <remarks/>
        public string campaignPdfReportLink
        {
            get
            {
                return this.campaignPdfReportLinkField;
            }
            set
            {
                this.campaignPdfReportLinkField = value;
                this.RaisePropertyChanged("campaignPdfReportLink");
            }
        }

        /// <remarks/>
        public string campaignLinkMap
        {
            get
            {
                return this.campaignLinkMapField;
            }
            set
            {
                this.campaignLinkMapField = value;
                this.RaisePropertyChanged("campaignLinkMap");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class GetCampaignReportResp : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIResponseHeader headerField;

        private int errorCodeField;

        private string errorMessageField;

        private CampaignReportType campaignReportTypeField;

        /// <remarks/>
        public APIResponseHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public int errorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
                this.RaisePropertyChanged("errorCode");
            }
        }

        /// <remarks/>
        public string errorMessage
        {
            get
            {
                return this.errorMessageField;
            }
            set
            {
                this.errorMessageField = value;
                this.RaisePropertyChanged("errorMessage");
            }
        }

        /// <remarks/>
        public CampaignReportType campaignReportType
        {
            get
            {
                return this.campaignReportTypeField;
            }
            set
            {
                this.campaignReportTypeField = value;
                this.RaisePropertyChanged("campaignReportType");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class GetCampaignReportReq : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIRequestHeader headerField;

        private int campaignIdField;

        private bool campaignIdFieldSpecified;

        private string languageField;

        /// <remarks/>
        public APIRequestHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public int campaignId
        {
            get
            {
                return this.campaignIdField;
            }
            set
            {
                this.campaignIdField = value;
                this.RaisePropertyChanged("campaignId");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool campaignIdSpecified
        {
            get
            {
                return this.campaignIdFieldSpecified;
            }
            set
            {
                this.campaignIdFieldSpecified = value;
                this.RaisePropertyChanged("campaignIdSpecified");
            }
        }

        /// <remarks/>
        public string language
        {
            get
            {
                return this.languageField;
            }
            set
            {
                this.languageField = value;
                this.RaisePropertyChanged("language");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class TrackingLinkHitType : object, System.ComponentModel.INotifyPropertyChanged
    {

        private long trackingLinkIdField;

        private int emailAddressFlexmailIdField;

        private string emailAddressReferenceIdField;

        private string timestampField;

        /// <remarks/>
        public long trackingLinkId
        {
            get
            {
                return this.trackingLinkIdField;
            }
            set
            {
                this.trackingLinkIdField = value;
                this.RaisePropertyChanged("trackingLinkId");
            }
        }

        /// <remarks/>
        public int emailAddressFlexmailId
        {
            get
            {
                return this.emailAddressFlexmailIdField;
            }
            set
            {
                this.emailAddressFlexmailIdField = value;
                this.RaisePropertyChanged("emailAddressFlexmailId");
            }
        }

        /// <remarks/>
        public string emailAddressReferenceId
        {
            get
            {
                return this.emailAddressReferenceIdField;
            }
            set
            {
                this.emailAddressReferenceIdField = value;
                this.RaisePropertyChanged("emailAddressReferenceId");
            }
        }

        /// <remarks/>
        public string timestamp
        {
            get
            {
                return this.timestampField;
            }
            set
            {
                this.timestampField = value;
                this.RaisePropertyChanged("timestamp");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class GetTrackingLinkHitsResp : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIResponseHeader headerField;

        private int errorCodeField;

        private string errorMessageField;

        private TrackingLinkHitType[] trackingLinkHitTypeItemsField;

        /// <remarks/>
        public APIResponseHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public int errorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
                this.RaisePropertyChanged("errorCode");
            }
        }

        /// <remarks/>
        public string errorMessage
        {
            get
            {
                return this.errorMessageField;
            }
            set
            {
                this.errorMessageField = value;
                this.RaisePropertyChanged("errorMessage");
            }
        }

        /// <remarks/>
        public TrackingLinkHitType[] trackingLinkHitTypeItems
        {
            get
            {
                return this.trackingLinkHitTypeItemsField;
            }
            set
            {
                this.trackingLinkHitTypeItemsField = value;
                this.RaisePropertyChanged("trackingLinkHitTypeItems");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class GetTrackingLinkHitsReq : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIRequestHeader headerField;

        private long trackingLinkIdField;

        /// <remarks/>
        public APIRequestHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public long trackingLinkId
        {
            get
            {
                return this.trackingLinkIdField;
            }
            set
            {
                this.trackingLinkIdField = value;
                this.RaisePropertyChanged("trackingLinkId");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class TrackingLinkType : object, System.ComponentModel.INotifyPropertyChanged
    {

        private long trackingLinkIdField;

        private string trackingLinkNameField;

        private string trackingLinkUrlField;

        private int trackingLinkHitsField;

        private int trackingLinkMaxImmoIdField;

        private bool trackingLinkMaxImmoIdFieldSpecified;

        /// <remarks/>
        public long trackingLinkId
        {
            get
            {
                return this.trackingLinkIdField;
            }
            set
            {
                this.trackingLinkIdField = value;
                this.RaisePropertyChanged("trackingLinkId");
            }
        }

        /// <remarks/>
        public string trackingLinkName
        {
            get
            {
                return this.trackingLinkNameField;
            }
            set
            {
                this.trackingLinkNameField = value;
                this.RaisePropertyChanged("trackingLinkName");
            }
        }

        /// <remarks/>
        public string trackingLinkUrl
        {
            get
            {
                return this.trackingLinkUrlField;
            }
            set
            {
                this.trackingLinkUrlField = value;
                this.RaisePropertyChanged("trackingLinkUrl");
            }
        }

        /// <remarks/>
        public int trackingLinkHits
        {
            get
            {
                return this.trackingLinkHitsField;
            }
            set
            {
                this.trackingLinkHitsField = value;
                this.RaisePropertyChanged("trackingLinkHits");
            }
        }

        /// <remarks/>
        public int trackingLinkMaxImmoId
        {
            get
            {
                return this.trackingLinkMaxImmoIdField;
            }
            set
            {
                this.trackingLinkMaxImmoIdField = value;
                this.RaisePropertyChanged("trackingLinkMaxImmoId");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool trackingLinkMaxImmoIdSpecified
        {
            get
            {
                return this.trackingLinkMaxImmoIdFieldSpecified;
            }
            set
            {
                this.trackingLinkMaxImmoIdFieldSpecified = value;
                this.RaisePropertyChanged("trackingLinkMaxImmoIdSpecified");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class GetCampaignTrackingLinksResp : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIResponseHeader headerField;

        private int errorCodeField;

        private string errorMessageField;

        private TrackingLinkType[] trackingLinkTypeItemsField;

        /// <remarks/>
        public APIResponseHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public int errorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
                this.RaisePropertyChanged("errorCode");
            }
        }

        /// <remarks/>
        public string errorMessage
        {
            get
            {
                return this.errorMessageField;
            }
            set
            {
                this.errorMessageField = value;
                this.RaisePropertyChanged("errorMessage");
            }
        }

        /// <remarks/>
        public TrackingLinkType[] trackingLinkTypeItems
        {
            get
            {
                return this.trackingLinkTypeItemsField;
            }
            set
            {
                this.trackingLinkTypeItemsField = value;
                this.RaisePropertyChanged("trackingLinkTypeItems");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class GetCampaignTrackingLinksReq : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIRequestHeader headerField;

        private int mailingListIdField;

        private bool mailingListIdFieldSpecified;

        private int campaignIdField;

        private bool campaignIdFieldSpecified;

        private string timestampSinceField;

        /// <remarks/>
        public APIRequestHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public int mailingListId
        {
            get
            {
                return this.mailingListIdField;
            }
            set
            {
                this.mailingListIdField = value;
                this.RaisePropertyChanged("mailingListId");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool mailingListIdSpecified
        {
            get
            {
                return this.mailingListIdFieldSpecified;
            }
            set
            {
                this.mailingListIdFieldSpecified = value;
                this.RaisePropertyChanged("mailingListIdSpecified");
            }
        }

        /// <remarks/>
        public int campaignId
        {
            get
            {
                return this.campaignIdField;
            }
            set
            {
                this.campaignIdField = value;
                this.RaisePropertyChanged("campaignId");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool campaignIdSpecified
        {
            get
            {
                return this.campaignIdFieldSpecified;
            }
            set
            {
                this.campaignIdFieldSpecified = value;
                this.RaisePropertyChanged("campaignIdSpecified");
            }
        }

        /// <remarks/>
        public string timestampSince
        {
            get
            {
                return this.timestampSinceField;
            }
            set
            {
                this.timestampSinceField = value;
                this.RaisePropertyChanged("timestampSince");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class ProfileUpdateType : object, System.ComponentModel.INotifyPropertyChanged
    {

        private int campaignIdField;

        private bool campaignIdFieldSpecified;

        private int emailAddressFlexmailIdField;

        private bool emailAddressFlexmailIdFieldSpecified;

        private string emailAddressReferenceIdField;

        private int emailAddressMailingListIdField;

        private bool emailAddressMailingListIdFieldSpecified;

        private EmailAddressType emailAddressTypeField;

        private string timestampField;

        /// <remarks/>
        public int campaignId
        {
            get
            {
                return this.campaignIdField;
            }
            set
            {
                this.campaignIdField = value;
                this.RaisePropertyChanged("campaignId");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool campaignIdSpecified
        {
            get
            {
                return this.campaignIdFieldSpecified;
            }
            set
            {
                this.campaignIdFieldSpecified = value;
                this.RaisePropertyChanged("campaignIdSpecified");
            }
        }

        /// <remarks/>
        public int emailAddressFlexmailId
        {
            get
            {
                return this.emailAddressFlexmailIdField;
            }
            set
            {
                this.emailAddressFlexmailIdField = value;
                this.RaisePropertyChanged("emailAddressFlexmailId");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool emailAddressFlexmailIdSpecified
        {
            get
            {
                return this.emailAddressFlexmailIdFieldSpecified;
            }
            set
            {
                this.emailAddressFlexmailIdFieldSpecified = value;
                this.RaisePropertyChanged("emailAddressFlexmailIdSpecified");
            }
        }

        /// <remarks/>
        public string emailAddressReferenceId
        {
            get
            {
                return this.emailAddressReferenceIdField;
            }
            set
            {
                this.emailAddressReferenceIdField = value;
                this.RaisePropertyChanged("emailAddressReferenceId");
            }
        }

        /// <remarks/>
        public int emailAddressMailingListId
        {
            get
            {
                return this.emailAddressMailingListIdField;
            }
            set
            {
                this.emailAddressMailingListIdField = value;
                this.RaisePropertyChanged("emailAddressMailingListId");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool emailAddressMailingListIdSpecified
        {
            get
            {
                return this.emailAddressMailingListIdFieldSpecified;
            }
            set
            {
                this.emailAddressMailingListIdFieldSpecified = value;
                this.RaisePropertyChanged("emailAddressMailingListIdSpecified");
            }
        }

        /// <remarks/>
        public EmailAddressType emailAddressType
        {
            get
            {
                return this.emailAddressTypeField;
            }
            set
            {
                this.emailAddressTypeField = value;
                this.RaisePropertyChanged("emailAddressType");
            }
        }

        /// <remarks/>
        public string timestamp
        {
            get
            {
                return this.timestampField;
            }
            set
            {
                this.timestampField = value;
                this.RaisePropertyChanged("timestamp");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class GetProfileUpdatesResp : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIResponseHeader headerField;

        private int errorCodeField;

        private string errorMessageField;

        private ProfileUpdateType[] profileUpdateTypeItemsField;

        /// <remarks/>
        public APIResponseHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public int errorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
                this.RaisePropertyChanged("errorCode");
            }
        }

        /// <remarks/>
        public string errorMessage
        {
            get
            {
                return this.errorMessageField;
            }
            set
            {
                this.errorMessageField = value;
                this.RaisePropertyChanged("errorMessage");
            }
        }

        /// <remarks/>
        public ProfileUpdateType[] profileUpdateTypeItems
        {
            get
            {
                return this.profileUpdateTypeItemsField;
            }
            set
            {
                this.profileUpdateTypeItemsField = value;
                this.RaisePropertyChanged("profileUpdateTypeItems");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class GetProfileUpdatesReq : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIRequestHeader headerField;

        private int mailingListIdField;

        private bool mailingListIdFieldSpecified;

        private int campaignIdField;

        private bool campaignIdFieldSpecified;

        private string timestampSinceField;

        /// <remarks/>
        public APIRequestHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public int mailingListId
        {
            get
            {
                return this.mailingListIdField;
            }
            set
            {
                this.mailingListIdField = value;
                this.RaisePropertyChanged("mailingListId");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool mailingListIdSpecified
        {
            get
            {
                return this.mailingListIdFieldSpecified;
            }
            set
            {
                this.mailingListIdFieldSpecified = value;
                this.RaisePropertyChanged("mailingListIdSpecified");
            }
        }

        /// <remarks/>
        public int campaignId
        {
            get
            {
                return this.campaignIdField;
            }
            set
            {
                this.campaignIdField = value;
                this.RaisePropertyChanged("campaignId");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool campaignIdSpecified
        {
            get
            {
                return this.campaignIdFieldSpecified;
            }
            set
            {
                this.campaignIdFieldSpecified = value;
                this.RaisePropertyChanged("campaignIdSpecified");
            }
        }

        /// <remarks/>
        public string timestampSince
        {
            get
            {
                return this.timestampSinceField;
            }
            set
            {
                this.timestampSinceField = value;
                this.RaisePropertyChanged("timestampSince");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class SubscriptionType : object, System.ComponentModel.INotifyPropertyChanged
    {

        private int emailAddressFlexmailIdField;

        private int emailAddressMailingListIdField;

        private EmailAddressType emailAddressTypeField;

        private int statusCodeField;

        private string statusMessageField;

        private string timestampField;

        /// <remarks/>
        public int emailAddressFlexmailId
        {
            get
            {
                return this.emailAddressFlexmailIdField;
            }
            set
            {
                this.emailAddressFlexmailIdField = value;
                this.RaisePropertyChanged("emailAddressFlexmailId");
            }
        }

        /// <remarks/>
        public int emailAddressMailingListId
        {
            get
            {
                return this.emailAddressMailingListIdField;
            }
            set
            {
                this.emailAddressMailingListIdField = value;
                this.RaisePropertyChanged("emailAddressMailingListId");
            }
        }

        /// <remarks/>
        public EmailAddressType emailAddressType
        {
            get
            {
                return this.emailAddressTypeField;
            }
            set
            {
                this.emailAddressTypeField = value;
                this.RaisePropertyChanged("emailAddressType");
            }
        }

        /// <remarks/>
        public int statusCode
        {
            get
            {
                return this.statusCodeField;
            }
            set
            {
                this.statusCodeField = value;
                this.RaisePropertyChanged("statusCode");
            }
        }

        /// <remarks/>
        public string statusMessage
        {
            get
            {
                return this.statusMessageField;
            }
            set
            {
                this.statusMessageField = value;
                this.RaisePropertyChanged("statusMessage");
            }
        }

        /// <remarks/>
        public string timestamp
        {
            get
            {
                return this.timestampField;
            }
            set
            {
                this.timestampField = value;
                this.RaisePropertyChanged("timestamp");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class GetSubscriptionsResp : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIResponseHeader headerField;

        private int errorCodeField;

        private string errorMessageField;

        private SubscriptionType[] subscriptionTypeItemsField;

        /// <remarks/>
        public APIResponseHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public int errorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
                this.RaisePropertyChanged("errorCode");
            }
        }

        /// <remarks/>
        public string errorMessage
        {
            get
            {
                return this.errorMessageField;
            }
            set
            {
                this.errorMessageField = value;
                this.RaisePropertyChanged("errorMessage");
            }
        }

        /// <remarks/>
        public SubscriptionType[] subscriptionTypeItems
        {
            get
            {
                return this.subscriptionTypeItemsField;
            }
            set
            {
                this.subscriptionTypeItemsField = value;
                this.RaisePropertyChanged("subscriptionTypeItems");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class GetSubscriptionsReq : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIRequestHeader headerField;

        private int mailingListIdField;

        private bool mailingListIdFieldSpecified;

        private string timestampSinceField;

        /// <remarks/>
        public APIRequestHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public int mailingListId
        {
            get
            {
                return this.mailingListIdField;
            }
            set
            {
                this.mailingListIdField = value;
                this.RaisePropertyChanged("mailingListId");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool mailingListIdSpecified
        {
            get
            {
                return this.mailingListIdFieldSpecified;
            }
            set
            {
                this.mailingListIdFieldSpecified = value;
                this.RaisePropertyChanged("mailingListIdSpecified");
            }
        }

        /// <remarks/>
        public string timestampSince
        {
            get
            {
                return this.timestampSinceField;
            }
            set
            {
                this.timestampSinceField = value;
                this.RaisePropertyChanged("timestampSince");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class UnsubscriptionType : object, System.ComponentModel.INotifyPropertyChanged
    {

        private int campaignIdField;

        private bool campaignIdFieldSpecified;

        private int emailAddressFlexmailIdField;

        private bool emailAddressFlexmailIdFieldSpecified;

        private string emailAddressReferenceIdField;

        private int emailAddressMailingListIdField;

        private bool emailAddressMailingListIdFieldSpecified;

        private EmailAddressType emailAddressTypeField;

        private int subListIdField;

        private bool subListIdFieldSpecified;

        private string timestampField;

        /// <remarks/>
        public int campaignId
        {
            get
            {
                return this.campaignIdField;
            }
            set
            {
                this.campaignIdField = value;
                this.RaisePropertyChanged("campaignId");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool campaignIdSpecified
        {
            get
            {
                return this.campaignIdFieldSpecified;
            }
            set
            {
                this.campaignIdFieldSpecified = value;
                this.RaisePropertyChanged("campaignIdSpecified");
            }
        }

        /// <remarks/>
        public int emailAddressFlexmailId
        {
            get
            {
                return this.emailAddressFlexmailIdField;
            }
            set
            {
                this.emailAddressFlexmailIdField = value;
                this.RaisePropertyChanged("emailAddressFlexmailId");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool emailAddressFlexmailIdSpecified
        {
            get
            {
                return this.emailAddressFlexmailIdFieldSpecified;
            }
            set
            {
                this.emailAddressFlexmailIdFieldSpecified = value;
                this.RaisePropertyChanged("emailAddressFlexmailIdSpecified");
            }
        }

        /// <remarks/>
        public string emailAddressReferenceId
        {
            get
            {
                return this.emailAddressReferenceIdField;
            }
            set
            {
                this.emailAddressReferenceIdField = value;
                this.RaisePropertyChanged("emailAddressReferenceId");
            }
        }

        /// <remarks/>
        public int emailAddressMailingListId
        {
            get
            {
                return this.emailAddressMailingListIdField;
            }
            set
            {
                this.emailAddressMailingListIdField = value;
                this.RaisePropertyChanged("emailAddressMailingListId");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool emailAddressMailingListIdSpecified
        {
            get
            {
                return this.emailAddressMailingListIdFieldSpecified;
            }
            set
            {
                this.emailAddressMailingListIdFieldSpecified = value;
                this.RaisePropertyChanged("emailAddressMailingListIdSpecified");
            }
        }

        /// <remarks/>
        public EmailAddressType emailAddressType
        {
            get
            {
                return this.emailAddressTypeField;
            }
            set
            {
                this.emailAddressTypeField = value;
                this.RaisePropertyChanged("emailAddressType");
            }
        }

        /// <remarks/>
        public int subListId
        {
            get
            {
                return this.subListIdField;
            }
            set
            {
                this.subListIdField = value;
                this.RaisePropertyChanged("subListId");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool subListIdSpecified
        {
            get
            {
                return this.subListIdFieldSpecified;
            }
            set
            {
                this.subListIdFieldSpecified = value;
                this.RaisePropertyChanged("subListIdSpecified");
            }
        }

        /// <remarks/>
        public string timestamp
        {
            get
            {
                return this.timestampField;
            }
            set
            {
                this.timestampField = value;
                this.RaisePropertyChanged("timestamp");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class GetUnsubscriptionsResp : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIResponseHeader headerField;

        private int errorCodeField;

        private string errorMessageField;

        private UnsubscriptionType[] unsubscriptionTypeItemsField;

        /// <remarks/>
        public APIResponseHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public int errorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
                this.RaisePropertyChanged("errorCode");
            }
        }

        /// <remarks/>
        public string errorMessage
        {
            get
            {
                return this.errorMessageField;
            }
            set
            {
                this.errorMessageField = value;
                this.RaisePropertyChanged("errorMessage");
            }
        }

        /// <remarks/>
        public UnsubscriptionType[] unsubscriptionTypeItems
        {
            get
            {
                return this.unsubscriptionTypeItemsField;
            }
            set
            {
                this.unsubscriptionTypeItemsField = value;
                this.RaisePropertyChanged("unsubscriptionTypeItems");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class GetUnsubscriptionsReq : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIRequestHeader headerField;

        private int mailingListIdField;

        private bool mailingListIdFieldSpecified;

        private int campaignIdField;

        private bool campaignIdFieldSpecified;

        private string timestampSinceField;

        private bool subListUnsubscriptionsField;

        private bool subListUnsubscriptionsFieldSpecified;

        /// <remarks/>
        public APIRequestHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public int mailingListId
        {
            get
            {
                return this.mailingListIdField;
            }
            set
            {
                this.mailingListIdField = value;
                this.RaisePropertyChanged("mailingListId");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool mailingListIdSpecified
        {
            get
            {
                return this.mailingListIdFieldSpecified;
            }
            set
            {
                this.mailingListIdFieldSpecified = value;
                this.RaisePropertyChanged("mailingListIdSpecified");
            }
        }

        /// <remarks/>
        public int campaignId
        {
            get
            {
                return this.campaignIdField;
            }
            set
            {
                this.campaignIdField = value;
                this.RaisePropertyChanged("campaignId");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool campaignIdSpecified
        {
            get
            {
                return this.campaignIdFieldSpecified;
            }
            set
            {
                this.campaignIdFieldSpecified = value;
                this.RaisePropertyChanged("campaignIdSpecified");
            }
        }

        /// <remarks/>
        public string timestampSince
        {
            get
            {
                return this.timestampSinceField;
            }
            set
            {
                this.timestampSinceField = value;
                this.RaisePropertyChanged("timestampSince");
            }
        }

        /// <remarks/>
        public bool subListUnsubscriptions
        {
            get
            {
                return this.subListUnsubscriptionsField;
            }
            set
            {
                this.subListUnsubscriptionsField = value;
                this.RaisePropertyChanged("subListUnsubscriptions");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool subListUnsubscriptionsSpecified
        {
            get
            {
                return this.subListUnsubscriptionsFieldSpecified;
            }
            set
            {
                this.subListUnsubscriptionsFieldSpecified = value;
                this.RaisePropertyChanged("subListUnsubscriptionsSpecified");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class BounceType : object, System.ComponentModel.INotifyPropertyChanged
    {

        private int campaignIdField;

        private bool campaignIdFieldSpecified;

        private int emailAddressFlexmailIdField;

        private bool emailAddressFlexmailIdFieldSpecified;

        private string emailAddressReferenceIdField;

        private int emailAddressMailingListIdField;

        private bool emailAddressMailingListIdFieldSpecified;

        private EmailAddressType emailAddressTypeField;

        private string timestampField;

        private string statusCodeField;

        private string statusMessageField;

        /// <remarks/>
        public int campaignId
        {
            get
            {
                return this.campaignIdField;
            }
            set
            {
                this.campaignIdField = value;
                this.RaisePropertyChanged("campaignId");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool campaignIdSpecified
        {
            get
            {
                return this.campaignIdFieldSpecified;
            }
            set
            {
                this.campaignIdFieldSpecified = value;
                this.RaisePropertyChanged("campaignIdSpecified");
            }
        }

        /// <remarks/>
        public int emailAddressFlexmailId
        {
            get
            {
                return this.emailAddressFlexmailIdField;
            }
            set
            {
                this.emailAddressFlexmailIdField = value;
                this.RaisePropertyChanged("emailAddressFlexmailId");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool emailAddressFlexmailIdSpecified
        {
            get
            {
                return this.emailAddressFlexmailIdFieldSpecified;
            }
            set
            {
                this.emailAddressFlexmailIdFieldSpecified = value;
                this.RaisePropertyChanged("emailAddressFlexmailIdSpecified");
            }
        }

        /// <remarks/>
        public string emailAddressReferenceId
        {
            get
            {
                return this.emailAddressReferenceIdField;
            }
            set
            {
                this.emailAddressReferenceIdField = value;
                this.RaisePropertyChanged("emailAddressReferenceId");
            }
        }

        /// <remarks/>
        public int emailAddressMailingListId
        {
            get
            {
                return this.emailAddressMailingListIdField;
            }
            set
            {
                this.emailAddressMailingListIdField = value;
                this.RaisePropertyChanged("emailAddressMailingListId");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool emailAddressMailingListIdSpecified
        {
            get
            {
                return this.emailAddressMailingListIdFieldSpecified;
            }
            set
            {
                this.emailAddressMailingListIdFieldSpecified = value;
                this.RaisePropertyChanged("emailAddressMailingListIdSpecified");
            }
        }

        /// <remarks/>
        public EmailAddressType emailAddressType
        {
            get
            {
                return this.emailAddressTypeField;
            }
            set
            {
                this.emailAddressTypeField = value;
                this.RaisePropertyChanged("emailAddressType");
            }
        }

        /// <remarks/>
        public string timestamp
        {
            get
            {
                return this.timestampField;
            }
            set
            {
                this.timestampField = value;
                this.RaisePropertyChanged("timestamp");
            }
        }

        /// <remarks/>
        public string statusCode
        {
            get
            {
                return this.statusCodeField;
            }
            set
            {
                this.statusCodeField = value;
                this.RaisePropertyChanged("statusCode");
            }
        }

        /// <remarks/>
        public string statusMessage
        {
            get
            {
                return this.statusMessageField;
            }
            set
            {
                this.statusMessageField = value;
                this.RaisePropertyChanged("statusMessage");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class GetBouncesResp : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIResponseHeader headerField;

        private int errorCodeField;

        private string errorMessageField;

        private BounceType[] bounceTypeItemsField;

        /// <remarks/>
        public APIResponseHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public int errorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
                this.RaisePropertyChanged("errorCode");
            }
        }

        /// <remarks/>
        public string errorMessage
        {
            get
            {
                return this.errorMessageField;
            }
            set
            {
                this.errorMessageField = value;
                this.RaisePropertyChanged("errorMessage");
            }
        }

        /// <remarks/>
        public BounceType[] bounceTypeItems
        {
            get
            {
                return this.bounceTypeItemsField;
            }
            set
            {
                this.bounceTypeItemsField = value;
                this.RaisePropertyChanged("bounceTypeItems");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class GetBouncesReq : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIRequestHeader headerField;

        private int mailingListIdField;

        private bool mailingListIdFieldSpecified;

        private int campaignIdField;

        private bool campaignIdFieldSpecified;

        private string timestampSinceField;

        /// <remarks/>
        public APIRequestHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public int mailingListId
        {
            get
            {
                return this.mailingListIdField;
            }
            set
            {
                this.mailingListIdField = value;
                this.RaisePropertyChanged("mailingListId");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool mailingListIdSpecified
        {
            get
            {
                return this.mailingListIdFieldSpecified;
            }
            set
            {
                this.mailingListIdFieldSpecified = value;
                this.RaisePropertyChanged("mailingListIdSpecified");
            }
        }

        /// <remarks/>
        public int campaignId
        {
            get
            {
                return this.campaignIdField;
            }
            set
            {
                this.campaignIdField = value;
                this.RaisePropertyChanged("campaignId");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool campaignIdSpecified
        {
            get
            {
                return this.campaignIdFieldSpecified;
            }
            set
            {
                this.campaignIdFieldSpecified = value;
                this.RaisePropertyChanged("campaignIdSpecified");
            }
        }

        /// <remarks/>
        public string timestampSince
        {
            get
            {
                return this.timestampSinceField;
            }
            set
            {
                this.timestampSinceField = value;
                this.RaisePropertyChanged("timestampSince");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class SendTestCampaignResp : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIResponseHeader headerField;

        private int errorCodeField;

        private string errorMessageField;

        /// <remarks/>
        public APIResponseHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public int errorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
                this.RaisePropertyChanged("errorCode");
            }
        }

        /// <remarks/>
        public string errorMessage
        {
            get
            {
                return this.errorMessageField;
            }
            set
            {
                this.errorMessageField = value;
                this.RaisePropertyChanged("errorMessage");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class TestCampaignType : object, System.ComponentModel.INotifyPropertyChanged
    {

        private string testCampaignNameField;

        private string testCampaignSubjectField;

        private string testCampaignSendToEmailAddressField;

        private string testCampaignSenderEmailAddressField;

        private string testCampaignSenderNameField;

        private string testCampaignReplyEmailAddressField;

        private int testCampaignMessageIdField;

        private bool testCampaignMessageIdFieldSpecified;

        /// <remarks/>
        public string testCampaignName
        {
            get
            {
                return this.testCampaignNameField;
            }
            set
            {
                this.testCampaignNameField = value;
                this.RaisePropertyChanged("testCampaignName");
            }
        }

        /// <remarks/>
        public string testCampaignSubject
        {
            get
            {
                return this.testCampaignSubjectField;
            }
            set
            {
                this.testCampaignSubjectField = value;
                this.RaisePropertyChanged("testCampaignSubject");
            }
        }

        /// <remarks/>
        public string testCampaignSendToEmailAddress
        {
            get
            {
                return this.testCampaignSendToEmailAddressField;
            }
            set
            {
                this.testCampaignSendToEmailAddressField = value;
                this.RaisePropertyChanged("testCampaignSendToEmailAddress");
            }
        }

        /// <remarks/>
        public string testCampaignSenderEmailAddress
        {
            get
            {
                return this.testCampaignSenderEmailAddressField;
            }
            set
            {
                this.testCampaignSenderEmailAddressField = value;
                this.RaisePropertyChanged("testCampaignSenderEmailAddress");
            }
        }

        /// <remarks/>
        public string testCampaignSenderName
        {
            get
            {
                return this.testCampaignSenderNameField;
            }
            set
            {
                this.testCampaignSenderNameField = value;
                this.RaisePropertyChanged("testCampaignSenderName");
            }
        }

        /// <remarks/>
        public string testCampaignReplyEmailAddress
        {
            get
            {
                return this.testCampaignReplyEmailAddressField;
            }
            set
            {
                this.testCampaignReplyEmailAddressField = value;
                this.RaisePropertyChanged("testCampaignReplyEmailAddress");
            }
        }

        /// <remarks/>
        public int testCampaignMessageId
        {
            get
            {
                return this.testCampaignMessageIdField;
            }
            set
            {
                this.testCampaignMessageIdField = value;
                this.RaisePropertyChanged("testCampaignMessageId");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool testCampaignMessageIdSpecified
        {
            get
            {
                return this.testCampaignMessageIdFieldSpecified;
            }
            set
            {
                this.testCampaignMessageIdFieldSpecified = value;
                this.RaisePropertyChanged("testCampaignMessageIdSpecified");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class SendTestCampaignReq : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIRequestHeader headerField;

        private TestCampaignType testCampaignTypeField;

        /// <remarks/>
        public APIRequestHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public TestCampaignType testCampaignType
        {
            get
            {
                return this.testCampaignTypeField;
            }
            set
            {
                this.testCampaignTypeField = value;
                this.RaisePropertyChanged("testCampaignType");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class SendCampaignResp : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIResponseHeader headerField;

        private int errorCodeField;

        private string errorMessageField;

        /// <remarks/>
        public APIResponseHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public int errorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
                this.RaisePropertyChanged("errorCode");
            }
        }

        /// <remarks/>
        public string errorMessage
        {
            get
            {
                return this.errorMessageField;
            }
            set
            {
                this.errorMessageField = value;
                this.RaisePropertyChanged("errorMessage");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class SendCampaignReq : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIRequestHeader headerField;

        private int campaignIdField;

        private string campaignSendTimestampField;

        /// <remarks/>
        public APIRequestHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public int campaignId
        {
            get
            {
                return this.campaignIdField;
            }
            set
            {
                this.campaignIdField = value;
                this.RaisePropertyChanged("campaignId");
            }
        }

        /// <remarks/>
        public string campaignSendTimestamp
        {
            get
            {
                return this.campaignSendTimestampField;
            }
            set
            {
                this.campaignSendTimestampField = value;
                this.RaisePropertyChanged("campaignSendTimestamp");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class GetCampaignsResp : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIResponseHeader headerField;

        private int errorCodeField;

        private string errorMessageField;

        private CampaignType[] campaignTypeItemsField;

        /// <remarks/>
        public APIResponseHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public int errorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
                this.RaisePropertyChanged("errorCode");
            }
        }

        /// <remarks/>
        public string errorMessage
        {
            get
            {
                return this.errorMessageField;
            }
            set
            {
                this.errorMessageField = value;
                this.RaisePropertyChanged("errorMessage");
            }
        }

        /// <remarks/>
        public CampaignType[] campaignTypeItems
        {
            get
            {
                return this.campaignTypeItemsField;
            }
            set
            {
                this.campaignTypeItemsField = value;
                this.RaisePropertyChanged("campaignTypeItems");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class CampaignType : object, System.ComponentModel.INotifyPropertyChanged
    {

        private int campaignIdField;

        private bool campaignIdFieldSpecified;

        private string campaignNameField;

        private int campaignSendStatusField;

        private bool campaignSendStatusFieldSpecified;

        private string campaignSendDateField;

        private string campaignSubjectField;

        private string campaignSenderEmailAddressField;

        private string campaignSenderNameField;

        private string campaignReplyEmailAddressField;

        private int campaignMessageIdField;

        private bool campaignMessageIdFieldSpecified;

        private int[] campaignMailingIdsField;

        private string[] campaignEmailAddressesField;

        private int[] campaignGroupIdsField;

        private int[] campaignPreferenceIdsField;

        private bool campaignIsAutoresponderField;

        private bool campaignIsAutoresponderFieldSpecified;

        private string campaignTypeField;

        /// <remarks/>
        public int campaignId
        {
            get
            {
                return this.campaignIdField;
            }
            set
            {
                this.campaignIdField = value;
                this.RaisePropertyChanged("campaignId");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool campaignIdSpecified
        {
            get
            {
                return this.campaignIdFieldSpecified;
            }
            set
            {
                this.campaignIdFieldSpecified = value;
                this.RaisePropertyChanged("campaignIdSpecified");
            }
        }

        /// <remarks/>
        public string campaignName
        {
            get
            {
                return this.campaignNameField;
            }
            set
            {
                this.campaignNameField = value;
                this.RaisePropertyChanged("campaignName");
            }
        }

        /// <remarks/>
        public int campaignSendStatus
        {
            get
            {
                return this.campaignSendStatusField;
            }
            set
            {
                this.campaignSendStatusField = value;
                this.RaisePropertyChanged("campaignSendStatus");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool campaignSendStatusSpecified
        {
            get
            {
                return this.campaignSendStatusFieldSpecified;
            }
            set
            {
                this.campaignSendStatusFieldSpecified = value;
                this.RaisePropertyChanged("campaignSendStatusSpecified");
            }
        }

        /// <remarks/>
        public string campaignSendDate
        {
            get
            {
                return this.campaignSendDateField;
            }
            set
            {
                this.campaignSendDateField = value;
                this.RaisePropertyChanged("campaignSendDate");
            }
        }

        /// <remarks/>
        public string campaignSubject
        {
            get
            {
                return this.campaignSubjectField;
            }
            set
            {
                this.campaignSubjectField = value;
                this.RaisePropertyChanged("campaignSubject");
            }
        }

        /// <remarks/>
        public string campaignSenderEmailAddress
        {
            get
            {
                return this.campaignSenderEmailAddressField;
            }
            set
            {
                this.campaignSenderEmailAddressField = value;
                this.RaisePropertyChanged("campaignSenderEmailAddress");
            }
        }

        /// <remarks/>
        public string campaignSenderName
        {
            get
            {
                return this.campaignSenderNameField;
            }
            set
            {
                this.campaignSenderNameField = value;
                this.RaisePropertyChanged("campaignSenderName");
            }
        }

        /// <remarks/>
        public string campaignReplyEmailAddress
        {
            get
            {
                return this.campaignReplyEmailAddressField;
            }
            set
            {
                this.campaignReplyEmailAddressField = value;
                this.RaisePropertyChanged("campaignReplyEmailAddress");
            }
        }

        /// <remarks/>
        public int campaignMessageId
        {
            get
            {
                return this.campaignMessageIdField;
            }
            set
            {
                this.campaignMessageIdField = value;
                this.RaisePropertyChanged("campaignMessageId");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool campaignMessageIdSpecified
        {
            get
            {
                return this.campaignMessageIdFieldSpecified;
            }
            set
            {
                this.campaignMessageIdFieldSpecified = value;
                this.RaisePropertyChanged("campaignMessageIdSpecified");
            }
        }

        /// <remarks/>
        public int[] campaignMailingIds
        {
            get
            {
                return this.campaignMailingIdsField;
            }
            set
            {
                this.campaignMailingIdsField = value;
                this.RaisePropertyChanged("campaignMailingIds");
            }
        }

        /// <remarks/>
        public string[] campaignEmailAddresses
        {
            get
            {
                return this.campaignEmailAddressesField;
            }
            set
            {
                this.campaignEmailAddressesField = value;
                this.RaisePropertyChanged("campaignEmailAddresses");
            }
        }

        /// <remarks/>
        public int[] campaignGroupIds
        {
            get
            {
                return this.campaignGroupIdsField;
            }
            set
            {
                this.campaignGroupIdsField = value;
                this.RaisePropertyChanged("campaignGroupIds");
            }
        }

        /// <remarks/>
        public int[] campaignPreferenceIds
        {
            get
            {
                return this.campaignPreferenceIdsField;
            }
            set
            {
                this.campaignPreferenceIdsField = value;
                this.RaisePropertyChanged("campaignPreferenceIds");
            }
        }

        /// <remarks/>
        public bool campaignIsAutoresponder
        {
            get
            {
                return this.campaignIsAutoresponderField;
            }
            set
            {
                this.campaignIsAutoresponderField = value;
                this.RaisePropertyChanged("campaignIsAutoresponder");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool campaignIsAutoresponderSpecified
        {
            get
            {
                return this.campaignIsAutoresponderFieldSpecified;
            }
            set
            {
                this.campaignIsAutoresponderFieldSpecified = value;
                this.RaisePropertyChanged("campaignIsAutoresponderSpecified");
            }
        }

        /// <remarks/>
        public string campaignType
        {
            get
            {
                return this.campaignTypeField;
            }
            set
            {
                this.campaignTypeField = value;
                this.RaisePropertyChanged("campaignType");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class GetCampaignsReq : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIRequestHeader headerField;

        private campaignTypeType typeField;

        private bool typeFieldSpecified;

        /// <remarks/>
        public APIRequestHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public campaignTypeType type
        {
            get
            {
                return this.typeField;
            }
            set
            {
                this.typeField = value;
                this.RaisePropertyChanged("type");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool typeSpecified
        {
            get
            {
                return this.typeFieldSpecified;
            }
            set
            {
                this.typeFieldSpecified = value;
                this.RaisePropertyChanged("typeSpecified");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public enum campaignTypeType
    {

        /// <remarks/>
        Campaign,

        /// <remarks/>
        TestCampaign,

        /// <remarks/>
        Workflow,
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class DeleteCampaignResp : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIResponseHeader headerField;

        private int errorCodeField;

        private string errorMessageField;

        /// <remarks/>
        public APIResponseHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public int errorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
                this.RaisePropertyChanged("errorCode");
            }
        }

        /// <remarks/>
        public string errorMessage
        {
            get
            {
                return this.errorMessageField;
            }
            set
            {
                this.errorMessageField = value;
                this.RaisePropertyChanged("errorMessage");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class DeleteCampaignReq : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIRequestHeader headerField;

        private CampaignType campaignTypeField;

        /// <remarks/>
        public APIRequestHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public CampaignType campaignType
        {
            get
            {
                return this.campaignTypeField;
            }
            set
            {
                this.campaignTypeField = value;
                this.RaisePropertyChanged("campaignType");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class UpdateCampaignResp : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIResponseHeader headerField;

        private int errorCodeField;

        private string errorMessageField;

        /// <remarks/>
        public APIResponseHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public int errorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
                this.RaisePropertyChanged("errorCode");
            }
        }

        /// <remarks/>
        public string errorMessage
        {
            get
            {
                return this.errorMessageField;
            }
            set
            {
                this.errorMessageField = value;
                this.RaisePropertyChanged("errorMessage");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class UpdateCampaignReq : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIRequestHeader headerField;

        private CampaignType campaignTypeField;

        /// <remarks/>
        public APIRequestHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public CampaignType campaignType
        {
            get
            {
                return this.campaignTypeField;
            }
            set
            {
                this.campaignTypeField = value;
                this.RaisePropertyChanged("campaignType");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class CreateCampaignResp : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIResponseHeader headerField;

        private int errorCodeField;

        private string errorMessageField;

        private int campaignIdField;

        /// <remarks/>
        public APIResponseHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public int errorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
                this.RaisePropertyChanged("errorCode");
            }
        }

        /// <remarks/>
        public string errorMessage
        {
            get
            {
                return this.errorMessageField;
            }
            set
            {
                this.errorMessageField = value;
                this.RaisePropertyChanged("errorMessage");
            }
        }

        /// <remarks/>
        public int campaignId
        {
            get
            {
                return this.campaignIdField;
            }
            set
            {
                this.campaignIdField = value;
                this.RaisePropertyChanged("campaignId");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class CreateCampaignReq : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIRequestHeader headerField;

        private CampaignType campaignTypeField;

        /// <remarks/>
        public APIRequestHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public CampaignType campaignType
        {
            get
            {
                return this.campaignTypeField;
            }
            set
            {
                this.campaignTypeField = value;
                this.RaisePropertyChanged("campaignType");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class DeleteGroupSubscriptionResp : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIResponseHeader headerField;

        private int errorCodeField;

        private string errorMessageField;

        /// <remarks/>
        public APIResponseHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public int errorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
                this.RaisePropertyChanged("errorCode");
            }
        }

        /// <remarks/>
        public string errorMessage
        {
            get
            {
                return this.errorMessageField;
            }
            set
            {
                this.errorMessageField = value;
                this.RaisePropertyChanged("errorMessage");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class DeleteGroupSubscriptionReq : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIRequestHeader headerField;

        private GroupSubscriptionType groupSubscriptionTypeField;

        /// <remarks/>
        public APIRequestHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public GroupSubscriptionType groupSubscriptionType
        {
            get
            {
                return this.groupSubscriptionTypeField;
            }
            set
            {
                this.groupSubscriptionTypeField = value;
                this.RaisePropertyChanged("groupSubscriptionType");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class GroupSubscriptionType : object, System.ComponentModel.INotifyPropertyChanged
    {

        private int groupSubscriptionIdField;

        private bool groupSubscriptionIdFieldSpecified;

        private int groupIdField;

        private bool groupIdFieldSpecified;

        private int emailAddressFlexmailIdField;

        private bool emailAddressFlexmailIdFieldSpecified;

        private string emailAddressReferenceIdField;

        private int emailAddressMailingListIdField;

        private bool emailAddressMailingListIdFieldSpecified;

        private int errorCodeField;

        private bool errorCodeFieldSpecified;

        private string errorMessageField;

        /// <remarks/>
        public int groupSubscriptionId
        {
            get
            {
                return this.groupSubscriptionIdField;
            }
            set
            {
                this.groupSubscriptionIdField = value;
                this.RaisePropertyChanged("groupSubscriptionId");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool groupSubscriptionIdSpecified
        {
            get
            {
                return this.groupSubscriptionIdFieldSpecified;
            }
            set
            {
                this.groupSubscriptionIdFieldSpecified = value;
                this.RaisePropertyChanged("groupSubscriptionIdSpecified");
            }
        }

        /// <remarks/>
        public int groupId
        {
            get
            {
                return this.groupIdField;
            }
            set
            {
                this.groupIdField = value;
                this.RaisePropertyChanged("groupId");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool groupIdSpecified
        {
            get
            {
                return this.groupIdFieldSpecified;
            }
            set
            {
                this.groupIdFieldSpecified = value;
                this.RaisePropertyChanged("groupIdSpecified");
            }
        }

        /// <remarks/>
        public int emailAddressFlexmailId
        {
            get
            {
                return this.emailAddressFlexmailIdField;
            }
            set
            {
                this.emailAddressFlexmailIdField = value;
                this.RaisePropertyChanged("emailAddressFlexmailId");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool emailAddressFlexmailIdSpecified
        {
            get
            {
                return this.emailAddressFlexmailIdFieldSpecified;
            }
            set
            {
                this.emailAddressFlexmailIdFieldSpecified = value;
                this.RaisePropertyChanged("emailAddressFlexmailIdSpecified");
            }
        }

        /// <remarks/>
        public string emailAddressReferenceId
        {
            get
            {
                return this.emailAddressReferenceIdField;
            }
            set
            {
                this.emailAddressReferenceIdField = value;
                this.RaisePropertyChanged("emailAddressReferenceId");
            }
        }

        /// <remarks/>
        public int emailAddressMailingListId
        {
            get
            {
                return this.emailAddressMailingListIdField;
            }
            set
            {
                this.emailAddressMailingListIdField = value;
                this.RaisePropertyChanged("emailAddressMailingListId");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool emailAddressMailingListIdSpecified
        {
            get
            {
                return this.emailAddressMailingListIdFieldSpecified;
            }
            set
            {
                this.emailAddressMailingListIdFieldSpecified = value;
                this.RaisePropertyChanged("emailAddressMailingListIdSpecified");
            }
        }

        /// <remarks/>
        public int errorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
                this.RaisePropertyChanged("errorCode");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool errorCodeSpecified
        {
            get
            {
                return this.errorCodeFieldSpecified;
            }
            set
            {
                this.errorCodeFieldSpecified = value;
                this.RaisePropertyChanged("errorCodeSpecified");
            }
        }

        /// <remarks/>
        public string errorMessage
        {
            get
            {
                return this.errorMessageField;
            }
            set
            {
                this.errorMessageField = value;
                this.RaisePropertyChanged("errorMessage");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class CreateGroupSubscriptionResp : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIResponseHeader headerField;

        private int errorCodeField;

        private string errorMessageField;

        private int groupSubscriptionIdField;

        /// <remarks/>
        public APIResponseHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public int errorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
                this.RaisePropertyChanged("errorCode");
            }
        }

        /// <remarks/>
        public string errorMessage
        {
            get
            {
                return this.errorMessageField;
            }
            set
            {
                this.errorMessageField = value;
                this.RaisePropertyChanged("errorMessage");
            }
        }

        /// <remarks/>
        public int groupSubscriptionId
        {
            get
            {
                return this.groupSubscriptionIdField;
            }
            set
            {
                this.groupSubscriptionIdField = value;
                this.RaisePropertyChanged("groupSubscriptionId");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class CreateGroupSubscriptionReq : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIRequestHeader headerField;

        private GroupSubscriptionType groupSubscriptionTypeField;

        /// <remarks/>
        public APIRequestHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public GroupSubscriptionType groupSubscriptionType
        {
            get
            {
                return this.groupSubscriptionTypeField;
            }
            set
            {
                this.groupSubscriptionTypeField = value;
                this.RaisePropertyChanged("groupSubscriptionType");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class ImportGroupSubscriptionsResp : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIResponseHeader headerField;

        private GroupSubscriptionType[] groupSubscriptionTypeItemsField;

        /// <remarks/>
        public APIResponseHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public GroupSubscriptionType[] groupSubscriptionTypeItems
        {
            get
            {
                return this.groupSubscriptionTypeItemsField;
            }
            set
            {
                this.groupSubscriptionTypeItemsField = value;
                this.RaisePropertyChanged("groupSubscriptionTypeItems");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class ImportGroupSubscriptionsReq : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIRequestHeader headerField;

        private GroupSubscriptionType[] groupSubscriptionTypeItemsField;

        /// <remarks/>
        public APIRequestHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public GroupSubscriptionType[] groupSubscriptionTypeItems
        {
            get
            {
                return this.groupSubscriptionTypeItemsField;
            }
            set
            {
                this.groupSubscriptionTypeItemsField = value;
                this.RaisePropertyChanged("groupSubscriptionTypeItems");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class GetGroupsResp : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIResponseHeader headerField;

        private int errorCodeField;

        private string errorMessageField;

        private GroupType[] groupTypeItemsField;

        /// <remarks/>
        public APIResponseHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public int errorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
                this.RaisePropertyChanged("errorCode");
            }
        }

        /// <remarks/>
        public string errorMessage
        {
            get
            {
                return this.errorMessageField;
            }
            set
            {
                this.errorMessageField = value;
                this.RaisePropertyChanged("errorMessage");
            }
        }

        /// <remarks/>
        public GroupType[] groupTypeItems
        {
            get
            {
                return this.groupTypeItemsField;
            }
            set
            {
                this.groupTypeItemsField = value;
                this.RaisePropertyChanged("groupTypeItems");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class GroupType : object, System.ComponentModel.INotifyPropertyChanged
    {

        private int groupIdField;

        private bool groupIdFieldSpecified;

        private string groupNameField;

        /// <remarks/>
        public int groupId
        {
            get
            {
                return this.groupIdField;
            }
            set
            {
                this.groupIdField = value;
                this.RaisePropertyChanged("groupId");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool groupIdSpecified
        {
            get
            {
                return this.groupIdFieldSpecified;
            }
            set
            {
                this.groupIdFieldSpecified = value;
                this.RaisePropertyChanged("groupIdSpecified");
            }
        }

        /// <remarks/>
        public string groupName
        {
            get
            {
                return this.groupNameField;
            }
            set
            {
                this.groupNameField = value;
                this.RaisePropertyChanged("groupName");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class GetGroupsReq : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIRequestHeader headerField;

        /// <remarks/>
        public APIRequestHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class DeleteGroupResp : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIResponseHeader headerField;

        private int errorCodeField;

        private string errorMessageField;

        /// <remarks/>
        public APIResponseHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public int errorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
                this.RaisePropertyChanged("errorCode");
            }
        }

        /// <remarks/>
        public string errorMessage
        {
            get
            {
                return this.errorMessageField;
            }
            set
            {
                this.errorMessageField = value;
                this.RaisePropertyChanged("errorMessage");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class DeleteGroupReq : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIRequestHeader headerField;

        private GroupType groupTypeField;

        /// <remarks/>
        public APIRequestHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public GroupType groupType
        {
            get
            {
                return this.groupTypeField;
            }
            set
            {
                this.groupTypeField = value;
                this.RaisePropertyChanged("groupType");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class UpdateGroupResp : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIResponseHeader headerField;

        private int errorCodeField;

        private string errorMessageField;

        /// <remarks/>
        public APIResponseHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public int errorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
                this.RaisePropertyChanged("errorCode");
            }
        }

        /// <remarks/>
        public string errorMessage
        {
            get
            {
                return this.errorMessageField;
            }
            set
            {
                this.errorMessageField = value;
                this.RaisePropertyChanged("errorMessage");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class UpdateGroupReq : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIRequestHeader headerField;

        private GroupType groupTypeField;

        /// <remarks/>
        public APIRequestHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public GroupType groupType
        {
            get
            {
                return this.groupTypeField;
            }
            set
            {
                this.groupTypeField = value;
                this.RaisePropertyChanged("groupType");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class CreateGroupResp : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIResponseHeader headerField;

        private int errorCodeField;

        private string errorMessageField;

        private int groupIdField;

        /// <remarks/>
        public APIResponseHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public int errorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
                this.RaisePropertyChanged("errorCode");
            }
        }

        /// <remarks/>
        public string errorMessage
        {
            get
            {
                return this.errorMessageField;
            }
            set
            {
                this.errorMessageField = value;
                this.RaisePropertyChanged("errorMessage");
            }
        }

        /// <remarks/>
        public int groupId
        {
            get
            {
                return this.groupIdField;
            }
            set
            {
                this.groupIdField = value;
                this.RaisePropertyChanged("groupId");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class CreateGroupReq : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIRequestHeader headerField;

        private GroupType groupTypeField;

        /// <remarks/>
        public APIRequestHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public GroupType groupType
        {
            get
            {
                return this.groupTypeField;
            }
            set
            {
                this.groupTypeField = value;
                this.RaisePropertyChanged("groupType");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class GetPreferencesResp : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIResponseHeader headerField;

        private int errorCodeField;

        private string errorMessageField;

        private PreferenceType[] preferenceTypeItemsField;

        /// <remarks/>
        public APIResponseHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public int errorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
                this.RaisePropertyChanged("errorCode");
            }
        }

        /// <remarks/>
        public string errorMessage
        {
            get
            {
                return this.errorMessageField;
            }
            set
            {
                this.errorMessageField = value;
                this.RaisePropertyChanged("errorMessage");
            }
        }

        /// <remarks/>
        public PreferenceType[] preferenceTypeItems
        {
            get
            {
                return this.preferenceTypeItemsField;
            }
            set
            {
                this.preferenceTypeItemsField = value;
                this.RaisePropertyChanged("preferenceTypeItems");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class PreferenceType : object, System.ComponentModel.INotifyPropertyChanged
    {

        private int preferenceIdField;

        private bool preferenceIdFieldSpecified;

        private string preferenceNameField;

        private string preferenceLabelField;

        private string preferenceDescriptionField;

        /// <remarks/>
        public int preferenceId
        {
            get
            {
                return this.preferenceIdField;
            }
            set
            {
                this.preferenceIdField = value;
                this.RaisePropertyChanged("preferenceId");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool preferenceIdSpecified
        {
            get
            {
                return this.preferenceIdFieldSpecified;
            }
            set
            {
                this.preferenceIdFieldSpecified = value;
                this.RaisePropertyChanged("preferenceIdSpecified");
            }
        }

        /// <remarks/>
        public string preferenceName
        {
            get
            {
                return this.preferenceNameField;
            }
            set
            {
                this.preferenceNameField = value;
                this.RaisePropertyChanged("preferenceName");
            }
        }

        /// <remarks/>
        public string preferenceLabel
        {
            get
            {
                return this.preferenceLabelField;
            }
            set
            {
                this.preferenceLabelField = value;
                this.RaisePropertyChanged("preferenceLabel");
            }
        }

        /// <remarks/>
        public string preferenceDescription
        {
            get
            {
                return this.preferenceDescriptionField;
            }
            set
            {
                this.preferenceDescriptionField = value;
                this.RaisePropertyChanged("preferenceDescription");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class GetPreferencesReq : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIRequestHeader headerField;

        /// <remarks/>
        public APIRequestHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class DeletePreferenceResp : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIResponseHeader headerField;

        private int errorCodeField;

        private string errorMessageField;

        /// <remarks/>
        public APIResponseHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public int errorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
                this.RaisePropertyChanged("errorCode");
            }
        }

        /// <remarks/>
        public string errorMessage
        {
            get
            {
                return this.errorMessageField;
            }
            set
            {
                this.errorMessageField = value;
                this.RaisePropertyChanged("errorMessage");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class DeletePreferenceReq : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIRequestHeader headerField;

        private PreferenceType preferenceTypeField;

        /// <remarks/>
        public APIRequestHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public PreferenceType preferenceType
        {
            get
            {
                return this.preferenceTypeField;
            }
            set
            {
                this.preferenceTypeField = value;
                this.RaisePropertyChanged("preferenceType");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class UpdatePreferenceResp : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIResponseHeader headerField;

        private int errorCodeField;

        private string errorMessageField;

        /// <remarks/>
        public APIResponseHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public int errorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
                this.RaisePropertyChanged("errorCode");
            }
        }

        /// <remarks/>
        public string errorMessage
        {
            get
            {
                return this.errorMessageField;
            }
            set
            {
                this.errorMessageField = value;
                this.RaisePropertyChanged("errorMessage");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class UpdatePreferenceReq : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIRequestHeader headerField;

        private PreferenceType preferenceTypeField;

        /// <remarks/>
        public APIRequestHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public PreferenceType preferenceType
        {
            get
            {
                return this.preferenceTypeField;
            }
            set
            {
                this.preferenceTypeField = value;
                this.RaisePropertyChanged("preferenceType");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class CreatePreferenceResp : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIResponseHeader headerField;

        private int errorCodeField;

        private string errorMessageField;

        private int preferenceIdField;

        /// <remarks/>
        public APIResponseHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public int errorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
                this.RaisePropertyChanged("errorCode");
            }
        }

        /// <remarks/>
        public string errorMessage
        {
            get
            {
                return this.errorMessageField;
            }
            set
            {
                this.errorMessageField = value;
                this.RaisePropertyChanged("errorMessage");
            }
        }

        /// <remarks/>
        public int preferenceId
        {
            get
            {
                return this.preferenceIdField;
            }
            set
            {
                this.preferenceIdField = value;
                this.RaisePropertyChanged("preferenceId");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class CreatePreferenceReq : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIRequestHeader headerField;

        private PreferenceType preferenceTypeField;

        /// <remarks/>
        public APIRequestHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public PreferenceType preferenceType
        {
            get
            {
                return this.preferenceTypeField;
            }
            set
            {
                this.preferenceTypeField = value;
                this.RaisePropertyChanged("preferenceType");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class GetTemplatesResp : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIResponseHeader headerField;

        private int errorCodeField;

        private string errorMessageField;

        private TemplateType[] templateTypeItemsField;

        /// <remarks/>
        public APIResponseHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public int errorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
                this.RaisePropertyChanged("errorCode");
            }
        }

        /// <remarks/>
        public string errorMessage
        {
            get
            {
                return this.errorMessageField;
            }
            set
            {
                this.errorMessageField = value;
                this.RaisePropertyChanged("errorMessage");
            }
        }

        /// <remarks/>
        public TemplateType[] templateTypeItems
        {
            get
            {
                return this.templateTypeItemsField;
            }
            set
            {
                this.templateTypeItemsField = value;
                this.RaisePropertyChanged("templateTypeItems");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class TemplateType : object, System.ComponentModel.INotifyPropertyChanged
    {

        private int templateIdField;

        private bool templateIdFieldSpecified;

        private string templateNameField;

        private string templateTextField;

        private string templateXmlField;

        private string templateTypeField;

        /// <remarks/>
        public int templateId
        {
            get
            {
                return this.templateIdField;
            }
            set
            {
                this.templateIdField = value;
                this.RaisePropertyChanged("templateId");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool templateIdSpecified
        {
            get
            {
                return this.templateIdFieldSpecified;
            }
            set
            {
                this.templateIdFieldSpecified = value;
                this.RaisePropertyChanged("templateIdSpecified");
            }
        }

        /// <remarks/>
        public string templateName
        {
            get
            {
                return this.templateNameField;
            }
            set
            {
                this.templateNameField = value;
                this.RaisePropertyChanged("templateName");
            }
        }

        /// <remarks/>
        public string templateText
        {
            get
            {
                return this.templateTextField;
            }
            set
            {
                this.templateTextField = value;
                this.RaisePropertyChanged("templateText");
            }
        }

        /// <remarks/>
        public string templateXml
        {
            get
            {
                return this.templateXmlField;
            }
            set
            {
                this.templateXmlField = value;
                this.RaisePropertyChanged("templateXml");
            }
        }

        /// <remarks/>
        public string templateType
        {
            get
            {
                return this.templateTypeField;
            }
            set
            {
                this.templateTypeField = value;
                this.RaisePropertyChanged("templateType");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class GetTemplatesReq : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIRequestHeader headerField;

        private TemplateType templateTypeField;

        /// <remarks/>
        public APIRequestHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public TemplateType templateType
        {
            get
            {
                return this.templateTypeField;
            }
            set
            {
                this.templateTypeField = value;
                this.RaisePropertyChanged("templateType");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class DeleteTemplateResp : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIResponseHeader headerField;

        private int errorCodeField;

        private string errorMessageField;

        /// <remarks/>
        public APIResponseHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public int errorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
                this.RaisePropertyChanged("errorCode");
            }
        }

        /// <remarks/>
        public string errorMessage
        {
            get
            {
                return this.errorMessageField;
            }
            set
            {
                this.errorMessageField = value;
                this.RaisePropertyChanged("errorMessage");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class DeleteTemplateReq : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIRequestHeader headerField;

        private TemplateType templateTypeField;

        /// <remarks/>
        public APIRequestHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public TemplateType templateType
        {
            get
            {
                return this.templateTypeField;
            }
            set
            {
                this.templateTypeField = value;
                this.RaisePropertyChanged("templateType");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class UpdateTemplateResp : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIResponseHeader headerField;

        private int errorCodeField;

        private string errorMessageField;

        /// <remarks/>
        public APIResponseHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public int errorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
                this.RaisePropertyChanged("errorCode");
            }
        }

        /// <remarks/>
        public string errorMessage
        {
            get
            {
                return this.errorMessageField;
            }
            set
            {
                this.errorMessageField = value;
                this.RaisePropertyChanged("errorMessage");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class UpdateTemplateReq : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIRequestHeader headerField;

        private TemplateType templateTypeField;

        /// <remarks/>
        public APIRequestHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public TemplateType templateType
        {
            get
            {
                return this.templateTypeField;
            }
            set
            {
                this.templateTypeField = value;
                this.RaisePropertyChanged("templateType");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class CreateTemplateResp : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIResponseHeader headerField;

        private int errorCodeField;

        private string errorMessageField;

        private int templateIdField;

        /// <remarks/>
        public APIResponseHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public int errorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
                this.RaisePropertyChanged("errorCode");
            }
        }

        /// <remarks/>
        public string errorMessage
        {
            get
            {
                return this.errorMessageField;
            }
            set
            {
                this.errorMessageField = value;
                this.RaisePropertyChanged("errorMessage");
            }
        }

        /// <remarks/>
        public int templateId
        {
            get
            {
                return this.templateIdField;
            }
            set
            {
                this.templateIdField = value;
                this.RaisePropertyChanged("templateId");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class CreateTemplateReq : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIRequestHeader headerField;

        private TemplateType templateTypeField;

        /// <remarks/>
        public APIRequestHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public TemplateType templateType
        {
            get
            {
                return this.templateTypeField;
            }
            set
            {
                this.templateTypeField = value;
                this.RaisePropertyChanged("templateType");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class GetLandingPagesResp : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIResponseHeader headerField;

        private int errorCodeField;

        private string errorMessageField;

        private LandingPageType[] landingPageTypeItemsField;

        /// <remarks/>
        public APIResponseHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public int errorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
                this.RaisePropertyChanged("errorCode");
            }
        }

        /// <remarks/>
        public string errorMessage
        {
            get
            {
                return this.errorMessageField;
            }
            set
            {
                this.errorMessageField = value;
                this.RaisePropertyChanged("errorMessage");
            }
        }

        /// <remarks/>
        public LandingPageType[] landingPageTypeItems
        {
            get
            {
                return this.landingPageTypeItemsField;
            }
            set
            {
                this.landingPageTypeItemsField = value;
                this.RaisePropertyChanged("landingPageTypeItems");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class LandingPageType : object, System.ComponentModel.INotifyPropertyChanged
    {

        private int landingPageIdField;

        private bool landingPageIdFieldSpecified;

        private string landingPageNameField;

        private string landingPageTextField;

        private string landingPageCreationDateField;

        private int landingPageViewsField;

        private bool landingPageViewsFieldSpecified;

        /// <remarks/>
        public int landingPageId
        {
            get
            {
                return this.landingPageIdField;
            }
            set
            {
                this.landingPageIdField = value;
                this.RaisePropertyChanged("landingPageId");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool landingPageIdSpecified
        {
            get
            {
                return this.landingPageIdFieldSpecified;
            }
            set
            {
                this.landingPageIdFieldSpecified = value;
                this.RaisePropertyChanged("landingPageIdSpecified");
            }
        }

        /// <remarks/>
        public string landingPageName
        {
            get
            {
                return this.landingPageNameField;
            }
            set
            {
                this.landingPageNameField = value;
                this.RaisePropertyChanged("landingPageName");
            }
        }

        /// <remarks/>
        public string landingPageText
        {
            get
            {
                return this.landingPageTextField;
            }
            set
            {
                this.landingPageTextField = value;
                this.RaisePropertyChanged("landingPageText");
            }
        }

        /// <remarks/>
        public string landingPageCreationDate
        {
            get
            {
                return this.landingPageCreationDateField;
            }
            set
            {
                this.landingPageCreationDateField = value;
                this.RaisePropertyChanged("landingPageCreationDate");
            }
        }

        /// <remarks/>
        public int landingPageViews
        {
            get
            {
                return this.landingPageViewsField;
            }
            set
            {
                this.landingPageViewsField = value;
                this.RaisePropertyChanged("landingPageViews");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool landingPageViewsSpecified
        {
            get
            {
                return this.landingPageViewsFieldSpecified;
            }
            set
            {
                this.landingPageViewsFieldSpecified = value;
                this.RaisePropertyChanged("landingPageViewsSpecified");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class GetLandingPagesReq : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIRequestHeader headerField;

        /// <remarks/>
        public APIRequestHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class DeleteLandingPageResp : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIResponseHeader headerField;

        private int errorCodeField;

        private string errorMessageField;

        /// <remarks/>
        public APIResponseHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public int errorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
                this.RaisePropertyChanged("errorCode");
            }
        }

        /// <remarks/>
        public string errorMessage
        {
            get
            {
                return this.errorMessageField;
            }
            set
            {
                this.errorMessageField = value;
                this.RaisePropertyChanged("errorMessage");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class DeleteLandingPageReq : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIRequestHeader headerField;

        private LandingPageType landingPageTypeField;

        /// <remarks/>
        public APIRequestHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public LandingPageType landingPageType
        {
            get
            {
                return this.landingPageTypeField;
            }
            set
            {
                this.landingPageTypeField = value;
                this.RaisePropertyChanged("landingPageType");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class UpdateLandingPageResp : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIResponseHeader headerField;

        private int errorCodeField;

        private string errorMessageField;

        /// <remarks/>
        public APIResponseHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public int errorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
                this.RaisePropertyChanged("errorCode");
            }
        }

        /// <remarks/>
        public string errorMessage
        {
            get
            {
                return this.errorMessageField;
            }
            set
            {
                this.errorMessageField = value;
                this.RaisePropertyChanged("errorMessage");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class UpdateLandingPageReq : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIRequestHeader headerField;

        private LandingPageType landingPageTypeField;

        /// <remarks/>
        public APIRequestHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public LandingPageType landingPageType
        {
            get
            {
                return this.landingPageTypeField;
            }
            set
            {
                this.landingPageTypeField = value;
                this.RaisePropertyChanged("landingPageType");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class CreateLandingPageResp : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIResponseHeader headerField;

        private int errorCodeField;

        private string errorMessageField;

        private int landingPageIdField;

        /// <remarks/>
        public APIResponseHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public int errorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
                this.RaisePropertyChanged("errorCode");
            }
        }

        /// <remarks/>
        public string errorMessage
        {
            get
            {
                return this.errorMessageField;
            }
            set
            {
                this.errorMessageField = value;
                this.RaisePropertyChanged("errorMessage");
            }
        }

        /// <remarks/>
        public int landingPageId
        {
            get
            {
                return this.landingPageIdField;
            }
            set
            {
                this.landingPageIdField = value;
                this.RaisePropertyChanged("landingPageId");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class CreateLandingPageReq : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIRequestHeader headerField;

        private LandingPageType landingPageTypeField;

        /// <remarks/>
        public APIRequestHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public LandingPageType landingPageType
        {
            get
            {
                return this.landingPageTypeField;
            }
            set
            {
                this.landingPageTypeField = value;
                this.RaisePropertyChanged("landingPageType");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class GetMessagesResp : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIResponseHeader headerField;

        private int errorCodeField;

        private string errorMessageField;

        private MessageType[] messageTypeItemsField;

        /// <remarks/>
        public APIResponseHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public int errorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
                this.RaisePropertyChanged("errorCode");
            }
        }

        /// <remarks/>
        public string errorMessage
        {
            get
            {
                return this.errorMessageField;
            }
            set
            {
                this.errorMessageField = value;
                this.RaisePropertyChanged("errorMessage");
            }
        }

        /// <remarks/>
        public MessageType[] messageTypeItems
        {
            get
            {
                return this.messageTypeItemsField;
            }
            set
            {
                this.messageTypeItemsField = value;
                this.RaisePropertyChanged("messageTypeItems");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class MessageType : object, System.ComponentModel.INotifyPropertyChanged
    {

        private int messageIdField;

        private bool messageIdFieldSpecified;

        private string messageNameField;

        private string messageTextField;

        private string messageTextMessageField;

        private string messageTypeField;

        private string messageCreationDateField;

        private int messageArchivedField;

        private bool messageArchivedFieldSpecified;

        private int messageTemplateIdField;

        private bool messageTemplateIdFieldSpecified;

        private string messageTemplateDataField;

        private int messageWizardTemplateIdField;

        private bool messageWizardTemplateIdFieldSpecified;

        private string messageWizardTemplateDataField;

        private string messageWebLinkField;

        /// <remarks/>
        public int messageId
        {
            get
            {
                return this.messageIdField;
            }
            set
            {
                this.messageIdField = value;
                this.RaisePropertyChanged("messageId");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool messageIdSpecified
        {
            get
            {
                return this.messageIdFieldSpecified;
            }
            set
            {
                this.messageIdFieldSpecified = value;
                this.RaisePropertyChanged("messageIdSpecified");
            }
        }

        /// <remarks/>
        public string messageName
        {
            get
            {
                return this.messageNameField;
            }
            set
            {
                this.messageNameField = value;
                this.RaisePropertyChanged("messageName");
            }
        }

        /// <remarks/>
        public string messageText
        {
            get
            {
                return this.messageTextField;
            }
            set
            {
                this.messageTextField = value;
                this.RaisePropertyChanged("messageText");
            }
        }

        /// <remarks/>
        public string messageTextMessage
        {
            get
            {
                return this.messageTextMessageField;
            }
            set
            {
                this.messageTextMessageField = value;
                this.RaisePropertyChanged("messageTextMessage");
            }
        }

        /// <remarks/>
        public string messageType
        {
            get
            {
                return this.messageTypeField;
            }
            set
            {
                this.messageTypeField = value;
                this.RaisePropertyChanged("messageType");
            }
        }

        /// <remarks/>
        public string messageCreationDate
        {
            get
            {
                return this.messageCreationDateField;
            }
            set
            {
                this.messageCreationDateField = value;
                this.RaisePropertyChanged("messageCreationDate");
            }
        }

        /// <remarks/>
        public int messageArchived
        {
            get
            {
                return this.messageArchivedField;
            }
            set
            {
                this.messageArchivedField = value;
                this.RaisePropertyChanged("messageArchived");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool messageArchivedSpecified
        {
            get
            {
                return this.messageArchivedFieldSpecified;
            }
            set
            {
                this.messageArchivedFieldSpecified = value;
                this.RaisePropertyChanged("messageArchivedSpecified");
            }
        }

        /// <remarks/>
        public int messageTemplateId
        {
            get
            {
                return this.messageTemplateIdField;
            }
            set
            {
                this.messageTemplateIdField = value;
                this.RaisePropertyChanged("messageTemplateId");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool messageTemplateIdSpecified
        {
            get
            {
                return this.messageTemplateIdFieldSpecified;
            }
            set
            {
                this.messageTemplateIdFieldSpecified = value;
                this.RaisePropertyChanged("messageTemplateIdSpecified");
            }
        }

        /// <remarks/>
        public string messageTemplateData
        {
            get
            {
                return this.messageTemplateDataField;
            }
            set
            {
                this.messageTemplateDataField = value;
                this.RaisePropertyChanged("messageTemplateData");
            }
        }

        /// <remarks/>
        public int messageWizardTemplateId
        {
            get
            {
                return this.messageWizardTemplateIdField;
            }
            set
            {
                this.messageWizardTemplateIdField = value;
                this.RaisePropertyChanged("messageWizardTemplateId");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool messageWizardTemplateIdSpecified
        {
            get
            {
                return this.messageWizardTemplateIdFieldSpecified;
            }
            set
            {
                this.messageWizardTemplateIdFieldSpecified = value;
                this.RaisePropertyChanged("messageWizardTemplateIdSpecified");
            }
        }

        /// <remarks/>
        public string messageWizardTemplateData
        {
            get
            {
                return this.messageWizardTemplateDataField;
            }
            set
            {
                this.messageWizardTemplateDataField = value;
                this.RaisePropertyChanged("messageWizardTemplateData");
            }
        }

        /// <remarks/>
        public string messageWebLink
        {
            get
            {
                return this.messageWebLinkField;
            }
            set
            {
                this.messageWebLinkField = value;
                this.RaisePropertyChanged("messageWebLink");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class GetMessagesReq : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIRequestHeader headerField;

        private bool archivedField;

        private bool archivedFieldSpecified;

        private bool optinField;

        private bool optinFieldSpecified;

        private bool metaDataOnlyField;

        private bool metaDataOnlyFieldSpecified;

        /// <remarks/>
        public APIRequestHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public bool archived
        {
            get
            {
                return this.archivedField;
            }
            set
            {
                this.archivedField = value;
                this.RaisePropertyChanged("archived");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool archivedSpecified
        {
            get
            {
                return this.archivedFieldSpecified;
            }
            set
            {
                this.archivedFieldSpecified = value;
                this.RaisePropertyChanged("archivedSpecified");
            }
        }

        /// <remarks/>
        public bool optin
        {
            get
            {
                return this.optinField;
            }
            set
            {
                this.optinField = value;
                this.RaisePropertyChanged("optin");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool optinSpecified
        {
            get
            {
                return this.optinFieldSpecified;
            }
            set
            {
                this.optinFieldSpecified = value;
                this.RaisePropertyChanged("optinSpecified");
            }
        }

        /// <remarks/>
        public bool metaDataOnly
        {
            get
            {
                return this.metaDataOnlyField;
            }
            set
            {
                this.metaDataOnlyField = value;
                this.RaisePropertyChanged("metaDataOnly");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool metaDataOnlySpecified
        {
            get
            {
                return this.metaDataOnlyFieldSpecified;
            }
            set
            {
                this.metaDataOnlyFieldSpecified = value;
                this.RaisePropertyChanged("metaDataOnlySpecified");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class DeleteMessageResp : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIResponseHeader headerField;

        private int errorCodeField;

        private string errorMessageField;

        /// <remarks/>
        public APIResponseHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public int errorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
                this.RaisePropertyChanged("errorCode");
            }
        }

        /// <remarks/>
        public string errorMessage
        {
            get
            {
                return this.errorMessageField;
            }
            set
            {
                this.errorMessageField = value;
                this.RaisePropertyChanged("errorMessage");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class DeleteMessageReq : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIRequestHeader headerField;

        private MessageType messageTypeField;

        /// <remarks/>
        public APIRequestHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public MessageType messageType
        {
            get
            {
                return this.messageTypeField;
            }
            set
            {
                this.messageTypeField = value;
                this.RaisePropertyChanged("messageType");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class UpdateMessageResp : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIResponseHeader headerField;

        private int errorCodeField;

        private string errorMessageField;

        /// <remarks/>
        public APIResponseHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public int errorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
                this.RaisePropertyChanged("errorCode");
            }
        }

        /// <remarks/>
        public string errorMessage
        {
            get
            {
                return this.errorMessageField;
            }
            set
            {
                this.errorMessageField = value;
                this.RaisePropertyChanged("errorMessage");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class UpdateMessageReq : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIRequestHeader headerField;

        private MessageType messageTypeField;

        /// <remarks/>
        public APIRequestHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public MessageType messageType
        {
            get
            {
                return this.messageTypeField;
            }
            set
            {
                this.messageTypeField = value;
                this.RaisePropertyChanged("messageType");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class CreateMessageResp : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIResponseHeader headerField;

        private int errorCodeField;

        private string errorMessageField;

        private int messageIdField;

        /// <remarks/>
        public APIResponseHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public int errorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
                this.RaisePropertyChanged("errorCode");
            }
        }

        /// <remarks/>
        public string errorMessage
        {
            get
            {
                return this.errorMessageField;
            }
            set
            {
                this.errorMessageField = value;
                this.RaisePropertyChanged("errorMessage");
            }
        }

        /// <remarks/>
        public int messageId
        {
            get
            {
                return this.messageIdField;
            }
            set
            {
                this.messageIdField = value;
                this.RaisePropertyChanged("messageId");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class CreateMessageReq : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIRequestHeader headerField;

        private MessageType messageTypeField;

        /// <remarks/>
        public APIRequestHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public MessageType messageType
        {
            get
            {
                return this.messageTypeField;
            }
            set
            {
                this.messageTypeField = value;
                this.RaisePropertyChanged("messageType");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class GetEmailAddressSubscriptionsResp : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIResponseHeader headerField;

        private int errorCodeField;

        private string errorMessageField;

        private EmailAddressType[] emailAddressTypeItemsField;

        /// <remarks/>
        public APIResponseHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public int errorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
                this.RaisePropertyChanged("errorCode");
            }
        }

        /// <remarks/>
        public string errorMessage
        {
            get
            {
                return this.errorMessageField;
            }
            set
            {
                this.errorMessageField = value;
                this.RaisePropertyChanged("errorMessage");
            }
        }

        /// <remarks/>
        public EmailAddressType[] emailAddressTypeItems
        {
            get
            {
                return this.emailAddressTypeItemsField;
            }
            set
            {
                this.emailAddressTypeItemsField = value;
                this.RaisePropertyChanged("emailAddressTypeItems");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class GetEmailAddressSubscriptionsReq : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIRequestHeader headerField;

        private int[] mailingListIdsField;

        private EmailAddressType[] emailAddressTypeItemsField;

        /// <remarks/>
        public APIRequestHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public int[] mailingListIds
        {
            get
            {
                return this.mailingListIdsField;
            }
            set
            {
                this.mailingListIdsField = value;
                this.RaisePropertyChanged("mailingListIds");
            }
        }

        /// <remarks/>
        public EmailAddressType[] emailAddressTypeItems
        {
            get
            {
                return this.emailAddressTypeItemsField;
            }
            set
            {
                this.emailAddressTypeItemsField = value;
                this.RaisePropertyChanged("emailAddressTypeItems");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class GetEmailAddressesResp : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIResponseHeader headerField;

        private int errorCodeField;

        private string errorMessageField;

        private EmailAddressType[] emailAddressTypeItemsField;

        /// <remarks/>
        public APIResponseHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public int errorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
                this.RaisePropertyChanged("errorCode");
            }
        }

        /// <remarks/>
        public string errorMessage
        {
            get
            {
                return this.errorMessageField;
            }
            set
            {
                this.errorMessageField = value;
                this.RaisePropertyChanged("errorMessage");
            }
        }

        /// <remarks/>
        public EmailAddressType[] emailAddressTypeItems
        {
            get
            {
                return this.emailAddressTypeItemsField;
            }
            set
            {
                this.emailAddressTypeItemsField = value;
                this.RaisePropertyChanged("emailAddressTypeItems");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class GetEmailAddressesReq : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIRequestHeader headerField;

        private int[] mailingListIdsField;

        private int[] groupIdsField;

        private EmailAddressType[] emailAddressTypeItemsField;

        /// <remarks/>
        public APIRequestHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public int[] mailingListIds
        {
            get
            {
                return this.mailingListIdsField;
            }
            set
            {
                this.mailingListIdsField = value;
                this.RaisePropertyChanged("mailingListIds");
            }
        }

        /// <remarks/>
        public int[] groupIds
        {
            get
            {
                return this.groupIdsField;
            }
            set
            {
                this.groupIdsField = value;
                this.RaisePropertyChanged("groupIds");
            }
        }

        /// <remarks/>
        public EmailAddressType[] emailAddressTypeItems
        {
            get
            {
                return this.emailAddressTypeItemsField;
            }
            set
            {
                this.emailAddressTypeItemsField = value;
                this.RaisePropertyChanged("emailAddressTypeItems");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class ImportEmailAddressRespType : object, System.ComponentModel.INotifyPropertyChanged
    {

        private string referenceIdField;

        private int flexmailIdField;

        private int errorCodeField;

        private string errorMessageField;

        /// <remarks/>
        public string referenceId
        {
            get
            {
                return this.referenceIdField;
            }
            set
            {
                this.referenceIdField = value;
                this.RaisePropertyChanged("referenceId");
            }
        }

        /// <remarks/>
        public int flexmailId
        {
            get
            {
                return this.flexmailIdField;
            }
            set
            {
                this.flexmailIdField = value;
                this.RaisePropertyChanged("flexmailId");
            }
        }

        /// <remarks/>
        public int errorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
                this.RaisePropertyChanged("errorCode");
            }
        }

        /// <remarks/>
        public string errorMessage
        {
            get
            {
                return this.errorMessageField;
            }
            set
            {
                this.errorMessageField = value;
                this.RaisePropertyChanged("errorMessage");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class ImportEmailAddressesResp : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIResponseHeader headerField;

        private int errorCodeField;

        private string errorMessageField;

        private ImportEmailAddressRespType[] importEmailAddressRespTypeItemsField;

        /// <remarks/>
        public APIResponseHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public int errorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
                this.RaisePropertyChanged("errorCode");
            }
        }

        /// <remarks/>
        public string errorMessage
        {
            get
            {
                return this.errorMessageField;
            }
            set
            {
                this.errorMessageField = value;
                this.RaisePropertyChanged("errorMessage");
            }
        }

        /// <remarks/>
        public ImportEmailAddressRespType[] importEmailAddressRespTypeItems
        {
            get
            {
                return this.importEmailAddressRespTypeItemsField;
            }
            set
            {
                this.importEmailAddressRespTypeItemsField = value;
                this.RaisePropertyChanged("importEmailAddressRespTypeItems");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class ImportEmailAddressesReq : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIRequestHeader headerField;

        private int mailingListIdField;

        private EmailAddressType[] emailAddressTypeItemsField;

        private bool allowDuplicatesField;

        private bool allowDuplicatesFieldSpecified;

        private bool overwriteField;

        private bool overwriteFieldSpecified;

        private bool synchroniseField;

        private bool synchroniseFieldSpecified;

        private ReferenceFieldType referenceFieldField;

        private bool referenceFieldFieldSpecified;

        private string transactionIdField;

        private bool allowBouncedOutField;

        private bool allowBouncedOutFieldSpecified;

        /// <remarks/>
        public APIRequestHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public int mailingListId
        {
            get
            {
                return this.mailingListIdField;
            }
            set
            {
                this.mailingListIdField = value;
                this.RaisePropertyChanged("mailingListId");
            }
        }

        /// <remarks/>
        public EmailAddressType[] emailAddressTypeItems
        {
            get
            {
                return this.emailAddressTypeItemsField;
            }
            set
            {
                this.emailAddressTypeItemsField = value;
                this.RaisePropertyChanged("emailAddressTypeItems");
            }
        }

        /// <remarks/>
        public bool allowDuplicates
        {
            get
            {
                return this.allowDuplicatesField;
            }
            set
            {
                this.allowDuplicatesField = value;
                this.RaisePropertyChanged("allowDuplicates");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool allowDuplicatesSpecified
        {
            get
            {
                return this.allowDuplicatesFieldSpecified;
            }
            set
            {
                this.allowDuplicatesFieldSpecified = value;
                this.RaisePropertyChanged("allowDuplicatesSpecified");
            }
        }

        /// <remarks/>
        public bool overwrite
        {
            get
            {
                return this.overwriteField;
            }
            set
            {
                this.overwriteField = value;
                this.RaisePropertyChanged("overwrite");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool overwriteSpecified
        {
            get
            {
                return this.overwriteFieldSpecified;
            }
            set
            {
                this.overwriteFieldSpecified = value;
                this.RaisePropertyChanged("overwriteSpecified");
            }
        }

        /// <remarks/>
        public bool synchronise
        {
            get
            {
                return this.synchroniseField;
            }
            set
            {
                this.synchroniseField = value;
                this.RaisePropertyChanged("synchronise");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool synchroniseSpecified
        {
            get
            {
                return this.synchroniseFieldSpecified;
            }
            set
            {
                this.synchroniseFieldSpecified = value;
                this.RaisePropertyChanged("synchroniseSpecified");
            }
        }

        /// <remarks/>
        public ReferenceFieldType referenceField
        {
            get
            {
                return this.referenceFieldField;
            }
            set
            {
                this.referenceFieldField = value;
                this.RaisePropertyChanged("referenceField");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool referenceFieldSpecified
        {
            get
            {
                return this.referenceFieldFieldSpecified;
            }
            set
            {
                this.referenceFieldFieldSpecified = value;
                this.RaisePropertyChanged("referenceFieldSpecified");
            }
        }

        /// <remarks/>
        public string transactionId
        {
            get
            {
                return this.transactionIdField;
            }
            set
            {
                this.transactionIdField = value;
                this.RaisePropertyChanged("transactionId");
            }
        }

        /// <remarks/>
        public bool allowBouncedOut
        {
            get
            {
                return this.allowBouncedOutField;
            }
            set
            {
                this.allowBouncedOutField = value;
                this.RaisePropertyChanged("allowBouncedOut");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool allowBouncedOutSpecified
        {
            get
            {
                return this.allowBouncedOutFieldSpecified;
            }
            set
            {
                this.allowBouncedOutFieldSpecified = value;
                this.RaisePropertyChanged("allowBouncedOutSpecified");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public enum ReferenceFieldType
    {

        /// <remarks/>
        email,

        /// <remarks/>
        company,

        /// <remarks/>
        title,

        /// <remarks/>
        name,

        /// <remarks/>
        surname,

        /// <remarks/>
        jobtitle,

        /// <remarks/>
        street,

        /// <remarks/>
        zip,

        /// <remarks/>
        city,

        /// <remarks/>
        province,

        /// <remarks/>
        country,

        /// <remarks/>
        phone,

        /// <remarks/>
        mobile,

        /// <remarks/>
        fax,

        /// <remarks/>
        website,

        /// <remarks/>
        language,

        /// <remarks/>
        gender,

        /// <remarks/>
        birthday,

        /// <remarks/>
        market,

        /// <remarks/>
        activities,

        /// <remarks/>
        employees,

        /// <remarks/>
        turnover,

        /// <remarks/>
        vat,

        /// <remarks/>
        nace,

        /// <remarks/>
        keywords,

        /// <remarks/>
        barcode,

        /// <remarks/>
        free_field_1,

        /// <remarks/>
        free_field_2,

        /// <remarks/>
        free_field_3,

        /// <remarks/>
        free_field_4,

        /// <remarks/>
        free_field_5,

        /// <remarks/>
        free_field_6,

        /// <remarks/>
        reference_id,
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class DeleteEmailAddressResp : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIResponseHeader headerField;

        private int errorCodeField;

        private string errorMessageField;

        /// <remarks/>
        public APIResponseHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public int errorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
                this.RaisePropertyChanged("errorCode");
            }
        }

        /// <remarks/>
        public string errorMessage
        {
            get
            {
                return this.errorMessageField;
            }
            set
            {
                this.errorMessageField = value;
                this.RaisePropertyChanged("errorMessage");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class DeleteEmailAddressReq : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIRequestHeader headerField;

        private int mailingListIdField;

        private EmailAddressType emailAddressTypeField;

        /// <remarks/>
        public APIRequestHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public int mailingListId
        {
            get
            {
                return this.mailingListIdField;
            }
            set
            {
                this.mailingListIdField = value;
                this.RaisePropertyChanged("mailingListId");
            }
        }

        /// <remarks/>
        public EmailAddressType emailAddressType
        {
            get
            {
                return this.emailAddressTypeField;
            }
            set
            {
                this.emailAddressTypeField = value;
                this.RaisePropertyChanged("emailAddressType");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class UpdateEmailAddressResp : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIResponseHeader headerField;

        private int errorCodeField;

        private string errorMessageField;

        private int emailAddressIdField;

        private bool emailAddressIdFieldSpecified;

        /// <remarks/>
        public APIResponseHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public int errorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
                this.RaisePropertyChanged("errorCode");
            }
        }

        /// <remarks/>
        public string errorMessage
        {
            get
            {
                return this.errorMessageField;
            }
            set
            {
                this.errorMessageField = value;
                this.RaisePropertyChanged("errorMessage");
            }
        }

        /// <remarks/>
        public int emailAddressId
        {
            get
            {
                return this.emailAddressIdField;
            }
            set
            {
                this.emailAddressIdField = value;
                this.RaisePropertyChanged("emailAddressId");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool emailAddressIdSpecified
        {
            get
            {
                return this.emailAddressIdFieldSpecified;
            }
            set
            {
                this.emailAddressIdFieldSpecified = value;
                this.RaisePropertyChanged("emailAddressIdSpecified");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class UpdateEmailAddressReq : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIRequestHeader headerField;

        private EmailAddressType emailAddressTypeField;

        private int mailingListIdField;

        private bool mailingListIdFieldSpecified;

        /// <remarks/>
        public APIRequestHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public EmailAddressType emailAddressType
        {
            get
            {
                return this.emailAddressTypeField;
            }
            set
            {
                this.emailAddressTypeField = value;
                this.RaisePropertyChanged("emailAddressType");
            }
        }

        /// <remarks/>
        public int mailingListId
        {
            get
            {
                return this.mailingListIdField;
            }
            set
            {
                this.mailingListIdField = value;
                this.RaisePropertyChanged("mailingListId");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool mailingListIdSpecified
        {
            get
            {
                return this.mailingListIdFieldSpecified;
            }
            set
            {
                this.mailingListIdFieldSpecified = value;
                this.RaisePropertyChanged("mailingListIdSpecified");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class CreateEmailAddressResp : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIResponseHeader headerField;

        private int errorCodeField;

        private string errorMessageField;

        private int emailAddressIdField;

        /// <remarks/>
        public APIResponseHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public int errorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
                this.RaisePropertyChanged("errorCode");
            }
        }

        /// <remarks/>
        public string errorMessage
        {
            get
            {
                return this.errorMessageField;
            }
            set
            {
                this.errorMessageField = value;
                this.RaisePropertyChanged("errorMessage");
            }
        }

        /// <remarks/>
        public int emailAddressId
        {
            get
            {
                return this.emailAddressIdField;
            }
            set
            {
                this.emailAddressIdField = value;
                this.RaisePropertyChanged("emailAddressId");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class OptInType : object, System.ComponentModel.INotifyPropertyChanged
    {

        private int messageIdField;

        private string senderNameField;

        private string senderEmailField;

        private string replyEmailField;

        private string subjectField;

        /// <remarks/>
        public int messageId
        {
            get
            {
                return this.messageIdField;
            }
            set
            {
                this.messageIdField = value;
                this.RaisePropertyChanged("messageId");
            }
        }

        /// <remarks/>
        public string senderName
        {
            get
            {
                return this.senderNameField;
            }
            set
            {
                this.senderNameField = value;
                this.RaisePropertyChanged("senderName");
            }
        }

        /// <remarks/>
        public string senderEmail
        {
            get
            {
                return this.senderEmailField;
            }
            set
            {
                this.senderEmailField = value;
                this.RaisePropertyChanged("senderEmail");
            }
        }

        /// <remarks/>
        public string replyEmail
        {
            get
            {
                return this.replyEmailField;
            }
            set
            {
                this.replyEmailField = value;
                this.RaisePropertyChanged("replyEmail");
            }
        }

        /// <remarks/>
        public string subject
        {
            get
            {
                return this.subjectField;
            }
            set
            {
                this.subjectField = value;
                this.RaisePropertyChanged("subject");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class CreateEmailAddressReq : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIRequestHeader headerField;

        private int mailingListIdField;

        private EmailAddressType emailAddressTypeField;

        private OptInType optInTypeField;

        /// <remarks/>
        public APIRequestHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public int mailingListId
        {
            get
            {
                return this.mailingListIdField;
            }
            set
            {
                this.mailingListIdField = value;
                this.RaisePropertyChanged("mailingListId");
            }
        }

        /// <remarks/>
        public EmailAddressType emailAddressType
        {
            get
            {
                return this.emailAddressTypeField;
            }
            set
            {
                this.emailAddressTypeField = value;
                this.RaisePropertyChanged("emailAddressType");
            }
        }

        /// <remarks/>
        public OptInType optInType
        {
            get
            {
                return this.optInTypeField;
            }
            set
            {
                this.optInTypeField = value;
                this.RaisePropertyChanged("optInType");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class GetMailingListsResp : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIResponseHeader headerField;

        private int errorCodeField;

        private string errorMessageField;

        private MailingListType[] mailingListTypeItemsField;

        /// <remarks/>
        public APIResponseHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public int errorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
                this.RaisePropertyChanged("errorCode");
            }
        }

        /// <remarks/>
        public string errorMessage
        {
            get
            {
                return this.errorMessageField;
            }
            set
            {
                this.errorMessageField = value;
                this.RaisePropertyChanged("errorMessage");
            }
        }

        /// <remarks/>
        public MailingListType[] mailingListTypeItems
        {
            get
            {
                return this.mailingListTypeItemsField;
            }
            set
            {
                this.mailingListTypeItemsField = value;
                this.RaisePropertyChanged("mailingListTypeItems");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class GetMailingListsReq : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIRequestHeader headerField;

        private int categoryIdField;

        /// <remarks/>
        public APIRequestHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public int categoryId
        {
            get
            {
                return this.categoryIdField;
            }
            set
            {
                this.categoryIdField = value;
                this.RaisePropertyChanged("categoryId");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class TruncateMailingListResp : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIResponseHeader headerField;

        private int errorCodeField;

        private string errorMessageField;

        /// <remarks/>
        public APIResponseHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public int errorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
                this.RaisePropertyChanged("errorCode");
            }
        }

        /// <remarks/>
        public string errorMessage
        {
            get
            {
                return this.errorMessageField;
            }
            set
            {
                this.errorMessageField = value;
                this.RaisePropertyChanged("errorMessage");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class TruncateMailingListReq : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIRequestHeader headerField;

        private int mailingListIdField;

        /// <remarks/>
        public APIRequestHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public int mailingListId
        {
            get
            {
                return this.mailingListIdField;
            }
            set
            {
                this.mailingListIdField = value;
                this.RaisePropertyChanged("mailingListId");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class DeleteMailingListResp : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIResponseHeader headerField;

        private int errorCodeField;

        private string errorMessageField;

        /// <remarks/>
        public APIResponseHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public int errorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
                this.RaisePropertyChanged("errorCode");
            }
        }

        /// <remarks/>
        public string errorMessage
        {
            get
            {
                return this.errorMessageField;
            }
            set
            {
                this.errorMessageField = value;
                this.RaisePropertyChanged("errorMessage");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class DeleteMailingListReq : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIRequestHeader headerField;

        private int mailingListIdField;

        /// <remarks/>
        public APIRequestHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public int mailingListId
        {
            get
            {
                return this.mailingListIdField;
            }
            set
            {
                this.mailingListIdField = value;
                this.RaisePropertyChanged("mailingListId");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class UpdateMailingListResp : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIResponseHeader headerField;

        private int errorCodeField;

        private string errorMessageField;

        /// <remarks/>
        public APIResponseHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public int errorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
                this.RaisePropertyChanged("errorCode");
            }
        }

        /// <remarks/>
        public string errorMessage
        {
            get
            {
                return this.errorMessageField;
            }
            set
            {
                this.errorMessageField = value;
                this.RaisePropertyChanged("errorMessage");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class UpdateMailingListReq : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIRequestHeader headerField;

        private int mailingListIdField;

        private string mailingListNameField;

        private string mailingListLanguageField;

        /// <remarks/>
        public APIRequestHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public int mailingListId
        {
            get
            {
                return this.mailingListIdField;
            }
            set
            {
                this.mailingListIdField = value;
                this.RaisePropertyChanged("mailingListId");
            }
        }

        /// <remarks/>
        public string mailingListName
        {
            get
            {
                return this.mailingListNameField;
            }
            set
            {
                this.mailingListNameField = value;
                this.RaisePropertyChanged("mailingListName");
            }
        }

        /// <remarks/>
        public string mailingListLanguage
        {
            get
            {
                return this.mailingListLanguageField;
            }
            set
            {
                this.mailingListLanguageField = value;
                this.RaisePropertyChanged("mailingListLanguage");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class CreateMailingListResp : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIResponseHeader headerField;

        private int errorCodeField;

        private string errorMessageField;

        private int mailingListIdField;

        /// <remarks/>
        public APIResponseHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public int errorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
                this.RaisePropertyChanged("errorCode");
            }
        }

        /// <remarks/>
        public string errorMessage
        {
            get
            {
                return this.errorMessageField;
            }
            set
            {
                this.errorMessageField = value;
                this.RaisePropertyChanged("errorMessage");
            }
        }

        /// <remarks/>
        public int mailingListId
        {
            get
            {
                return this.mailingListIdField;
            }
            set
            {
                this.mailingListIdField = value;
                this.RaisePropertyChanged("mailingListId");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class CreateMailingListReq : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIRequestHeader headerField;

        private int categoryIdField;

        private string mailingListNameField;

        private string mailingListLanguageField;

        private bool addUnsubscriptionsToBlacklistField;

        private bool addUnsubscriptionsToBlacklistFieldSpecified;

        /// <remarks/>
        public APIRequestHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public int categoryId
        {
            get
            {
                return this.categoryIdField;
            }
            set
            {
                this.categoryIdField = value;
                this.RaisePropertyChanged("categoryId");
            }
        }

        /// <remarks/>
        public string mailingListName
        {
            get
            {
                return this.mailingListNameField;
            }
            set
            {
                this.mailingListNameField = value;
                this.RaisePropertyChanged("mailingListName");
            }
        }

        /// <remarks/>
        public string mailingListLanguage
        {
            get
            {
                return this.mailingListLanguageField;
            }
            set
            {
                this.mailingListLanguageField = value;
                this.RaisePropertyChanged("mailingListLanguage");
            }
        }

        /// <remarks/>
        public bool addUnsubscriptionsToBlacklist
        {
            get
            {
                return this.addUnsubscriptionsToBlacklistField;
            }
            set
            {
                this.addUnsubscriptionsToBlacklistField = value;
                this.RaisePropertyChanged("addUnsubscriptionsToBlacklist");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool addUnsubscriptionsToBlacklistSpecified
        {
            get
            {
                return this.addUnsubscriptionsToBlacklistFieldSpecified;
            }
            set
            {
                this.addUnsubscriptionsToBlacklistFieldSpecified = value;
                this.RaisePropertyChanged("addUnsubscriptionsToBlacklistSpecified");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class CategoryType : object, System.ComponentModel.INotifyPropertyChanged
    {

        private int categoryIdField;

        private bool categoryIdFieldSpecified;

        private string categoryNameField;

        /// <remarks/>
        public int categoryId
        {
            get
            {
                return this.categoryIdField;
            }
            set
            {
                this.categoryIdField = value;
                this.RaisePropertyChanged("categoryId");
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.SoapIgnoreAttribute()]
        public bool categoryIdSpecified
        {
            get
            {
                return this.categoryIdFieldSpecified;
            }
            set
            {
                this.categoryIdFieldSpecified = value;
                this.RaisePropertyChanged("categoryIdSpecified");
            }
        }

        /// <remarks/>
        public string categoryName
        {
            get
            {
                return this.categoryNameField;
            }
            set
            {
                this.categoryNameField = value;
                this.RaisePropertyChanged("categoryName");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class GetCategoriesResp : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIResponseHeader headerField;

        private int errorCodeField;

        private string errorMessageField;

        private CategoryType[] categoryTypeItemsField;

        /// <remarks/>
        public APIResponseHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public int errorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
                this.RaisePropertyChanged("errorCode");
            }
        }

        /// <remarks/>
        public string errorMessage
        {
            get
            {
                return this.errorMessageField;
            }
            set
            {
                this.errorMessageField = value;
                this.RaisePropertyChanged("errorMessage");
            }
        }

        /// <remarks/>
        public CategoryType[] categoryTypeItems
        {
            get
            {
                return this.categoryTypeItemsField;
            }
            set
            {
                this.categoryTypeItemsField = value;
                this.RaisePropertyChanged("categoryTypeItems");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class GetCategoriesReq : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIRequestHeader headerField;

        /// <remarks/>
        public APIRequestHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class DeleteCategoryResp : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIResponseHeader headerField;

        private int errorCodeField;

        private string errorMessageField;

        /// <remarks/>
        public APIResponseHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public int errorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
                this.RaisePropertyChanged("errorCode");
            }
        }

        /// <remarks/>
        public string errorMessage
        {
            get
            {
                return this.errorMessageField;
            }
            set
            {
                this.errorMessageField = value;
                this.RaisePropertyChanged("errorMessage");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class DeleteCategoryReq : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIRequestHeader headerField;

        private int categoryIdField;

        /// <remarks/>
        public APIRequestHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public int categoryId
        {
            get
            {
                return this.categoryIdField;
            }
            set
            {
                this.categoryIdField = value;
                this.RaisePropertyChanged("categoryId");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class UpdateCategoryResp : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIResponseHeader headerField;

        private int errorCodeField;

        private string errorMessageField;

        /// <remarks/>
        public APIResponseHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public int errorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
                this.RaisePropertyChanged("errorCode");
            }
        }

        /// <remarks/>
        public string errorMessage
        {
            get
            {
                return this.errorMessageField;
            }
            set
            {
                this.errorMessageField = value;
                this.RaisePropertyChanged("errorMessage");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class UpdateCategoryReq : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIRequestHeader headerField;

        private int categoryIdField;

        private string categoryNameField;

        /// <remarks/>
        public APIRequestHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public int categoryId
        {
            get
            {
                return this.categoryIdField;
            }
            set
            {
                this.categoryIdField = value;
                this.RaisePropertyChanged("categoryId");
            }
        }

        /// <remarks/>
        public string categoryName
        {
            get
            {
                return this.categoryNameField;
            }
            set
            {
                this.categoryNameField = value;
                this.RaisePropertyChanged("categoryName");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.7.2046.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.SoapTypeAttribute(Namespace = "http://soap.flexmail.eu/3.0.0/flexmail.wsdl")]
    public partial class CreateCategoryResp : object, System.ComponentModel.INotifyPropertyChanged
    {

        private APIResponseHeader headerField;

        private int errorCodeField;

        private string errorMessageField;

        private int categoryIdField;

        /// <remarks/>
        public APIResponseHeader header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
                this.RaisePropertyChanged("header");
            }
        }

        /// <remarks/>
        public int errorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
                this.RaisePropertyChanged("errorCode");
            }
        }

        /// <remarks/>
        public string errorMessage
        {
            get
            {
                return this.errorMessageField;
            }
            set
            {
                this.errorMessageField = value;
                this.RaisePropertyChanged("errorMessage");
            }
        }

        /// <remarks/>
        public int categoryId
        {
            get
            {
                return this.categoryIdField;
            }
            set
            {
                this.categoryIdField = value;
                this.RaisePropertyChanged("categoryId");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "CreateCategory", WrapperNamespace = "", IsWrapped = true)]
    public partial class CreateCategoryRequest
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.CreateCategoryReq CreateCategoryReq;

        public CreateCategoryRequest()
        {
        }

        public CreateCategoryRequest(FlexMail.Service.CreateCategoryReq CreateCategoryReq)
        {
            this.CreateCategoryReq = CreateCategoryReq;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "CreateCategoryResponse", WrapperNamespace = "", IsWrapped = true)]
    public partial class CreateCategoryResponse
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.CreateCategoryResp CreateCategoryResp;

        public CreateCategoryResponse()
        {
        }

        public CreateCategoryResponse(FlexMail.Service.CreateCategoryResp CreateCategoryResp)
        {
            this.CreateCategoryResp = CreateCategoryResp;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "UpdateCategory", WrapperNamespace = "", IsWrapped = true)]
    public partial class UpdateCategoryRequest
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.UpdateCategoryReq UpdateCategoryReq;

        public UpdateCategoryRequest()
        {
        }

        public UpdateCategoryRequest(FlexMail.Service.UpdateCategoryReq UpdateCategoryReq)
        {
            this.UpdateCategoryReq = UpdateCategoryReq;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "UpdateCategoryResponse", WrapperNamespace = "", IsWrapped = true)]
    public partial class UpdateCategoryResponse
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.UpdateCategoryResp UpdateCategoryResp;

        public UpdateCategoryResponse()
        {
        }

        public UpdateCategoryResponse(FlexMail.Service.UpdateCategoryResp UpdateCategoryResp)
        {
            this.UpdateCategoryResp = UpdateCategoryResp;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "DeleteCategory", WrapperNamespace = "", IsWrapped = true)]
    public partial class DeleteCategoryRequest
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.DeleteCategoryReq DeleteCategoryReq;

        public DeleteCategoryRequest()
        {
        }

        public DeleteCategoryRequest(FlexMail.Service.DeleteCategoryReq DeleteCategoryReq)
        {
            this.DeleteCategoryReq = DeleteCategoryReq;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "DeleteCategoryResponse", WrapperNamespace = "", IsWrapped = true)]
    public partial class DeleteCategoryResponse
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.DeleteCategoryResp DeleteCategoryResp;

        public DeleteCategoryResponse()
        {
        }

        public DeleteCategoryResponse(FlexMail.Service.DeleteCategoryResp DeleteCategoryResp)
        {
            this.DeleteCategoryResp = DeleteCategoryResp;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "GetCategories", WrapperNamespace = "", IsWrapped = true)]
    public partial class GetCategoriesRequest
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.GetCategoriesReq GetCategoriesReq;

        public GetCategoriesRequest()
        {
        }

        public GetCategoriesRequest(FlexMail.Service.GetCategoriesReq GetCategoriesReq)
        {
            this.GetCategoriesReq = GetCategoriesReq;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "GetCategoriesResponse", WrapperNamespace = "", IsWrapped = true)]
    public partial class GetCategoriesResponse
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.GetCategoriesResp GetCategoriesResp;

        public GetCategoriesResponse()
        {
        }

        public GetCategoriesResponse(FlexMail.Service.GetCategoriesResp GetCategoriesResp)
        {
            this.GetCategoriesResp = GetCategoriesResp;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "CreateMailingList", WrapperNamespace = "", IsWrapped = true)]
    public partial class CreateMailingListRequest
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.CreateMailingListReq CreateMailingListReq;

        public CreateMailingListRequest()
        {
        }

        public CreateMailingListRequest(FlexMail.Service.CreateMailingListReq CreateMailingListReq)
        {
            this.CreateMailingListReq = CreateMailingListReq;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "CreateMailingListResponse", WrapperNamespace = "", IsWrapped = true)]
    public partial class CreateMailingListResponse
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.CreateMailingListResp CreateMailingListResp;

        public CreateMailingListResponse()
        {
        }

        public CreateMailingListResponse(FlexMail.Service.CreateMailingListResp CreateMailingListResp)
        {
            this.CreateMailingListResp = CreateMailingListResp;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "UpdateMailingList", WrapperNamespace = "", IsWrapped = true)]
    public partial class UpdateMailingListRequest
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.UpdateMailingListReq UpdateMailingListReq;

        public UpdateMailingListRequest()
        {
        }

        public UpdateMailingListRequest(FlexMail.Service.UpdateMailingListReq UpdateMailingListReq)
        {
            this.UpdateMailingListReq = UpdateMailingListReq;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "UpdateMailingListResponse", WrapperNamespace = "", IsWrapped = true)]
    public partial class UpdateMailingListResponse
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.UpdateMailingListResp UpdateMailingListResp;

        public UpdateMailingListResponse()
        {
        }

        public UpdateMailingListResponse(FlexMail.Service.UpdateMailingListResp UpdateMailingListResp)
        {
            this.UpdateMailingListResp = UpdateMailingListResp;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "DeleteMailingList", WrapperNamespace = "", IsWrapped = true)]
    public partial class DeleteMailingListRequest
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.DeleteMailingListReq DeleteMailingListReq;

        public DeleteMailingListRequest()
        {
        }

        public DeleteMailingListRequest(FlexMail.Service.DeleteMailingListReq DeleteMailingListReq)
        {
            this.DeleteMailingListReq = DeleteMailingListReq;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "DeleteMailingListResponse", WrapperNamespace = "", IsWrapped = true)]
    public partial class DeleteMailingListResponse
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.DeleteMailingListResp DeleteMailingListResp;

        public DeleteMailingListResponse()
        {
        }

        public DeleteMailingListResponse(FlexMail.Service.DeleteMailingListResp DeleteMailingListResp)
        {
            this.DeleteMailingListResp = DeleteMailingListResp;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "TruncateMailingList", WrapperNamespace = "", IsWrapped = true)]
    public partial class TruncateMailingListRequest
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.TruncateMailingListReq TruncateMailingListReq;

        public TruncateMailingListRequest()
        {
        }

        public TruncateMailingListRequest(FlexMail.Service.TruncateMailingListReq TruncateMailingListReq)
        {
            this.TruncateMailingListReq = TruncateMailingListReq;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "TruncateMailingListResponse", WrapperNamespace = "", IsWrapped = true)]
    public partial class TruncateMailingListResponse
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.TruncateMailingListResp TruncateMailingListResp;

        public TruncateMailingListResponse()
        {
        }

        public TruncateMailingListResponse(FlexMail.Service.TruncateMailingListResp TruncateMailingListResp)
        {
            this.TruncateMailingListResp = TruncateMailingListResp;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "GetMailingLists", WrapperNamespace = "", IsWrapped = true)]
    public partial class GetMailingListsRequest
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.GetMailingListsReq GetMailingListsReq;

        public GetMailingListsRequest()
        {
        }

        public GetMailingListsRequest(FlexMail.Service.GetMailingListsReq GetMailingListsReq)
        {
            this.GetMailingListsReq = GetMailingListsReq;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "GetMailingListsResponse", WrapperNamespace = "", IsWrapped = true)]
    public partial class GetMailingListsResponse
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.GetMailingListsResp GetMailingListsResp;

        public GetMailingListsResponse()
        {
        }

        public GetMailingListsResponse(FlexMail.Service.GetMailingListsResp GetMailingListsResp)
        {
            this.GetMailingListsResp = GetMailingListsResp;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "CreateEmailAddress", WrapperNamespace = "", IsWrapped = true)]
    public partial class CreateEmailAddressRequest
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.CreateEmailAddressReq CreateEmailAddressReq;

        public CreateEmailAddressRequest()
        {
        }

        public CreateEmailAddressRequest(FlexMail.Service.CreateEmailAddressReq CreateEmailAddressReq)
        {
            this.CreateEmailAddressReq = CreateEmailAddressReq;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "CreateEmailAddressResponse", WrapperNamespace = "", IsWrapped = true)]
    public partial class CreateEmailAddressResponse
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.CreateEmailAddressResp CreateEmailAddressResp;

        public CreateEmailAddressResponse()
        {
        }

        public CreateEmailAddressResponse(FlexMail.Service.CreateEmailAddressResp CreateEmailAddressResp)
        {
            this.CreateEmailAddressResp = CreateEmailAddressResp;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "UpdateEmailAddress", WrapperNamespace = "", IsWrapped = true)]
    public partial class UpdateEmailAddressRequest
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.UpdateEmailAddressReq UpdateEmailAddressReq;

        public UpdateEmailAddressRequest()
        {
        }

        public UpdateEmailAddressRequest(FlexMail.Service.UpdateEmailAddressReq UpdateEmailAddressReq)
        {
            this.UpdateEmailAddressReq = UpdateEmailAddressReq;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "UpdateEmailAddressResponse", WrapperNamespace = "", IsWrapped = true)]
    public partial class UpdateEmailAddressResponse
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.UpdateEmailAddressResp UpdateEmailAddressResp;

        public UpdateEmailAddressResponse()
        {
        }

        public UpdateEmailAddressResponse(FlexMail.Service.UpdateEmailAddressResp UpdateEmailAddressResp)
        {
            this.UpdateEmailAddressResp = UpdateEmailAddressResp;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "DeleteEmailAddress", WrapperNamespace = "", IsWrapped = true)]
    public partial class DeleteEmailAddressRequest
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.DeleteEmailAddressReq DeleteeEmailAddressReq;

        public DeleteEmailAddressRequest()
        {
        }

        public DeleteEmailAddressRequest(FlexMail.Service.DeleteEmailAddressReq DeleteeEmailAddressReq)
        {
            this.DeleteeEmailAddressReq = DeleteeEmailAddressReq;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "DeleteEmailAddressResponse", WrapperNamespace = "", IsWrapped = true)]
    public partial class DeleteEmailAddressResponse
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.DeleteEmailAddressResp DeleteEmailAddressResp;

        public DeleteEmailAddressResponse()
        {
        }

        public DeleteEmailAddressResponse(FlexMail.Service.DeleteEmailAddressResp DeleteEmailAddressResp)
        {
            this.DeleteEmailAddressResp = DeleteEmailAddressResp;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "ImportEmailAddresses", WrapperNamespace = "", IsWrapped = true)]
    public partial class ImportEmailAddressesRequest
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.ImportEmailAddressesReq ImportEmailAddressesReq;

        public ImportEmailAddressesRequest()
        {
        }

        public ImportEmailAddressesRequest(FlexMail.Service.ImportEmailAddressesReq ImportEmailAddressesReq)
        {
            this.ImportEmailAddressesReq = ImportEmailAddressesReq;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "ImportEmailAddressesResponse", WrapperNamespace = "", IsWrapped = true)]
    public partial class ImportEmailAddressesResponse
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.ImportEmailAddressesResp ImportEmailAddressesResp;

        public ImportEmailAddressesResponse()
        {
        }

        public ImportEmailAddressesResponse(FlexMail.Service.ImportEmailAddressesResp ImportEmailAddressesResp)
        {
            this.ImportEmailAddressesResp = ImportEmailAddressesResp;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "GetEmailAddresses", WrapperNamespace = "", IsWrapped = true)]
    public partial class GetEmailAddressesRequest
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.GetEmailAddressesReq GetEmailAddressesReq;

        public GetEmailAddressesRequest()
        {
        }

        public GetEmailAddressesRequest(FlexMail.Service.GetEmailAddressesReq GetEmailAddressesReq)
        {
            this.GetEmailAddressesReq = GetEmailAddressesReq;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "GetEmailAddressesResponse", WrapperNamespace = "", IsWrapped = true)]
    public partial class GetEmailAddressesResponse
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.GetEmailAddressesResp GetEmailAddressesResp;

        public GetEmailAddressesResponse()
        {
        }

        public GetEmailAddressesResponse(FlexMail.Service.GetEmailAddressesResp GetEmailAddressesResp)
        {
            this.GetEmailAddressesResp = GetEmailAddressesResp;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "GetEmailAddressSubscriptions", WrapperNamespace = "", IsWrapped = true)]
    public partial class GetEmailAddressSubscriptionsRequest
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.GetEmailAddressSubscriptionsReq GetEmailAddressSubscriptionsReq;

        public GetEmailAddressSubscriptionsRequest()
        {
        }

        public GetEmailAddressSubscriptionsRequest(FlexMail.Service.GetEmailAddressSubscriptionsReq GetEmailAddressSubscriptionsReq)
        {
            this.GetEmailAddressSubscriptionsReq = GetEmailAddressSubscriptionsReq;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "GetEmailAddressSubscriptionsResponse", WrapperNamespace = "", IsWrapped = true)]
    public partial class GetEmailAddressSubscriptionsResponse
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.GetEmailAddressSubscriptionsResp GetEmailAddressSubscriptionsResp;

        public GetEmailAddressSubscriptionsResponse()
        {
        }

        public GetEmailAddressSubscriptionsResponse(FlexMail.Service.GetEmailAddressSubscriptionsResp GetEmailAddressSubscriptionsResp)
        {
            this.GetEmailAddressSubscriptionsResp = GetEmailAddressSubscriptionsResp;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "CreateMessage", WrapperNamespace = "", IsWrapped = true)]
    public partial class CreateMessageRequest
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.CreateMessageReq CreateMessageReq;

        public CreateMessageRequest()
        {
        }

        public CreateMessageRequest(FlexMail.Service.CreateMessageReq CreateMessageReq)
        {
            this.CreateMessageReq = CreateMessageReq;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "CreateMessageResponse", WrapperNamespace = "", IsWrapped = true)]
    public partial class CreateMessageResponse
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.CreateMessageResp CreateMessageResp;

        public CreateMessageResponse()
        {
        }

        public CreateMessageResponse(FlexMail.Service.CreateMessageResp CreateMessageResp)
        {
            this.CreateMessageResp = CreateMessageResp;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "UpdateMessage", WrapperNamespace = "", IsWrapped = true)]
    public partial class UpdateMessageRequest
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.UpdateMessageReq UpdateMessageReq;

        public UpdateMessageRequest()
        {
        }

        public UpdateMessageRequest(FlexMail.Service.UpdateMessageReq UpdateMessageReq)
        {
            this.UpdateMessageReq = UpdateMessageReq;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "UpdateMessageResponse", WrapperNamespace = "", IsWrapped = true)]
    public partial class UpdateMessageResponse
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.UpdateMessageResp UpdateMessageResp;

        public UpdateMessageResponse()
        {
        }

        public UpdateMessageResponse(FlexMail.Service.UpdateMessageResp UpdateMessageResp)
        {
            this.UpdateMessageResp = UpdateMessageResp;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "DeleteMessage", WrapperNamespace = "", IsWrapped = true)]
    public partial class DeleteMessageRequest
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.DeleteMessageReq DeleteMessageReq;

        public DeleteMessageRequest()
        {
        }

        public DeleteMessageRequest(FlexMail.Service.DeleteMessageReq DeleteMessageReq)
        {
            this.DeleteMessageReq = DeleteMessageReq;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "DeleteMessageResponse", WrapperNamespace = "", IsWrapped = true)]
    public partial class DeleteMessageResponse
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.DeleteMessageResp DeleteMessageResp;

        public DeleteMessageResponse()
        {
        }

        public DeleteMessageResponse(FlexMail.Service.DeleteMessageResp DeleteMessageResp)
        {
            this.DeleteMessageResp = DeleteMessageResp;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "GetMessages", WrapperNamespace = "", IsWrapped = true)]
    public partial class GetMessagesRequest
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.GetMessagesReq GetMessagesReq;

        public GetMessagesRequest()
        {
        }

        public GetMessagesRequest(FlexMail.Service.GetMessagesReq GetMessagesReq)
        {
            this.GetMessagesReq = GetMessagesReq;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "GetMessagesResponse", WrapperNamespace = "", IsWrapped = true)]
    public partial class GetMessagesResponse
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.GetMessagesResp GetMessagesResp;

        public GetMessagesResponse()
        {
        }

        public GetMessagesResponse(FlexMail.Service.GetMessagesResp GetMessagesResp)
        {
            this.GetMessagesResp = GetMessagesResp;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "CreateLandingPage", WrapperNamespace = "", IsWrapped = true)]
    public partial class CreateLandingPageRequest
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.CreateLandingPageReq CreateLandingPageReq;

        public CreateLandingPageRequest()
        {
        }

        public CreateLandingPageRequest(FlexMail.Service.CreateLandingPageReq CreateLandingPageReq)
        {
            this.CreateLandingPageReq = CreateLandingPageReq;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "CreateLandingPageResponse", WrapperNamespace = "", IsWrapped = true)]
    public partial class CreateLandingPageResponse
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.CreateLandingPageResp CreateLandingPageResp;

        public CreateLandingPageResponse()
        {
        }

        public CreateLandingPageResponse(FlexMail.Service.CreateLandingPageResp CreateLandingPageResp)
        {
            this.CreateLandingPageResp = CreateLandingPageResp;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "UpdateLandingPage", WrapperNamespace = "", IsWrapped = true)]
    public partial class UpdateLandingPageRequest
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.UpdateLandingPageReq UpdateLandingPageReq;

        public UpdateLandingPageRequest()
        {
        }

        public UpdateLandingPageRequest(FlexMail.Service.UpdateLandingPageReq UpdateLandingPageReq)
        {
            this.UpdateLandingPageReq = UpdateLandingPageReq;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "UpdateLandingPageResponse", WrapperNamespace = "", IsWrapped = true)]
    public partial class UpdateLandingPageResponse
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.UpdateLandingPageResp UpdateLandingPageResp;

        public UpdateLandingPageResponse()
        {
        }

        public UpdateLandingPageResponse(FlexMail.Service.UpdateLandingPageResp UpdateLandingPageResp)
        {
            this.UpdateLandingPageResp = UpdateLandingPageResp;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "DeleteLandingPage", WrapperNamespace = "", IsWrapped = true)]
    public partial class DeleteLandingPageRequest
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.DeleteLandingPageReq DeleteLandingPageReq;

        public DeleteLandingPageRequest()
        {
        }

        public DeleteLandingPageRequest(FlexMail.Service.DeleteLandingPageReq DeleteLandingPageReq)
        {
            this.DeleteLandingPageReq = DeleteLandingPageReq;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "DeleteLandingPageResponse", WrapperNamespace = "", IsWrapped = true)]
    public partial class DeleteLandingPageResponse
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.DeleteLandingPageResp DeleteLandingPageResp;

        public DeleteLandingPageResponse()
        {
        }

        public DeleteLandingPageResponse(FlexMail.Service.DeleteLandingPageResp DeleteLandingPageResp)
        {
            this.DeleteLandingPageResp = DeleteLandingPageResp;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "GetLandingPages", WrapperNamespace = "", IsWrapped = true)]
    public partial class GetLandingPagesRequest
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.GetLandingPagesReq GetLandingPagesReq;

        public GetLandingPagesRequest()
        {
        }

        public GetLandingPagesRequest(FlexMail.Service.GetLandingPagesReq GetLandingPagesReq)
        {
            this.GetLandingPagesReq = GetLandingPagesReq;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "GetLandingPagesResponse", WrapperNamespace = "", IsWrapped = true)]
    public partial class GetLandingPagesResponse
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.GetLandingPagesResp GetLandingPagesResp;

        public GetLandingPagesResponse()
        {
        }

        public GetLandingPagesResponse(FlexMail.Service.GetLandingPagesResp GetLandingPagesResp)
        {
            this.GetLandingPagesResp = GetLandingPagesResp;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "CreateTemplate", WrapperNamespace = "", IsWrapped = true)]
    public partial class CreateTemplateRequest
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.CreateTemplateReq CreateTemplateReq;

        public CreateTemplateRequest()
        {
        }

        public CreateTemplateRequest(FlexMail.Service.CreateTemplateReq CreateTemplateReq)
        {
            this.CreateTemplateReq = CreateTemplateReq;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "CreateTemplateResponse", WrapperNamespace = "", IsWrapped = true)]
    public partial class CreateTemplateResponse
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.CreateTemplateResp CreateTemplateResp;

        public CreateTemplateResponse()
        {
        }

        public CreateTemplateResponse(FlexMail.Service.CreateTemplateResp CreateTemplateResp)
        {
            this.CreateTemplateResp = CreateTemplateResp;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "UpdateTemplate", WrapperNamespace = "", IsWrapped = true)]
    public partial class UpdateTemplateRequest
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.UpdateTemplateReq UpdateTemplateReq;

        public UpdateTemplateRequest()
        {
        }

        public UpdateTemplateRequest(FlexMail.Service.UpdateTemplateReq UpdateTemplateReq)
        {
            this.UpdateTemplateReq = UpdateTemplateReq;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "UpdateTemplateResponse", WrapperNamespace = "", IsWrapped = true)]
    public partial class UpdateTemplateResponse
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.UpdateTemplateResp UpdateTemplateResp;

        public UpdateTemplateResponse()
        {
        }

        public UpdateTemplateResponse(FlexMail.Service.UpdateTemplateResp UpdateTemplateResp)
        {
            this.UpdateTemplateResp = UpdateTemplateResp;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "DeleteTemplate", WrapperNamespace = "", IsWrapped = true)]
    public partial class DeleteTemplateRequest
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.DeleteTemplateReq DeleteTemplateReq;

        public DeleteTemplateRequest()
        {
        }

        public DeleteTemplateRequest(FlexMail.Service.DeleteTemplateReq DeleteTemplateReq)
        {
            this.DeleteTemplateReq = DeleteTemplateReq;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "DeleteTemplateResponse", WrapperNamespace = "", IsWrapped = true)]
    public partial class DeleteTemplateResponse
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.DeleteTemplateResp DeleteTemplateResp;

        public DeleteTemplateResponse()
        {
        }

        public DeleteTemplateResponse(FlexMail.Service.DeleteTemplateResp DeleteTemplateResp)
        {
            this.DeleteTemplateResp = DeleteTemplateResp;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "GetTemplates", WrapperNamespace = "", IsWrapped = true)]
    public partial class GetTemplatesRequest
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.GetTemplatesReq GetTemplatesReq;

        public GetTemplatesRequest()
        {
        }

        public GetTemplatesRequest(FlexMail.Service.GetTemplatesReq GetTemplatesReq)
        {
            this.GetTemplatesReq = GetTemplatesReq;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "GetTemplatesResponse", WrapperNamespace = "", IsWrapped = true)]
    public partial class GetTemplatesResponse
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.GetTemplatesResp GetTemplatesResp;

        public GetTemplatesResponse()
        {
        }

        public GetTemplatesResponse(FlexMail.Service.GetTemplatesResp GetTemplatesResp)
        {
            this.GetTemplatesResp = GetTemplatesResp;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "CreatePreference", WrapperNamespace = "", IsWrapped = true)]
    public partial class CreatePreferenceRequest
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.CreatePreferenceReq CreatePreferenceReq;

        public CreatePreferenceRequest()
        {
        }

        public CreatePreferenceRequest(FlexMail.Service.CreatePreferenceReq CreatePreferenceReq)
        {
            this.CreatePreferenceReq = CreatePreferenceReq;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "CreatePreferenceResponse", WrapperNamespace = "", IsWrapped = true)]
    public partial class CreatePreferenceResponse
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.CreatePreferenceResp CreatePreferenceResp;

        public CreatePreferenceResponse()
        {
        }

        public CreatePreferenceResponse(FlexMail.Service.CreatePreferenceResp CreatePreferenceResp)
        {
            this.CreatePreferenceResp = CreatePreferenceResp;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "UpdatePreference", WrapperNamespace = "", IsWrapped = true)]
    public partial class UpdatePreferenceRequest
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.UpdatePreferenceReq UpdatePreferenceReq;

        public UpdatePreferenceRequest()
        {
        }

        public UpdatePreferenceRequest(FlexMail.Service.UpdatePreferenceReq UpdatePreferenceReq)
        {
            this.UpdatePreferenceReq = UpdatePreferenceReq;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "UpdatePreferenceResponse", WrapperNamespace = "", IsWrapped = true)]
    public partial class UpdatePreferenceResponse
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.UpdatePreferenceResp UpdatePreferenceResp;

        public UpdatePreferenceResponse()
        {
        }

        public UpdatePreferenceResponse(FlexMail.Service.UpdatePreferenceResp UpdatePreferenceResp)
        {
            this.UpdatePreferenceResp = UpdatePreferenceResp;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "DeletePreference", WrapperNamespace = "", IsWrapped = true)]
    public partial class DeletePreferenceRequest
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.DeletePreferenceReq DeletePreferenceReq;

        public DeletePreferenceRequest()
        {
        }

        public DeletePreferenceRequest(FlexMail.Service.DeletePreferenceReq DeletePreferenceReq)
        {
            this.DeletePreferenceReq = DeletePreferenceReq;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "DeletePreferenceResponse", WrapperNamespace = "", IsWrapped = true)]
    public partial class DeletePreferenceResponse
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.DeletePreferenceResp DeletePreferenceResp;

        public DeletePreferenceResponse()
        {
        }

        public DeletePreferenceResponse(FlexMail.Service.DeletePreferenceResp DeletePreferenceResp)
        {
            this.DeletePreferenceResp = DeletePreferenceResp;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "GetPreferences", WrapperNamespace = "", IsWrapped = true)]
    public partial class GetPreferencesRequest
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.GetPreferencesReq GetPreferencesReq;

        public GetPreferencesRequest()
        {
        }

        public GetPreferencesRequest(FlexMail.Service.GetPreferencesReq GetPreferencesReq)
        {
            this.GetPreferencesReq = GetPreferencesReq;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "GetPreferencesResponse", WrapperNamespace = "", IsWrapped = true)]
    public partial class GetPreferencesResponse
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.GetPreferencesResp GetPreferencesResp;

        public GetPreferencesResponse()
        {
        }

        public GetPreferencesResponse(FlexMail.Service.GetPreferencesResp GetPreferencesResp)
        {
            this.GetPreferencesResp = GetPreferencesResp;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "CreateGroup", WrapperNamespace = "", IsWrapped = true)]
    public partial class CreateGroupRequest
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.CreateGroupReq CreateGroupReq;

        public CreateGroupRequest()
        {
        }

        public CreateGroupRequest(FlexMail.Service.CreateGroupReq CreateGroupReq)
        {
            this.CreateGroupReq = CreateGroupReq;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "CreateGroupResponse", WrapperNamespace = "", IsWrapped = true)]
    public partial class CreateGroupResponse
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.CreateGroupResp CreateGroupResp;

        public CreateGroupResponse()
        {
        }

        public CreateGroupResponse(FlexMail.Service.CreateGroupResp CreateGroupResp)
        {
            this.CreateGroupResp = CreateGroupResp;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "UpdateGroup", WrapperNamespace = "", IsWrapped = true)]
    public partial class UpdateGroupRequest
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.UpdateGroupReq UpdateGroupReq;

        public UpdateGroupRequest()
        {
        }

        public UpdateGroupRequest(FlexMail.Service.UpdateGroupReq UpdateGroupReq)
        {
            this.UpdateGroupReq = UpdateGroupReq;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "UpdateGroupResponse", WrapperNamespace = "", IsWrapped = true)]
    public partial class UpdateGroupResponse
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.UpdateGroupResp UpdateGroupResp;

        public UpdateGroupResponse()
        {
        }

        public UpdateGroupResponse(FlexMail.Service.UpdateGroupResp UpdateGroupResp)
        {
            this.UpdateGroupResp = UpdateGroupResp;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "DeleteGroup", WrapperNamespace = "", IsWrapped = true)]
    public partial class DeleteGroupRequest
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.DeleteGroupReq DeleteGroupReq;

        public DeleteGroupRequest()
        {
        }

        public DeleteGroupRequest(FlexMail.Service.DeleteGroupReq DeleteGroupReq)
        {
            this.DeleteGroupReq = DeleteGroupReq;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "DeleteGroupResponse", WrapperNamespace = "", IsWrapped = true)]
    public partial class DeleteGroupResponse
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.DeleteGroupResp DeleteGroupResp;

        public DeleteGroupResponse()
        {
        }

        public DeleteGroupResponse(FlexMail.Service.DeleteGroupResp DeleteGroupResp)
        {
            this.DeleteGroupResp = DeleteGroupResp;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "GetGroups", WrapperNamespace = "", IsWrapped = true)]
    public partial class GetGroupsRequest
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.GetGroupsReq GetGroupsReq;

        public GetGroupsRequest()
        {
        }

        public GetGroupsRequest(FlexMail.Service.GetGroupsReq GetGroupsReq)
        {
            this.GetGroupsReq = GetGroupsReq;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "GetGroupsResponse", WrapperNamespace = "", IsWrapped = true)]
    public partial class GetGroupsResponse
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.GetGroupsResp GetGroupsResp;

        public GetGroupsResponse()
        {
        }

        public GetGroupsResponse(FlexMail.Service.GetGroupsResp GetGroupsResp)
        {
            this.GetGroupsResp = GetGroupsResp;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "ImportGroupSubscriptions", WrapperNamespace = "", IsWrapped = true)]
    public partial class ImportGroupSubscriptionsRequest
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.ImportGroupSubscriptionsReq ImportGroupSubscriptionsReq;

        public ImportGroupSubscriptionsRequest()
        {
        }

        public ImportGroupSubscriptionsRequest(FlexMail.Service.ImportGroupSubscriptionsReq ImportGroupSubscriptionsReq)
        {
            this.ImportGroupSubscriptionsReq = ImportGroupSubscriptionsReq;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "ImportGroupSubscriptionsResponse", WrapperNamespace = "", IsWrapped = true)]
    public partial class ImportGroupSubscriptionsResponse
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.ImportGroupSubscriptionsResp ImportGroupSubscriptionsResp;

        public ImportGroupSubscriptionsResponse()
        {
        }

        public ImportGroupSubscriptionsResponse(FlexMail.Service.ImportGroupSubscriptionsResp ImportGroupSubscriptionsResp)
        {
            this.ImportGroupSubscriptionsResp = ImportGroupSubscriptionsResp;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "CreateGroupSubscription", WrapperNamespace = "", IsWrapped = true)]
    public partial class CreateGroupSubscriptionRequest
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.CreateGroupSubscriptionReq CreateGroupSubscriptionReq;

        public CreateGroupSubscriptionRequest()
        {
        }

        public CreateGroupSubscriptionRequest(FlexMail.Service.CreateGroupSubscriptionReq CreateGroupSubscriptionReq)
        {
            this.CreateGroupSubscriptionReq = CreateGroupSubscriptionReq;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "CreateGroupSubscriptionResponse", WrapperNamespace = "", IsWrapped = true)]
    public partial class CreateGroupSubscriptionResponse
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.CreateGroupSubscriptionResp CreateGroupSubscriptionResp;

        public CreateGroupSubscriptionResponse()
        {
        }

        public CreateGroupSubscriptionResponse(FlexMail.Service.CreateGroupSubscriptionResp CreateGroupSubscriptionResp)
        {
            this.CreateGroupSubscriptionResp = CreateGroupSubscriptionResp;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "DeleteGroupSubscription", WrapperNamespace = "", IsWrapped = true)]
    public partial class DeleteGroupSubscriptionRequest
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.DeleteGroupSubscriptionReq DeleteGroupSubscriptionReq;

        public DeleteGroupSubscriptionRequest()
        {
        }

        public DeleteGroupSubscriptionRequest(FlexMail.Service.DeleteGroupSubscriptionReq DeleteGroupSubscriptionReq)
        {
            this.DeleteGroupSubscriptionReq = DeleteGroupSubscriptionReq;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "DeleteGroupSubscriptionResponse", WrapperNamespace = "", IsWrapped = true)]
    public partial class DeleteGroupSubscriptionResponse
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.DeleteGroupSubscriptionResp DeleteGroupSubscriptionResp;

        public DeleteGroupSubscriptionResponse()
        {
        }

        public DeleteGroupSubscriptionResponse(FlexMail.Service.DeleteGroupSubscriptionResp DeleteGroupSubscriptionResp)
        {
            this.DeleteGroupSubscriptionResp = DeleteGroupSubscriptionResp;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "CreateCampaign", WrapperNamespace = "", IsWrapped = true)]
    public partial class CreateCampaignRequest
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.CreateCampaignReq CreateCampaignReq;

        public CreateCampaignRequest()
        {
        }

        public CreateCampaignRequest(FlexMail.Service.CreateCampaignReq CreateCampaignReq)
        {
            this.CreateCampaignReq = CreateCampaignReq;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "CreateCampaignResponse", WrapperNamespace = "", IsWrapped = true)]
    public partial class CreateCampaignResponse
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.CreateCampaignResp CreateCampaignResp;

        public CreateCampaignResponse()
        {
        }

        public CreateCampaignResponse(FlexMail.Service.CreateCampaignResp CreateCampaignResp)
        {
            this.CreateCampaignResp = CreateCampaignResp;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "UpdateCampaign", WrapperNamespace = "", IsWrapped = true)]
    public partial class UpdateCampaignRequest
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.UpdateCampaignReq UpdateCampaignReq;

        public UpdateCampaignRequest()
        {
        }

        public UpdateCampaignRequest(FlexMail.Service.UpdateCampaignReq UpdateCampaignReq)
        {
            this.UpdateCampaignReq = UpdateCampaignReq;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "UpdateCampaignResponse", WrapperNamespace = "", IsWrapped = true)]
    public partial class UpdateCampaignResponse
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.UpdateCampaignResp UpdateCampaignResp;

        public UpdateCampaignResponse()
        {
        }

        public UpdateCampaignResponse(FlexMail.Service.UpdateCampaignResp UpdateCampaignResp)
        {
            this.UpdateCampaignResp = UpdateCampaignResp;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "DeleteCampaign", WrapperNamespace = "", IsWrapped = true)]
    public partial class DeleteCampaignRequest
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.DeleteCampaignReq DeleteCampaignReq;

        public DeleteCampaignRequest()
        {
        }

        public DeleteCampaignRequest(FlexMail.Service.DeleteCampaignReq DeleteCampaignReq)
        {
            this.DeleteCampaignReq = DeleteCampaignReq;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "DeleteCampaignResponse", WrapperNamespace = "", IsWrapped = true)]
    public partial class DeleteCampaignResponse
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.DeleteCampaignResp DeleteCampaignResp;

        public DeleteCampaignResponse()
        {
        }

        public DeleteCampaignResponse(FlexMail.Service.DeleteCampaignResp DeleteCampaignResp)
        {
            this.DeleteCampaignResp = DeleteCampaignResp;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "GetCampaigns", WrapperNamespace = "", IsWrapped = true)]
    public partial class GetCampaignsRequest
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.GetCampaignsReq GetCampaignsReq;

        public GetCampaignsRequest()
        {
        }

        public GetCampaignsRequest(FlexMail.Service.GetCampaignsReq GetCampaignsReq)
        {
            this.GetCampaignsReq = GetCampaignsReq;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "GetCampaignsResponse", WrapperNamespace = "", IsWrapped = true)]
    public partial class GetCampaignsResponse
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.GetCampaignsResp GetCampaignsResp;

        public GetCampaignsResponse()
        {
        }

        public GetCampaignsResponse(FlexMail.Service.GetCampaignsResp GetCampaignsResp)
        {
            this.GetCampaignsResp = GetCampaignsResp;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "SendCampaign", WrapperNamespace = "", IsWrapped = true)]
    public partial class SendCampaignRequest
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.SendCampaignReq SendCampaignReq;

        public SendCampaignRequest()
        {
        }

        public SendCampaignRequest(FlexMail.Service.SendCampaignReq SendCampaignReq)
        {
            this.SendCampaignReq = SendCampaignReq;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "SendCampaignResponse", WrapperNamespace = "", IsWrapped = true)]
    public partial class SendCampaignResponse
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.SendCampaignResp SendCampaignResp;

        public SendCampaignResponse()
        {
        }

        public SendCampaignResponse(FlexMail.Service.SendCampaignResp SendCampaignResp)
        {
            this.SendCampaignResp = SendCampaignResp;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "SendTestCampaign", WrapperNamespace = "", IsWrapped = true)]
    public partial class SendTestCampaignRequest
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.SendTestCampaignReq SendTestCampaignReq;

        public SendTestCampaignRequest()
        {
        }

        public SendTestCampaignRequest(FlexMail.Service.SendTestCampaignReq SendTestCampaignReq)
        {
            this.SendTestCampaignReq = SendTestCampaignReq;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "SendTestCampaignResponse", WrapperNamespace = "", IsWrapped = true)]
    public partial class SendTestCampaignResponse
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.SendTestCampaignResp SendTestCampaignResp;

        public SendTestCampaignResponse()
        {
        }

        public SendTestCampaignResponse(FlexMail.Service.SendTestCampaignResp SendTestCampaignResp)
        {
            this.SendTestCampaignResp = SendTestCampaignResp;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "GetBounces", WrapperNamespace = "", IsWrapped = true)]
    public partial class GetBouncesRequest
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.GetBouncesReq GetBouncesReq;

        public GetBouncesRequest()
        {
        }

        public GetBouncesRequest(FlexMail.Service.GetBouncesReq GetBouncesReq)
        {
            this.GetBouncesReq = GetBouncesReq;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "GetBouncesResponse", WrapperNamespace = "", IsWrapped = true)]
    public partial class GetBouncesResponse
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.GetBouncesResp GetBouncesResp;

        public GetBouncesResponse()
        {
        }

        public GetBouncesResponse(FlexMail.Service.GetBouncesResp GetBouncesResp)
        {
            this.GetBouncesResp = GetBouncesResp;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "GetUnsubscriptions", WrapperNamespace = "", IsWrapped = true)]
    public partial class GetUnsubscriptionsRequest
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.GetUnsubscriptionsReq GetUnsubscriptionsReq;

        public GetUnsubscriptionsRequest()
        {
        }

        public GetUnsubscriptionsRequest(FlexMail.Service.GetUnsubscriptionsReq GetUnsubscriptionsReq)
        {
            this.GetUnsubscriptionsReq = GetUnsubscriptionsReq;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "GetUnsubscriptionsResponse", WrapperNamespace = "", IsWrapped = true)]
    public partial class GetUnsubscriptionsResponse
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.GetUnsubscriptionsResp GetUnsubscriptionsResp;

        public GetUnsubscriptionsResponse()
        {
        }

        public GetUnsubscriptionsResponse(FlexMail.Service.GetUnsubscriptionsResp GetUnsubscriptionsResp)
        {
            this.GetUnsubscriptionsResp = GetUnsubscriptionsResp;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "GetSubscriptions", WrapperNamespace = "", IsWrapped = true)]
    public partial class GetSubscriptionsRequest
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.GetSubscriptionsReq GetSubscriptionsReq;

        public GetSubscriptionsRequest()
        {
        }

        public GetSubscriptionsRequest(FlexMail.Service.GetSubscriptionsReq GetSubscriptionsReq)
        {
            this.GetSubscriptionsReq = GetSubscriptionsReq;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "GetSubscriptionsResponse", WrapperNamespace = "", IsWrapped = true)]
    public partial class GetSubscriptionsResponse
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.GetSubscriptionsResp GetSubscriptionsResp;

        public GetSubscriptionsResponse()
        {
        }

        public GetSubscriptionsResponse(FlexMail.Service.GetSubscriptionsResp GetSubscriptionsResp)
        {
            this.GetSubscriptionsResp = GetSubscriptionsResp;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "GetProfileUpdates", WrapperNamespace = "", IsWrapped = true)]
    public partial class GetProfileUpdatesRequest
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.GetProfileUpdatesReq GetProfileUpdatesReq;

        public GetProfileUpdatesRequest()
        {
        }

        public GetProfileUpdatesRequest(FlexMail.Service.GetProfileUpdatesReq GetProfileUpdatesReq)
        {
            this.GetProfileUpdatesReq = GetProfileUpdatesReq;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "GetProfileUpdatesResponse", WrapperNamespace = "", IsWrapped = true)]
    public partial class GetProfileUpdatesResponse
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.GetProfileUpdatesResp GetProfileUpdatesResp;

        public GetProfileUpdatesResponse()
        {
        }

        public GetProfileUpdatesResponse(FlexMail.Service.GetProfileUpdatesResp GetProfileUpdatesResp)
        {
            this.GetProfileUpdatesResp = GetProfileUpdatesResp;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "GetCampaignTrackingLinks", WrapperNamespace = "", IsWrapped = true)]
    public partial class GetCampaignTrackingLinksRequest
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.GetCampaignTrackingLinksReq GetCampaignTrackingLinksReq;

        public GetCampaignTrackingLinksRequest()
        {
        }

        public GetCampaignTrackingLinksRequest(FlexMail.Service.GetCampaignTrackingLinksReq GetCampaignTrackingLinksReq)
        {
            this.GetCampaignTrackingLinksReq = GetCampaignTrackingLinksReq;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "GetCampaignTrackingLinksResponse", WrapperNamespace = "", IsWrapped = true)]
    public partial class GetCampaignTrackingLinksResponse
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.GetCampaignTrackingLinksResp GetCampaignTrackingLinksResp;

        public GetCampaignTrackingLinksResponse()
        {
        }

        public GetCampaignTrackingLinksResponse(FlexMail.Service.GetCampaignTrackingLinksResp GetCampaignTrackingLinksResp)
        {
            this.GetCampaignTrackingLinksResp = GetCampaignTrackingLinksResp;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "GetTrackingLinkHits", WrapperNamespace = "", IsWrapped = true)]
    public partial class GetTrackingLinkHitsRequest
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.GetTrackingLinkHitsReq GetTrackingLinkHitsReq;

        public GetTrackingLinkHitsRequest()
        {
        }

        public GetTrackingLinkHitsRequest(FlexMail.Service.GetTrackingLinkHitsReq GetTrackingLinkHitsReq)
        {
            this.GetTrackingLinkHitsReq = GetTrackingLinkHitsReq;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "GetTrackingLinkHitsResponse", WrapperNamespace = "", IsWrapped = true)]
    public partial class GetTrackingLinkHitsResponse
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.GetTrackingLinkHitsResp GetTrackingLinkHitsResp;

        public GetTrackingLinkHitsResponse()
        {
        }

        public GetTrackingLinkHitsResponse(FlexMail.Service.GetTrackingLinkHitsResp GetTrackingLinkHitsResp)
        {
            this.GetTrackingLinkHitsResp = GetTrackingLinkHitsResp;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "GetCampaignReport", WrapperNamespace = "", IsWrapped = true)]
    public partial class GetCampaignReportRequest
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.GetCampaignReportReq GetCampaignReportReq;

        public GetCampaignReportRequest()
        {
        }

        public GetCampaignReportRequest(FlexMail.Service.GetCampaignReportReq GetCampaignReportReq)
        {
            this.GetCampaignReportReq = GetCampaignReportReq;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "GetCampaignReportResponse", WrapperNamespace = "", IsWrapped = true)]
    public partial class GetCampaignReportResponse
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.GetCampaignReportResp GetCampaignReportResp;

        public GetCampaignReportResponse()
        {
        }

        public GetCampaignReportResponse(FlexMail.Service.GetCampaignReportResp GetCampaignReportResp)
        {
            this.GetCampaignReportResp = GetCampaignReportResp;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "PutFiles", WrapperNamespace = "", IsWrapped = true)]
    public partial class PutFilesRequest
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.PutFilesReq PutFilesReq;

        public PutFilesRequest()
        {
        }

        public PutFilesRequest(FlexMail.Service.PutFilesReq PutFilesReq)
        {
            this.PutFilesReq = PutFilesReq;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "PutFilesResponse", WrapperNamespace = "", IsWrapped = true)]
    public partial class PutFilesResponse
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.PutFilesResp PutFilesResp;

        public PutFilesResponse()
        {
        }

        public PutFilesResponse(FlexMail.Service.PutFilesResp PutFilesResp)
        {
            this.PutFilesResp = PutFilesResp;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "CreateEfficyActivity", WrapperNamespace = "", IsWrapped = true)]
    public partial class CreateEfficyActivityRequest
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.CreateEfficyActivityReq CreateEfficyActivityReq;

        public CreateEfficyActivityRequest()
        {
        }

        public CreateEfficyActivityRequest(FlexMail.Service.CreateEfficyActivityReq CreateEfficyActivityReq)
        {
            this.CreateEfficyActivityReq = CreateEfficyActivityReq;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "CreateEfficyActivityResponse", WrapperNamespace = "", IsWrapped = true)]
    public partial class CreateEfficyActivityResponse
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.CreateEfficyActivityResp CreateEfficyActivityResp;

        public CreateEfficyActivityResponse()
        {
        }

        public CreateEfficyActivityResponse(FlexMail.Service.CreateEfficyActivityResp CreateEfficyActivityResp)
        {
            this.CreateEfficyActivityResp = CreateEfficyActivityResp;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "UpdateEfficyActivity", WrapperNamespace = "", IsWrapped = true)]
    public partial class UpdateEfficyActivityRequest
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.UpdateEfficyActivityReq UpdateEfficyActivityReq;

        public UpdateEfficyActivityRequest()
        {
        }

        public UpdateEfficyActivityRequest(FlexMail.Service.UpdateEfficyActivityReq UpdateEfficyActivityReq)
        {
            this.UpdateEfficyActivityReq = UpdateEfficyActivityReq;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "UpdateEfficyActivityResponse", WrapperNamespace = "", IsWrapped = true)]
    public partial class UpdateEfficyActivityResponse
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.UpdateEfficyActivityResp UpdateEfficyActivityResp;

        public UpdateEfficyActivityResponse()
        {
        }

        public UpdateEfficyActivityResponse(FlexMail.Service.UpdateEfficyActivityResp UpdateEfficyActivityResp)
        {
            this.UpdateEfficyActivityResp = UpdateEfficyActivityResp;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "DeleteEfficyActivity", WrapperNamespace = "", IsWrapped = true)]
    public partial class DeleteEfficyActivityRequest
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.DeleteEfficyActivityReq DeleteEfficyActivityReq;

        public DeleteEfficyActivityRequest()
        {
        }

        public DeleteEfficyActivityRequest(FlexMail.Service.DeleteEfficyActivityReq DeleteEfficyActivityReq)
        {
            this.DeleteEfficyActivityReq = DeleteEfficyActivityReq;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "DeleteEfficyActivityResponse", WrapperNamespace = "", IsWrapped = true)]
    public partial class DeleteEfficyActivityResponse
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.DeleteEfficyActivityResp DeleteEfficyActivityResp;

        public DeleteEfficyActivityResponse()
        {
        }

        public DeleteEfficyActivityResponse(FlexMail.Service.DeleteEfficyActivityResp DeleteEfficyActivityResp)
        {
            this.DeleteEfficyActivityResp = DeleteEfficyActivityResp;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "GetEfficyActivities", WrapperNamespace = "", IsWrapped = true)]
    public partial class GetEfficyActivitiesRequest
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.GetEfficyActivitiesReq GetEfficyActivitiesReq;

        public GetEfficyActivitiesRequest()
        {
        }

        public GetEfficyActivitiesRequest(FlexMail.Service.GetEfficyActivitiesReq GetEfficyActivitiesReq)
        {
            this.GetEfficyActivitiesReq = GetEfficyActivitiesReq;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "GetEfficyActivitiesResponse", WrapperNamespace = "", IsWrapped = true)]
    public partial class GetEfficyActivitiesResponse
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.GetEfficyActivitiesResp GetEfficyActivitiesResp;

        public GetEfficyActivitiesResponse()
        {
        }

        public GetEfficyActivitiesResponse(FlexMail.Service.GetEfficyActivitiesResp GetEfficyActivitiesResp)
        {
            this.GetEfficyActivitiesResp = GetEfficyActivitiesResp;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "GetEmailAddressHistory", WrapperNamespace = "", IsWrapped = true)]
    public partial class GetEmailAddressHistoryRequest
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.GetEmailAddressHistoryReq GetEmailAddressHistoryReq;

        public GetEmailAddressHistoryRequest()
        {
        }

        public GetEmailAddressHistoryRequest(FlexMail.Service.GetEmailAddressHistoryReq GetEmailAddressHistoryReq)
        {
            this.GetEmailAddressHistoryReq = GetEmailAddressHistoryReq;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "GetEmailAddressHistoryResponse", WrapperNamespace = "", IsWrapped = true)]
    public partial class GetEmailAddressHistoryResponse
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.GetEmailAddressHistoryResp GetEmailAddressHistoryResp;

        public GetEmailAddressHistoryResponse()
        {
        }

        public GetEmailAddressHistoryResponse(FlexMail.Service.GetEmailAddressHistoryResp GetEmailAddressHistoryResp)
        {
            this.GetEmailAddressHistoryResp = GetEmailAddressHistoryResp;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "GetCampaignHistory", WrapperNamespace = "", IsWrapped = true)]
    public partial class GetCampaignHistoryRequest
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.GetCampaignHistoryReq GetCampaignHistoryReq;

        public GetCampaignHistoryRequest()
        {
        }

        public GetCampaignHistoryRequest(FlexMail.Service.GetCampaignHistoryReq GetCampaignHistoryReq)
        {
            this.GetCampaignHistoryReq = GetCampaignHistoryReq;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "GetCampaignHistoryResponse", WrapperNamespace = "", IsWrapped = true)]
    public partial class GetCampaignHistoryResponse
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.GetCampaignHistoryResp GetCampaignHistoryResp;

        public GetCampaignHistoryResponse()
        {
        }

        public GetCampaignHistoryResponse(FlexMail.Service.GetCampaignHistoryResp GetCampaignHistoryResp)
        {
            this.GetCampaignHistoryResp = GetCampaignHistoryResp;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "GetHistory", WrapperNamespace = "", IsWrapped = true)]
    public partial class GetHistoryRequest
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.GetHistoryReq GetHistoryReq;

        public GetHistoryRequest()
        {
        }

        public GetHistoryRequest(FlexMail.Service.GetHistoryReq GetHistoryReq)
        {
            this.GetHistoryReq = GetHistoryReq;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "GetHistoryResponse", WrapperNamespace = "", IsWrapped = true)]
    public partial class GetHistoryResponse
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.GetHistoryResp GetHistoryResp;

        public GetHistoryResponse()
        {
        }

        public GetHistoryResponse(FlexMail.Service.GetHistoryResp GetHistoryResp)
        {
            this.GetHistoryResp = GetHistoryResp;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "GetFormResults", WrapperNamespace = "", IsWrapped = true)]
    public partial class GetFormResultsRequest
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.GetFormResultsReq GetFormResultsReq;

        public GetFormResultsRequest()
        {
        }

        public GetFormResultsRequest(FlexMail.Service.GetFormResultsReq GetFormResultsReq)
        {
            this.GetFormResultsReq = GetFormResultsReq;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "GetFormResultsResponse", WrapperNamespace = "", IsWrapped = true)]
    public partial class GetFormResultsResponse
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.GetFormResultsResp GetFormResultsResp;

        public GetFormResultsResponse()
        {
        }

        public GetFormResultsResponse(FlexMail.Service.GetFormResultsResp GetFormResultsResp)
        {
            this.GetFormResultsResp = GetFormResultsResp;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "GetForms", WrapperNamespace = "", IsWrapped = true)]
    public partial class GetFormsRequest
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.GetFormsReq GetFormsReq;

        public GetFormsRequest()
        {
        }

        public GetFormsRequest(FlexMail.Service.GetFormsReq GetFormsReq)
        {
            this.GetFormsReq = GetFormsReq;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "GetFormsResponse", WrapperNamespace = "", IsWrapped = true)]
    public partial class GetFormsResponse
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.GetFormsResp GetFormsResp;

        public GetFormsResponse()
        {
        }

        public GetFormsResponse(FlexMail.Service.GetFormsResp GetFormsResp)
        {
            this.GetFormsResp = GetFormsResp;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "GetBalance", WrapperNamespace = "", IsWrapped = true)]
    public partial class GetBalanceRequest
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.GetBalanceReq GetBalanceReq;

        public GetBalanceRequest()
        {
        }

        public GetBalanceRequest(FlexMail.Service.GetBalanceReq GetBalanceReq)
        {
            this.GetBalanceReq = GetBalanceReq;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "GetBalanceResponse", WrapperNamespace = "", IsWrapped = true)]
    public partial class GetBalanceResponse
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.GetBalanceResp GetBalanceResp;

        public GetBalanceResponse()
        {
        }

        public GetBalanceResponse(FlexMail.Service.GetBalanceResp GetBalanceResp)
        {
            this.GetBalanceResp = GetBalanceResp;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "GetCampaignSummary", WrapperNamespace = "", IsWrapped = true)]
    public partial class GetCampaignSummaryRequest
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.GetCampaignSummaryReq GetCampaignSummaryReq;

        public GetCampaignSummaryRequest()
        {
        }

        public GetCampaignSummaryRequest(FlexMail.Service.GetCampaignSummaryReq GetCampaignSummaryReq)
        {
            this.GetCampaignSummaryReq = GetCampaignSummaryReq;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "GetCampaignSummaryResponse", WrapperNamespace = "", IsWrapped = true)]
    public partial class GetCampaignSummaryResponse
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.GetCampaignSummaryResp GetCampaignSummaryResp;

        public GetCampaignSummaryResponse()
        {
        }

        public GetCampaignSummaryResponse(FlexMail.Service.GetCampaignSummaryResp GetCampaignSummaryResp)
        {
            this.GetCampaignSummaryResp = GetCampaignSummaryResp;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "ImportBlacklist", WrapperNamespace = "", IsWrapped = true)]
    public partial class ImportBlacklistRequest
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.ImportBlacklistReq ImportBlacklistReq;

        public ImportBlacklistRequest()
        {
        }

        public ImportBlacklistRequest(FlexMail.Service.ImportBlacklistReq ImportBlacklistReq)
        {
            this.ImportBlacklistReq = ImportBlacklistReq;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "ImportBlacklistResponse", WrapperNamespace = "", IsWrapped = true)]
    public partial class ImportBlacklistResponse
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.ImportBlacklistResp ImportBlacklistResp;

        public ImportBlacklistResponse()
        {
        }

        public ImportBlacklistResponse(FlexMail.Service.ImportBlacklistResp ImportBlacklistResp)
        {
            this.ImportBlacklistResp = ImportBlacklistResp;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "CreateAccount", WrapperNamespace = "", IsWrapped = true)]
    public partial class CreateAccountRequest
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.CreateAccountReq CreateAccountReq;

        public CreateAccountRequest()
        {
        }

        public CreateAccountRequest(FlexMail.Service.CreateAccountReq CreateAccountReq)
        {
            this.CreateAccountReq = CreateAccountReq;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "CreateAccountResponse", WrapperNamespace = "", IsWrapped = true)]
    public partial class CreateAccountResponse
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.CreateAccountResp CreateAccountResp;

        public CreateAccountResponse()
        {
        }

        public CreateAccountResponse(FlexMail.Service.CreateAccountResp CreateAccountResp)
        {
            this.CreateAccountResp = CreateAccountResp;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "UpdateAccount", WrapperNamespace = "", IsWrapped = true)]
    public partial class UpdateAccountRequest
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.UpdateAccountReq UpdateAccountReq;

        public UpdateAccountRequest()
        {
        }

        public UpdateAccountRequest(FlexMail.Service.UpdateAccountReq UpdateAccountReq)
        {
            this.UpdateAccountReq = UpdateAccountReq;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "UpdateAccountResponse", WrapperNamespace = "", IsWrapped = true)]
    public partial class UpdateAccountResponse
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.UpdateAccountResp UpdateAccountResp;

        public UpdateAccountResponse()
        {
        }

        public UpdateAccountResponse(FlexMail.Service.UpdateAccountResp UpdateAccountResp)
        {
            this.UpdateAccountResp = UpdateAccountResp;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "DeleteAccount", WrapperNamespace = "", IsWrapped = true)]
    public partial class DeleteAccountRequest
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.DeleteAccountReq DeleteAccountReq;

        public DeleteAccountRequest()
        {
        }

        public DeleteAccountRequest(FlexMail.Service.DeleteAccountReq DeleteAccountReq)
        {
            this.DeleteAccountReq = DeleteAccountReq;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "DeleteAccountResponse", WrapperNamespace = "", IsWrapped = true)]
    public partial class DeleteAccountResponse
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.DeleteAccountResp DeleteAccountResp;

        public DeleteAccountResponse()
        {
        }

        public DeleteAccountResponse(FlexMail.Service.DeleteAccountResp DeleteAccountResp)
        {
            this.DeleteAccountResp = DeleteAccountResp;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "GetAccounts", WrapperNamespace = "", IsWrapped = true)]
    public partial class GetAccountsRequest
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.GetAccountsReq GetAccountsReq;

        public GetAccountsRequest()
        {
        }

        public GetAccountsRequest(FlexMail.Service.GetAccountsReq GetAccountsReq)
        {
            this.GetAccountsReq = GetAccountsReq;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "GetAccountsResponse", WrapperNamespace = "", IsWrapped = true)]
    public partial class GetAccountsResponse
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.GetAccountsResp GetAccountsResp;

        public GetAccountsResponse()
        {
        }

        public GetAccountsResponse(FlexMail.Service.GetAccountsResp GetAccountsResp)
        {
            this.GetAccountsResp = GetAccountsResp;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "AccountAddCredits", WrapperNamespace = "", IsWrapped = true)]
    public partial class AccountAddCreditsRequest
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.AccountAddCreditsReq AccountAddCreditsReq;

        public AccountAddCreditsRequest()
        {
        }

        public AccountAddCreditsRequest(FlexMail.Service.AccountAddCreditsReq AccountAddCreditsReq)
        {
            this.AccountAddCreditsReq = AccountAddCreditsReq;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "AccountAddCreditsResponse", WrapperNamespace = "", IsWrapped = true)]
    public partial class AccountAddCreditsResponse
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.AccountAddCreditsResp AccountAddCreditsResp;

        public AccountAddCreditsResponse()
        {
        }

        public AccountAddCreditsResponse(FlexMail.Service.AccountAddCreditsResp AccountAddCreditsResp)
        {
            this.AccountAddCreditsResp = AccountAddCreditsResp;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "AccountRevokeCredits", WrapperNamespace = "", IsWrapped = true)]
    public partial class AccountRevokeCreditsRequest
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.AccountRevokeCreditsReq AccountRevokeCreditsReq;

        public AccountRevokeCreditsRequest()
        {
        }

        public AccountRevokeCreditsRequest(FlexMail.Service.AccountRevokeCreditsReq AccountRevokeCreditsReq)
        {
            this.AccountRevokeCreditsReq = AccountRevokeCreditsReq;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "AccountRevokeCreditsResponse", WrapperNamespace = "", IsWrapped = true)]
    public partial class AccountRevokeCreditsResponse
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.AccountRevokeCreditsResp AccountRevokeCreditsResp;

        public AccountRevokeCreditsResponse()
        {
        }

        public AccountRevokeCreditsResponse(FlexMail.Service.AccountRevokeCreditsResp AccountRevokeCreditsResp)
        {
            this.AccountRevokeCreditsResp = AccountRevokeCreditsResp;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "GetCustomReport", WrapperNamespace = "", IsWrapped = true)]
    public partial class GetCustomReportRequest
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.GetCustomReportReq GetCustomReportReq;

        public GetCustomReportRequest()
        {
        }

        public GetCustomReportRequest(FlexMail.Service.GetCustomReportReq GetCustomReportReq)
        {
            this.GetCustomReportReq = GetCustomReportReq;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "GetCustomReportResponse", WrapperNamespace = "", IsWrapped = true)]
    public partial class GetCustomReportResponse
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.GetCustomReportResp GetCustomReportResp;

        public GetCustomReportResponse()
        {
        }

        public GetCustomReportResponse(FlexMail.Service.GetCustomReportResp GetCustomReportResp)
        {
            this.GetCustomReportResp = GetCustomReportResp;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "RegisterTransactionEnd", WrapperNamespace = "", IsWrapped = true)]
    public partial class RegisterTransactionEndRequest
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.RegisterTransactionEndReq RegisterTransactionEndReq;

        public RegisterTransactionEndRequest()
        {
        }

        public RegisterTransactionEndRequest(FlexMail.Service.RegisterTransactionEndReq RegisterTransactionEndReq)
        {
            this.RegisterTransactionEndReq = RegisterTransactionEndReq;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "RegisterTransactionEndResponse", WrapperNamespace = "", IsWrapped = true)]
    public partial class RegisterTransactionEndResponse
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.RegisterTransactionEndResp RegisterTransactionEndResp;

        public RegisterTransactionEndResponse()
        {
        }

        public RegisterTransactionEndResponse(FlexMail.Service.RegisterTransactionEndResp RegisterTransactionEndResp)
        {
            this.RegisterTransactionEndResp = RegisterTransactionEndResp;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "UpdateTruvoOrder", WrapperNamespace = "", IsWrapped = true)]
    public partial class UpdateTruvoOrderRequest
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.UpdateTruvoOrderReq UpdateTruvoOrderReq;

        public UpdateTruvoOrderRequest()
        {
        }

        public UpdateTruvoOrderRequest(FlexMail.Service.UpdateTruvoOrderReq UpdateTruvoOrderReq)
        {
            this.UpdateTruvoOrderReq = UpdateTruvoOrderReq;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "UpdateTruvoOrderResponse", WrapperNamespace = "", IsWrapped = true)]
    public partial class UpdateTruvoOrderResponse
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.UpdateTruvoOrderResp UpdateTruvoOrderResp;

        public UpdateTruvoOrderResponse()
        {
        }

        public UpdateTruvoOrderResponse(FlexMail.Service.UpdateTruvoOrderResp UpdateTruvoOrderResp)
        {
            this.UpdateTruvoOrderResp = UpdateTruvoOrderResp;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "GVImportSelection", WrapperNamespace = "", IsWrapped = true)]
    public partial class GVImportSelectionRequest
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.GVImportSelectionReq GVImportSelectionReq;

        public GVImportSelectionRequest()
        {
        }

        public GVImportSelectionRequest(FlexMail.Service.GVImportSelectionReq GVImportSelectionReq)
        {
            this.GVImportSelectionReq = GVImportSelectionReq;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(WrapperName = "GVImportSelectionResponse", WrapperNamespace = "", IsWrapped = true)]
    public partial class GVImportSelectionResponse
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "", Order = 0)]
        public FlexMail.Service.GVImportSelectionResp GVImportSelectionResp;

        public GVImportSelectionResponse()
        {
        }

        public GVImportSelectionResponse(FlexMail.Service.GVImportSelectionResp GVImportSelectionResp)
        {
            this.GVImportSelectionResp = GVImportSelectionResp;
        }
    }

    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    public interface FlexmailAPIPortTypeChannel : FlexMail.Service.FlexmailAPIPortType, System.ServiceModel.IClientChannel
    {
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    public partial class FlexmailAPIPortTypeClient : System.ServiceModel.ClientBase<FlexMail.Service.FlexmailAPIPortType>, FlexMail.Service.FlexmailAPIPortType
    {

        public FlexmailAPIPortTypeClient()
        {
        }

        public FlexmailAPIPortTypeClient(string endpointConfigurationName) :
                base(endpointConfigurationName)
        {
        }

        public FlexmailAPIPortTypeClient(string endpointConfigurationName, string remoteAddress) :
                base(endpointConfigurationName, remoteAddress)
        {
        }

        public FlexmailAPIPortTypeClient(string endpointConfigurationName, System.ServiceModel.EndpointAddress remoteAddress) :
                base(endpointConfigurationName, remoteAddress)
        {
        }

        public FlexmailAPIPortTypeClient(System.ServiceModel.Channels.Binding binding, System.ServiceModel.EndpointAddress remoteAddress) :
                base(binding, remoteAddress)
        {
        }

        public FlexMail.Service.CreateCategoryResponse CreateCategory(FlexMail.Service.CreateCategoryRequest request)
        {
            return base.Channel.CreateCategory(request);
        }

        public System.Threading.Tasks.Task<FlexMail.Service.CreateCategoryResponse> CreateCategoryAsync(FlexMail.Service.CreateCategoryRequest request)
        {
            return base.Channel.CreateCategoryAsync(request);
        }

        public FlexMail.Service.UpdateCategoryResponse UpdateCategory(FlexMail.Service.UpdateCategoryRequest request)
        {
            return base.Channel.UpdateCategory(request);
        }

        public System.Threading.Tasks.Task<FlexMail.Service.UpdateCategoryResponse> UpdateCategoryAsync(FlexMail.Service.UpdateCategoryRequest request)
        {
            return base.Channel.UpdateCategoryAsync(request);
        }

        public FlexMail.Service.DeleteCategoryResponse DeleteCategory(FlexMail.Service.DeleteCategoryRequest request)
        {
            return base.Channel.DeleteCategory(request);
        }

        public System.Threading.Tasks.Task<FlexMail.Service.DeleteCategoryResponse> DeleteCategoryAsync(FlexMail.Service.DeleteCategoryRequest request)
        {
            return base.Channel.DeleteCategoryAsync(request);
        }

        public FlexMail.Service.GetCategoriesResponse GetCategories(FlexMail.Service.GetCategoriesRequest request)
        {
            return base.Channel.GetCategories(request);
        }

        public System.Threading.Tasks.Task<FlexMail.Service.GetCategoriesResponse> GetCategoriesAsync(FlexMail.Service.GetCategoriesRequest request)
        {
            return base.Channel.GetCategoriesAsync(request);
        }

        public FlexMail.Service.CreateMailingListResponse CreateMailingList(FlexMail.Service.CreateMailingListRequest request)
        {
            return base.Channel.CreateMailingList(request);
        }

        public System.Threading.Tasks.Task<FlexMail.Service.CreateMailingListResponse> CreateMailingListAsync(FlexMail.Service.CreateMailingListRequest request)
        {
            return base.Channel.CreateMailingListAsync(request);
        }

        public FlexMail.Service.UpdateMailingListResponse UpdateMailingList(FlexMail.Service.UpdateMailingListRequest request)
        {
            return base.Channel.UpdateMailingList(request);
        }

        public System.Threading.Tasks.Task<FlexMail.Service.UpdateMailingListResponse> UpdateMailingListAsync(FlexMail.Service.UpdateMailingListRequest request)
        {
            return base.Channel.UpdateMailingListAsync(request);
        }

        public FlexMail.Service.DeleteMailingListResponse DeleteMailingList(FlexMail.Service.DeleteMailingListRequest request)
        {
            return base.Channel.DeleteMailingList(request);
        }

        public System.Threading.Tasks.Task<FlexMail.Service.DeleteMailingListResponse> DeleteMailingListAsync(FlexMail.Service.DeleteMailingListRequest request)
        {
            return base.Channel.DeleteMailingListAsync(request);
        }

        public FlexMail.Service.TruncateMailingListResponse TruncateMailingList(FlexMail.Service.TruncateMailingListRequest request)
        {
            return base.Channel.TruncateMailingList(request);
        }

        public System.Threading.Tasks.Task<FlexMail.Service.TruncateMailingListResponse> TruncateMailingListAsync(FlexMail.Service.TruncateMailingListRequest request)
        {
            return base.Channel.TruncateMailingListAsync(request);
        }

        public FlexMail.Service.GetMailingListsResponse GetMailingLists(FlexMail.Service.GetMailingListsRequest request)
        {
            return base.Channel.GetMailingLists(request);
        }

        public System.Threading.Tasks.Task<FlexMail.Service.GetMailingListsResponse> GetMailingListsAsync(FlexMail.Service.GetMailingListsRequest request)
        {
            return base.Channel.GetMailingListsAsync(request);
        }

        public FlexMail.Service.CreateEmailAddressResponse CreateEmailAddress(FlexMail.Service.CreateEmailAddressRequest request)
        {
            return base.Channel.CreateEmailAddress(request);
        }

        public System.Threading.Tasks.Task<FlexMail.Service.CreateEmailAddressResponse> CreateEmailAddressAsync(FlexMail.Service.CreateEmailAddressRequest request)
        {
            return base.Channel.CreateEmailAddressAsync(request);
        }

        public FlexMail.Service.UpdateEmailAddressResponse UpdateEmailAddress(FlexMail.Service.UpdateEmailAddressRequest request)
        {
            return base.Channel.UpdateEmailAddress(request);
        }

        public System.Threading.Tasks.Task<FlexMail.Service.UpdateEmailAddressResponse> UpdateEmailAddressAsync(FlexMail.Service.UpdateEmailAddressRequest request)
        {
            return base.Channel.UpdateEmailAddressAsync(request);
        }

        public FlexMail.Service.DeleteEmailAddressResponse DeleteEmailAddress(FlexMail.Service.DeleteEmailAddressRequest request)
        {
            return base.Channel.DeleteEmailAddress(request);
        }

        public System.Threading.Tasks.Task<FlexMail.Service.DeleteEmailAddressResponse> DeleteEmailAddressAsync(FlexMail.Service.DeleteEmailAddressRequest request)
        {
            return base.Channel.DeleteEmailAddressAsync(request);
        }

        public FlexMail.Service.ImportEmailAddressesResponse ImportEmailAddresses(FlexMail.Service.ImportEmailAddressesRequest request)
        {
            return base.Channel.ImportEmailAddresses(request);
        }

        public System.Threading.Tasks.Task<FlexMail.Service.ImportEmailAddressesResponse> ImportEmailAddressesAsync(FlexMail.Service.ImportEmailAddressesRequest request)
        {
            return base.Channel.ImportEmailAddressesAsync(request);
        }

        public FlexMail.Service.GetEmailAddressesResponse GetEmailAddresses(FlexMail.Service.GetEmailAddressesRequest request)
        {
            return base.Channel.GetEmailAddresses(request);
        }

        public System.Threading.Tasks.Task<FlexMail.Service.GetEmailAddressesResponse> GetEmailAddressesAsync(FlexMail.Service.GetEmailAddressesRequest request)
        {
            return base.Channel.GetEmailAddressesAsync(request);
        }

        public FlexMail.Service.GetEmailAddressSubscriptionsResponse GetEmailAddressSubscriptions(FlexMail.Service.GetEmailAddressSubscriptionsRequest request)
        {
            return base.Channel.GetEmailAddressSubscriptions(request);
        }

        public System.Threading.Tasks.Task<FlexMail.Service.GetEmailAddressSubscriptionsResponse> GetEmailAddressSubscriptionsAsync(FlexMail.Service.GetEmailAddressSubscriptionsRequest request)
        {
            return base.Channel.GetEmailAddressSubscriptionsAsync(request);
        }

        public FlexMail.Service.CreateMessageResponse CreateMessage(FlexMail.Service.CreateMessageRequest request)
        {
            return base.Channel.CreateMessage(request);
        }

        public System.Threading.Tasks.Task<FlexMail.Service.CreateMessageResponse> CreateMessageAsync(FlexMail.Service.CreateMessageRequest request)
        {
            return base.Channel.CreateMessageAsync(request);
        }

        public FlexMail.Service.UpdateMessageResponse UpdateMessage(FlexMail.Service.UpdateMessageRequest request)
        {
            return base.Channel.UpdateMessage(request);
        }

        public System.Threading.Tasks.Task<FlexMail.Service.UpdateMessageResponse> UpdateMessageAsync(FlexMail.Service.UpdateMessageRequest request)
        {
            return base.Channel.UpdateMessageAsync(request);
        }

        public FlexMail.Service.DeleteMessageResponse DeleteMessage(FlexMail.Service.DeleteMessageRequest request)
        {
            return base.Channel.DeleteMessage(request);
        }

        public System.Threading.Tasks.Task<FlexMail.Service.DeleteMessageResponse> DeleteMessageAsync(FlexMail.Service.DeleteMessageRequest request)
        {
            return base.Channel.DeleteMessageAsync(request);
        }

        public FlexMail.Service.GetMessagesResponse GetMessages(FlexMail.Service.GetMessagesRequest request)
        {
            return base.Channel.GetMessages(request);
        }

        public System.Threading.Tasks.Task<FlexMail.Service.GetMessagesResponse> GetMessagesAsync(FlexMail.Service.GetMessagesRequest request)
        {
            return base.Channel.GetMessagesAsync(request);
        }

        public FlexMail.Service.CreateLandingPageResponse CreateLandingPage(FlexMail.Service.CreateLandingPageRequest request)
        {
            return base.Channel.CreateLandingPage(request);
        }

        public System.Threading.Tasks.Task<FlexMail.Service.CreateLandingPageResponse> CreateLandingPageAsync(FlexMail.Service.CreateLandingPageRequest request)
        {
            return base.Channel.CreateLandingPageAsync(request);
        }

        public FlexMail.Service.UpdateLandingPageResponse UpdateLandingPage(FlexMail.Service.UpdateLandingPageRequest request)
        {
            return base.Channel.UpdateLandingPage(request);
        }

        public System.Threading.Tasks.Task<FlexMail.Service.UpdateLandingPageResponse> UpdateLandingPageAsync(FlexMail.Service.UpdateLandingPageRequest request)
        {
            return base.Channel.UpdateLandingPageAsync(request);
        }

        public FlexMail.Service.DeleteLandingPageResponse DeleteLandingPage(FlexMail.Service.DeleteLandingPageRequest request)
        {
            return base.Channel.DeleteLandingPage(request);
        }

        public System.Threading.Tasks.Task<FlexMail.Service.DeleteLandingPageResponse> DeleteLandingPageAsync(FlexMail.Service.DeleteLandingPageRequest request)
        {
            return base.Channel.DeleteLandingPageAsync(request);
        }

        public FlexMail.Service.GetLandingPagesResponse GetLandingPages(FlexMail.Service.GetLandingPagesRequest request)
        {
            return base.Channel.GetLandingPages(request);
        }

        public System.Threading.Tasks.Task<FlexMail.Service.GetLandingPagesResponse> GetLandingPagesAsync(FlexMail.Service.GetLandingPagesRequest request)
        {
            return base.Channel.GetLandingPagesAsync(request);
        }

        public FlexMail.Service.CreateTemplateResponse CreateTemplate(FlexMail.Service.CreateTemplateRequest request)
        {
            return base.Channel.CreateTemplate(request);
        }

        public System.Threading.Tasks.Task<FlexMail.Service.CreateTemplateResponse> CreateTemplateAsync(FlexMail.Service.CreateTemplateRequest request)
        {
            return base.Channel.CreateTemplateAsync(request);
        }

        public FlexMail.Service.UpdateTemplateResponse UpdateTemplate(FlexMail.Service.UpdateTemplateRequest request)
        {
            return base.Channel.UpdateTemplate(request);
        }

        public System.Threading.Tasks.Task<FlexMail.Service.UpdateTemplateResponse> UpdateTemplateAsync(FlexMail.Service.UpdateTemplateRequest request)
        {
            return base.Channel.UpdateTemplateAsync(request);
        }

        public FlexMail.Service.DeleteTemplateResponse DeleteTemplate(FlexMail.Service.DeleteTemplateRequest request)
        {
            return base.Channel.DeleteTemplate(request);
        }

        public System.Threading.Tasks.Task<FlexMail.Service.DeleteTemplateResponse> DeleteTemplateAsync(FlexMail.Service.DeleteTemplateRequest request)
        {
            return base.Channel.DeleteTemplateAsync(request);
        }

        public FlexMail.Service.GetTemplatesResponse GetTemplates(FlexMail.Service.GetTemplatesRequest request)
        {
            return base.Channel.GetTemplates(request);
        }

        public System.Threading.Tasks.Task<FlexMail.Service.GetTemplatesResponse> GetTemplatesAsync(FlexMail.Service.GetTemplatesRequest request)
        {
            return base.Channel.GetTemplatesAsync(request);
        }

        public FlexMail.Service.CreatePreferenceResponse CreatePreference(FlexMail.Service.CreatePreferenceRequest request)
        {
            return base.Channel.CreatePreference(request);
        }

        public System.Threading.Tasks.Task<FlexMail.Service.CreatePreferenceResponse> CreatePreferenceAsync(FlexMail.Service.CreatePreferenceRequest request)
        {
            return base.Channel.CreatePreferenceAsync(request);
        }

        public FlexMail.Service.UpdatePreferenceResponse UpdatePreference(FlexMail.Service.UpdatePreferenceRequest request)
        {
            return base.Channel.UpdatePreference(request);
        }

        public System.Threading.Tasks.Task<FlexMail.Service.UpdatePreferenceResponse> UpdatePreferenceAsync(FlexMail.Service.UpdatePreferenceRequest request)
        {
            return base.Channel.UpdatePreferenceAsync(request);
        }

        public FlexMail.Service.DeletePreferenceResponse DeletePreference(FlexMail.Service.DeletePreferenceRequest request)
        {
            return base.Channel.DeletePreference(request);
        }

        public System.Threading.Tasks.Task<FlexMail.Service.DeletePreferenceResponse> DeletePreferenceAsync(FlexMail.Service.DeletePreferenceRequest request)
        {
            return base.Channel.DeletePreferenceAsync(request);
        }

        public FlexMail.Service.GetPreferencesResponse GetPreferences(FlexMail.Service.GetPreferencesRequest request)
        {
            return base.Channel.GetPreferences(request);
        }

        public System.Threading.Tasks.Task<FlexMail.Service.GetPreferencesResponse> GetPreferencesAsync(FlexMail.Service.GetPreferencesRequest request)
        {
            return base.Channel.GetPreferencesAsync(request);
        }

        public FlexMail.Service.CreateGroupResponse CreateGroup(FlexMail.Service.CreateGroupRequest request)
        {
            return base.Channel.CreateGroup(request);
        }

        public System.Threading.Tasks.Task<FlexMail.Service.CreateGroupResponse> CreateGroupAsync(FlexMail.Service.CreateGroupRequest request)
        {
            return base.Channel.CreateGroupAsync(request);
        }

        public FlexMail.Service.UpdateGroupResponse UpdateGroup(FlexMail.Service.UpdateGroupRequest request)
        {
            return base.Channel.UpdateGroup(request);
        }

        public System.Threading.Tasks.Task<FlexMail.Service.UpdateGroupResponse> UpdateGroupAsync(FlexMail.Service.UpdateGroupRequest request)
        {
            return base.Channel.UpdateGroupAsync(request);
        }

        public FlexMail.Service.DeleteGroupResponse DeleteGroup(FlexMail.Service.DeleteGroupRequest request)
        {
            return base.Channel.DeleteGroup(request);
        }

        public System.Threading.Tasks.Task<FlexMail.Service.DeleteGroupResponse> DeleteGroupAsync(FlexMail.Service.DeleteGroupRequest request)
        {
            return base.Channel.DeleteGroupAsync(request);
        }

        public FlexMail.Service.GetGroupsResponse GetGroups(FlexMail.Service.GetGroupsRequest request)
        {
            return base.Channel.GetGroups(request);
        }

        public System.Threading.Tasks.Task<FlexMail.Service.GetGroupsResponse> GetGroupsAsync(FlexMail.Service.GetGroupsRequest request)
        {
            return base.Channel.GetGroupsAsync(request);
        }

        public FlexMail.Service.ImportGroupSubscriptionsResponse ImportGroupSubscriptions(FlexMail.Service.ImportGroupSubscriptionsRequest request)
        {
            return base.Channel.ImportGroupSubscriptions(request);
        }

        public System.Threading.Tasks.Task<FlexMail.Service.ImportGroupSubscriptionsResponse> ImportGroupSubscriptionsAsync(FlexMail.Service.ImportGroupSubscriptionsRequest request)
        {
            return base.Channel.ImportGroupSubscriptionsAsync(request);
        }

        public FlexMail.Service.CreateGroupSubscriptionResponse CreateGroupSubscription(FlexMail.Service.CreateGroupSubscriptionRequest request)
        {
            return base.Channel.CreateGroupSubscription(request);
        }

        public System.Threading.Tasks.Task<FlexMail.Service.CreateGroupSubscriptionResponse> CreateGroupSubscriptionAsync(FlexMail.Service.CreateGroupSubscriptionRequest request)
        {
            return base.Channel.CreateGroupSubscriptionAsync(request);
        }

        public FlexMail.Service.DeleteGroupSubscriptionResponse DeleteGroupSubscription(FlexMail.Service.DeleteGroupSubscriptionRequest request)
        {
            return base.Channel.DeleteGroupSubscription(request);
        }

        public System.Threading.Tasks.Task<FlexMail.Service.DeleteGroupSubscriptionResponse> DeleteGroupSubscriptionAsync(FlexMail.Service.DeleteGroupSubscriptionRequest request)
        {
            return base.Channel.DeleteGroupSubscriptionAsync(request);
        }

        public FlexMail.Service.CreateCampaignResponse CreateCampaign(FlexMail.Service.CreateCampaignRequest request)
        {
            return base.Channel.CreateCampaign(request);
        }

        public System.Threading.Tasks.Task<FlexMail.Service.CreateCampaignResponse> CreateCampaignAsync(FlexMail.Service.CreateCampaignRequest request)
        {
            return base.Channel.CreateCampaignAsync(request);
        }

        public FlexMail.Service.UpdateCampaignResponse UpdateCampaign(FlexMail.Service.UpdateCampaignRequest request)
        {
            return base.Channel.UpdateCampaign(request);
        }

        public System.Threading.Tasks.Task<FlexMail.Service.UpdateCampaignResponse> UpdateCampaignAsync(FlexMail.Service.UpdateCampaignRequest request)
        {
            return base.Channel.UpdateCampaignAsync(request);
        }

        public FlexMail.Service.DeleteCampaignResponse DeleteCampaign(FlexMail.Service.DeleteCampaignRequest request)
        {
            return base.Channel.DeleteCampaign(request);
        }

        public System.Threading.Tasks.Task<FlexMail.Service.DeleteCampaignResponse> DeleteCampaignAsync(FlexMail.Service.DeleteCampaignRequest request)
        {
            return base.Channel.DeleteCampaignAsync(request);
        }

        public FlexMail.Service.GetCampaignsResponse GetCampaigns(FlexMail.Service.GetCampaignsRequest request)
        {
            return base.Channel.GetCampaigns(request);
        }

        public System.Threading.Tasks.Task<FlexMail.Service.GetCampaignsResponse> GetCampaignsAsync(FlexMail.Service.GetCampaignsRequest request)
        {
            return base.Channel.GetCampaignsAsync(request);
        }

        public FlexMail.Service.SendCampaignResponse SendCampaign(FlexMail.Service.SendCampaignRequest request)
        {
            return base.Channel.SendCampaign(request);
        }

        public System.Threading.Tasks.Task<FlexMail.Service.SendCampaignResponse> SendCampaignAsync(FlexMail.Service.SendCampaignRequest request)
        {
            return base.Channel.SendCampaignAsync(request);
        }

        public FlexMail.Service.SendTestCampaignResponse SendTestCampaign(FlexMail.Service.SendTestCampaignRequest request)
        {
            return base.Channel.SendTestCampaign(request);
        }

        public System.Threading.Tasks.Task<FlexMail.Service.SendTestCampaignResponse> SendTestCampaignAsync(FlexMail.Service.SendTestCampaignRequest request)
        {
            return base.Channel.SendTestCampaignAsync(request);
        }

        public FlexMail.Service.GetBouncesResponse GetBounces(FlexMail.Service.GetBouncesRequest request)
        {
            return base.Channel.GetBounces(request);
        }

        public System.Threading.Tasks.Task<FlexMail.Service.GetBouncesResponse> GetBouncesAsync(FlexMail.Service.GetBouncesRequest request)
        {
            return base.Channel.GetBouncesAsync(request);
        }

        public FlexMail.Service.GetUnsubscriptionsResponse GetUnsubscriptions(FlexMail.Service.GetUnsubscriptionsRequest request)
        {
            return base.Channel.GetUnsubscriptions(request);
        }

        public System.Threading.Tasks.Task<FlexMail.Service.GetUnsubscriptionsResponse> GetUnsubscriptionsAsync(FlexMail.Service.GetUnsubscriptionsRequest request)
        {
            return base.Channel.GetUnsubscriptionsAsync(request);
        }

        public FlexMail.Service.GetSubscriptionsResponse GetSubscriptions(FlexMail.Service.GetSubscriptionsRequest request)
        {
            return base.Channel.GetSubscriptions(request);
        }

        public System.Threading.Tasks.Task<FlexMail.Service.GetSubscriptionsResponse> GetSubscriptionsAsync(FlexMail.Service.GetSubscriptionsRequest request)
        {
            return base.Channel.GetSubscriptionsAsync(request);
        }

        public FlexMail.Service.GetProfileUpdatesResponse GetProfileUpdates(FlexMail.Service.GetProfileUpdatesRequest request)
        {
            return base.Channel.GetProfileUpdates(request);
        }

        public System.Threading.Tasks.Task<FlexMail.Service.GetProfileUpdatesResponse> GetProfileUpdatesAsync(FlexMail.Service.GetProfileUpdatesRequest request)
        {
            return base.Channel.GetProfileUpdatesAsync(request);
        }

        public FlexMail.Service.GetCampaignTrackingLinksResponse GetCampaignTrackingLinks(FlexMail.Service.GetCampaignTrackingLinksRequest request)
        {
            return base.Channel.GetCampaignTrackingLinks(request);
        }

        public System.Threading.Tasks.Task<FlexMail.Service.GetCampaignTrackingLinksResponse> GetCampaignTrackingLinksAsync(FlexMail.Service.GetCampaignTrackingLinksRequest request)
        {
            return base.Channel.GetCampaignTrackingLinksAsync(request);
        }

        public FlexMail.Service.GetTrackingLinkHitsResponse GetTrackingLinkHits(FlexMail.Service.GetTrackingLinkHitsRequest request)
        {
            return base.Channel.GetTrackingLinkHits(request);
        }

        public System.Threading.Tasks.Task<FlexMail.Service.GetTrackingLinkHitsResponse> GetTrackingLinkHitsAsync(FlexMail.Service.GetTrackingLinkHitsRequest request)
        {
            return base.Channel.GetTrackingLinkHitsAsync(request);
        }

        public FlexMail.Service.GetCampaignReportResponse GetCampaignReport(FlexMail.Service.GetCampaignReportRequest request)
        {
            return base.Channel.GetCampaignReport(request);
        }

        public System.Threading.Tasks.Task<FlexMail.Service.GetCampaignReportResponse> GetCampaignReportAsync(FlexMail.Service.GetCampaignReportRequest request)
        {
            return base.Channel.GetCampaignReportAsync(request);
        }

        public FlexMail.Service.PutFilesResponse PutFiles(FlexMail.Service.PutFilesRequest request)
        {
            return base.Channel.PutFiles(request);
        }

        public System.Threading.Tasks.Task<FlexMail.Service.PutFilesResponse> PutFilesAsync(FlexMail.Service.PutFilesRequest request)
        {
            return base.Channel.PutFilesAsync(request);
        }

        public FlexMail.Service.CreateEfficyActivityResponse CreateEfficyActivity(FlexMail.Service.CreateEfficyActivityRequest request)
        {
            return base.Channel.CreateEfficyActivity(request);
        }

        public System.Threading.Tasks.Task<FlexMail.Service.CreateEfficyActivityResponse> CreateEfficyActivityAsync(FlexMail.Service.CreateEfficyActivityRequest request)
        {
            return base.Channel.CreateEfficyActivityAsync(request);
        }

        public FlexMail.Service.UpdateEfficyActivityResponse UpdateEfficyActivity(FlexMail.Service.UpdateEfficyActivityRequest request)
        {
            return base.Channel.UpdateEfficyActivity(request);
        }

        public System.Threading.Tasks.Task<FlexMail.Service.UpdateEfficyActivityResponse> UpdateEfficyActivityAsync(FlexMail.Service.UpdateEfficyActivityRequest request)
        {
            return base.Channel.UpdateEfficyActivityAsync(request);
        }

        public FlexMail.Service.DeleteEfficyActivityResponse DeleteEfficyActivity(FlexMail.Service.DeleteEfficyActivityRequest request)
        {
            return base.Channel.DeleteEfficyActivity(request);
        }

        public System.Threading.Tasks.Task<FlexMail.Service.DeleteEfficyActivityResponse> DeleteEfficyActivityAsync(FlexMail.Service.DeleteEfficyActivityRequest request)
        {
            return base.Channel.DeleteEfficyActivityAsync(request);
        }

        public FlexMail.Service.GetEfficyActivitiesResponse GetEfficyActivities(FlexMail.Service.GetEfficyActivitiesRequest request)
        {
            return base.Channel.GetEfficyActivities(request);
        }

        public System.Threading.Tasks.Task<FlexMail.Service.GetEfficyActivitiesResponse> GetEfficyActivitiesAsync(FlexMail.Service.GetEfficyActivitiesRequest request)
        {
            return base.Channel.GetEfficyActivitiesAsync(request);
        }

        public FlexMail.Service.GetEmailAddressHistoryResponse GetEmailAddressHistory(FlexMail.Service.GetEmailAddressHistoryRequest request)
        {
            return base.Channel.GetEmailAddressHistory(request);
        }

        public System.Threading.Tasks.Task<FlexMail.Service.GetEmailAddressHistoryResponse> GetEmailAddressHistoryAsync(FlexMail.Service.GetEmailAddressHistoryRequest request)
        {
            return base.Channel.GetEmailAddressHistoryAsync(request);
        }

        public FlexMail.Service.GetCampaignHistoryResponse GetCampaignHistory(FlexMail.Service.GetCampaignHistoryRequest request)
        {
            return base.Channel.GetCampaignHistory(request);
        }

        public System.Threading.Tasks.Task<FlexMail.Service.GetCampaignHistoryResponse> GetCampaignHistoryAsync(FlexMail.Service.GetCampaignHistoryRequest request)
        {
            return base.Channel.GetCampaignHistoryAsync(request);
        }

        public FlexMail.Service.GetHistoryResponse GetHistory(FlexMail.Service.GetHistoryRequest request)
        {
            return base.Channel.GetHistory(request);
        }

        public System.Threading.Tasks.Task<FlexMail.Service.GetHistoryResponse> GetHistoryAsync(FlexMail.Service.GetHistoryRequest request)
        {
            return base.Channel.GetHistoryAsync(request);
        }

        public FlexMail.Service.GetFormResultsResponse GetFormResults(FlexMail.Service.GetFormResultsRequest request)
        {
            return base.Channel.GetFormResults(request);
        }

        public System.Threading.Tasks.Task<FlexMail.Service.GetFormResultsResponse> GetFormResultsAsync(FlexMail.Service.GetFormResultsRequest request)
        {
            return base.Channel.GetFormResultsAsync(request);
        }

        public FlexMail.Service.GetFormsResponse GetForms(FlexMail.Service.GetFormsRequest request)
        {
            return base.Channel.GetForms(request);
        }

        public System.Threading.Tasks.Task<FlexMail.Service.GetFormsResponse> GetFormsAsync(FlexMail.Service.GetFormsRequest request)
        {
            return base.Channel.GetFormsAsync(request);
        }

        public FlexMail.Service.GetBalanceResponse GetBalance(FlexMail.Service.GetBalanceRequest request)
        {
            return base.Channel.GetBalance(request);
        }

        public System.Threading.Tasks.Task<FlexMail.Service.GetBalanceResponse> GetBalanceAsync(FlexMail.Service.GetBalanceRequest request)
        {
            return base.Channel.GetBalanceAsync(request);
        }

        public FlexMail.Service.GetCampaignSummaryResponse GetCampaignSummary(FlexMail.Service.GetCampaignSummaryRequest request)
        {
            return base.Channel.GetCampaignSummary(request);
        }

        public System.Threading.Tasks.Task<FlexMail.Service.GetCampaignSummaryResponse> GetCampaignSummaryAsync(FlexMail.Service.GetCampaignSummaryRequest request)
        {
            return base.Channel.GetCampaignSummaryAsync(request);
        }

        public FlexMail.Service.ImportBlacklistResponse ImportBlacklist(FlexMail.Service.ImportBlacklistRequest request)
        {
            return base.Channel.ImportBlacklist(request);
        }

        public System.Threading.Tasks.Task<FlexMail.Service.ImportBlacklistResponse> ImportBlacklistAsync(FlexMail.Service.ImportBlacklistRequest request)
        {
            return base.Channel.ImportBlacklistAsync(request);
        }

        public FlexMail.Service.CreateAccountResponse CreateAccount(FlexMail.Service.CreateAccountRequest request)
        {
            return base.Channel.CreateAccount(request);
        }

        public System.Threading.Tasks.Task<FlexMail.Service.CreateAccountResponse> CreateAccountAsync(FlexMail.Service.CreateAccountRequest request)
        {
            return base.Channel.CreateAccountAsync(request);
        }

        public FlexMail.Service.UpdateAccountResponse UpdateAccount(FlexMail.Service.UpdateAccountRequest request)
        {
            return base.Channel.UpdateAccount(request);
        }

        public System.Threading.Tasks.Task<FlexMail.Service.UpdateAccountResponse> UpdateAccountAsync(FlexMail.Service.UpdateAccountRequest request)
        {
            return base.Channel.UpdateAccountAsync(request);
        }

        public FlexMail.Service.DeleteAccountResponse DeleteAccount(FlexMail.Service.DeleteAccountRequest request)
        {
            return base.Channel.DeleteAccount(request);
        }

        public System.Threading.Tasks.Task<FlexMail.Service.DeleteAccountResponse> DeleteAccountAsync(FlexMail.Service.DeleteAccountRequest request)
        {
            return base.Channel.DeleteAccountAsync(request);
        }

        public FlexMail.Service.GetAccountsResponse GetAccounts(FlexMail.Service.GetAccountsRequest request)
        {
            return base.Channel.GetAccounts(request);
        }

        public System.Threading.Tasks.Task<FlexMail.Service.GetAccountsResponse> GetAccountsAsync(FlexMail.Service.GetAccountsRequest request)
        {
            return base.Channel.GetAccountsAsync(request);
        }

        public FlexMail.Service.AccountAddCreditsResponse AccountAddCredits(FlexMail.Service.AccountAddCreditsRequest request)
        {
            return base.Channel.AccountAddCredits(request);
        }

        public System.Threading.Tasks.Task<FlexMail.Service.AccountAddCreditsResponse> AccountAddCreditsAsync(FlexMail.Service.AccountAddCreditsRequest request)
        {
            return base.Channel.AccountAddCreditsAsync(request);
        }

        public FlexMail.Service.AccountRevokeCreditsResponse AccountRevokeCredits(FlexMail.Service.AccountRevokeCreditsRequest request)
        {
            return base.Channel.AccountRevokeCredits(request);
        }

        public System.Threading.Tasks.Task<FlexMail.Service.AccountRevokeCreditsResponse> AccountRevokeCreditsAsync(FlexMail.Service.AccountRevokeCreditsRequest request)
        {
            return base.Channel.AccountRevokeCreditsAsync(request);
        }

        public FlexMail.Service.GetCustomReportResponse GetCustomReport(FlexMail.Service.GetCustomReportRequest request)
        {
            return base.Channel.GetCustomReport(request);
        }

        public System.Threading.Tasks.Task<FlexMail.Service.GetCustomReportResponse> GetCustomReportAsync(FlexMail.Service.GetCustomReportRequest request)
        {
            return base.Channel.GetCustomReportAsync(request);
        }

        public FlexMail.Service.RegisterTransactionEndResponse RegisterTransactionEnd(FlexMail.Service.RegisterTransactionEndRequest request)
        {
            return base.Channel.RegisterTransactionEnd(request);
        }

        public System.Threading.Tasks.Task<FlexMail.Service.RegisterTransactionEndResponse> RegisterTransactionEndAsync(FlexMail.Service.RegisterTransactionEndRequest request)
        {
            return base.Channel.RegisterTransactionEndAsync(request);
        }

        public FlexMail.Service.UpdateTruvoOrderResponse UpdateTruvoOrder(FlexMail.Service.UpdateTruvoOrderRequest request)
        {
            return base.Channel.UpdateTruvoOrder(request);
        }

        public System.Threading.Tasks.Task<FlexMail.Service.UpdateTruvoOrderResponse> UpdateTruvoOrderAsync(FlexMail.Service.UpdateTruvoOrderRequest request)
        {
            return base.Channel.UpdateTruvoOrderAsync(request);
        }

        public FlexMail.Service.GVImportSelectionResponse GVImportSelection(FlexMail.Service.GVImportSelectionRequest request)
        {
            return base.Channel.GVImportSelection(request);
        }

        public System.Threading.Tasks.Task<FlexMail.Service.GVImportSelectionResponse> GVImportSelectionAsync(FlexMail.Service.GVImportSelectionRequest request)
        {
            return base.Channel.GVImportSelectionAsync(request);
        }
    }

    #pragma warning restore
}
