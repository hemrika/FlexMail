﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FlexMail.Service;

namespace FlexMail
{
    /// <summary>
    /// 
    /// </summary>
    public class Campaign : IDisposable
    {
        internal Campaign()
        {
            FlexMail.Resources.Campaign.Culture = Client.CultureInfo;
        }

        #region Campaigns

        private GetCampaignsResp _campaigns = null;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="type"></param>
        /// <returns></returns>
        public List<CampaignType> Campaigns(campaignTypeType type = campaignTypeType.Campaign)
        {
            try
            {
                if (_campaigns == null)
                {
                    var req = new GetCampaignsReq() { header = Client.RequestHeader };

                    req.type = type;

                    GetCampaignsRequest request = new GetCampaignsRequest() { GetCampaignsReq = req };
                    GetCampaignsResponse response = Client.API.GetCampaigns(request);
                    _campaigns = response.GetCampaignsResp;
                }

                if (_campaigns != null && _campaigns.errorCode == (int)errorCode.No_error)
                    return _campaigns.campaignTypeItems.ToList<CampaignType>();
                else
                    if (_campaigns != null) throw new FlexMailException(FlexMail.Resources.Campaign.ResourceManager.GetString("Campaigns_" + _campaigns.errorCode), _campaigns.errorCode);

                throw new FlexMailException(FlexMail.Resources.Campaign.ResourceManager.GetString("Campaigns_" + _campaigns.errorCode), _campaigns.errorCode);
            }
            catch (Exception ex)
            {
                System.Diagnostics.Trace.TraceError(ex.Message);
                throw;
            }

            finally
            {
                _campaigns = null;
            }
        }

        #endregion

        #region Send

        

        /// <summary>
        /// 
        /// </summary>
        /// <param name="campaignId"></param>
        /// <param name="campaignSendTimestamp"></param>
        public void Send(string campaignId = null, string campaignSendTimestamp = null)
        {
            SendCampaignResp _send = null;
            try
            {
                if (_send == null)
                {
                    var req = new SendCampaignReq() { header = Client.RequestHeader };

                    if (!string.IsNullOrWhiteSpace(campaignId))
                        req.campaignId = int.Parse(campaignId);

                    if (!string.IsNullOrWhiteSpace(campaignSendTimestamp))
                        req.campaignSendTimestamp = campaignSendTimestamp;

                    SendCampaignRequest request = new SendCampaignRequest() { SendCampaignReq = req };
                    SendCampaignResponse response = Client.API.SendCampaign(request);
                    _send = response.SendCampaignResp;
                }

                if (_send != null && _send.errorCode == (int)errorCode.No_error)
                    return;
                else
                    if (_send != null) throw new FlexMailException(FlexMail.Resources.Campaign.ResourceManager.GetString("Send_" + _send.errorCode), _send.errorCode);

                throw new FlexMailException(FlexMail.Resources.Blacklist.ResourceManager.GetString("Send_" + _send.errorCode), _send.errorCode);
            }
            catch (Exception ex)
            {
                System.Diagnostics.Trace.TraceError(ex.Message);
                throw;
            }
            finally
            {
                _send = null;
            }
        }

        #endregion

        #region SendTest

        

        /// <summary>
        /// 
        /// </summary>
        /// <param name="testCampaignType"></param>
        public void SendTest(TestCampaignType testCampaignType = null)
        {
            SendTestCampaignResp _sendTest = null;

            try
            {
                if (_sendTest == null)
                {
                    var req = new SendTestCampaignReq() { header = Client.RequestHeader };

                    if (testCampaignType != null)
                        req.testCampaignType = testCampaignType;

                    SendTestCampaignRequest request = new SendTestCampaignRequest() { SendTestCampaignReq = req };
                    SendTestCampaignResponse response = Client.API.SendTestCampaign(request);
                    _sendTest = response.SendTestCampaignResp;
                }
                if (_sendTest != null && _sendTest.errorCode == (int)errorCode.No_error)
                    return;
                else
                    if (_sendTest != null) throw new FlexMailException(FlexMail.Resources.Campaign.ResourceManager.GetString("SendTest_" + _sendTest.errorCode), _sendTest.errorCode);

                throw new FlexMailException(FlexMail.Resources.Blacklist.ResourceManager.GetString("SendTest_" + _sendTest.errorCode), _sendTest.errorCode);
            }
            catch (Exception ex)
            {
                System.Diagnostics.Trace.TraceError(ex.Message);
                throw;
            }
            finally
            {
                _sendTest = null;
            }
        }

        #endregion

        #region Update

        

        /// <summary>
        /// 
        /// </summary>
        /// <param name="campaignType"></param>
        public void Update(CampaignType campaignType = null)
        {
            UpdateCampaignResp _update = null;

            try
            {
                if (_update == null)
                {
                    var req = new UpdateCampaignReq() { header = Client.RequestHeader };

                    if (campaignType != null)
                        req.campaignType = campaignType;

                    UpdateCampaignRequest request = new UpdateCampaignRequest() { UpdateCampaignReq = req };
                    UpdateCampaignResponse response = Client.API.UpdateCampaign(request);
                    _update = response.UpdateCampaignResp;
                }

                if (_update != null && _update.errorCode == (int)errorCode.No_error)
                    return;
                else
                    if (_update != null) throw new FlexMailException(FlexMail.Resources.Campaign.ResourceManager.GetString("Update_" + _update.errorCode), _update.errorCode);

                throw new FlexMailException(FlexMail.Resources.Blacklist.ResourceManager.GetString("Update_" + _update.errorCode), _update.errorCode);
            }
            catch (Exception ex)
            {
                System.Diagnostics.Trace.TraceError(ex.Message);
                throw;
            }
            finally
            {
                _update = null;
            }
        }

        #endregion

        #region Create

        

        /// <summary>
        /// 
        /// </summary>
        /// <param name="campaignType"></param>
        /// <returns></returns>
        public int Create(CampaignType campaignType = null)
        {
            CreateCampaignResp _create = null;

            try
            {
                if (_create == null)
                {
                    var req = new CreateCampaignReq() { header = Client.RequestHeader };

                    if (campaignType != null)
                        req.campaignType = campaignType;

                    CreateCampaignRequest request = new CreateCampaignRequest() { CreateCampaignReq = req };
                    CreateCampaignResponse response = Client.API.CreateCampaign(request);
                    _create = response.CreateCampaignResp;
                }

                if (_create != null && _create.errorCode == (int)errorCode.No_error)
                    return _create.campaignId;
                else
                    if (_create != null) throw new FlexMailException(FlexMail.Resources.Campaign.ResourceManager.GetString("Update_" + _create.errorCode), _create.errorCode);

                throw new FlexMailException(FlexMail.Resources.Blacklist.ResourceManager.GetString("Update_" + _create.errorCode), _create.errorCode);
            }
            catch (Exception ex)
            {
                System.Diagnostics.Trace.TraceError(ex.Message);
                throw;
            }
            finally
            {
                _create = null;
            }
        }

        #endregion

        #region Delete



        /// <summary>
        /// 
        /// </summary>
        /// <param name="campaignType"></param>
        public void Delete(CampaignType campaignType = null)
        {
            DeleteCampaignResp _delete = null;

            try
            {

                if (_delete == null)
                {
                    var req = new DeleteCampaignReq() { header = Client.RequestHeader };

                    if (campaignType != null)
                        req.campaignType = campaignType;

                    DeleteCampaignRequest request = new DeleteCampaignRequest() { DeleteCampaignReq = req };
                    DeleteCampaignResponse response = Client.API.DeleteCampaign(request);
                    _delete = response.DeleteCampaignResp;
                }

                if (_delete != null && _delete.errorCode == (int)errorCode.No_error)
                    return;
                else
                    if (_delete != null) throw new FlexMailException(FlexMail.Resources.Campaign.ResourceManager.GetString("Delete_" + _delete.errorCode), _delete.errorCode);

                throw new FlexMailException(FlexMail.Resources.Blacklist.ResourceManager.GetString("Delete_" + _delete.errorCode), _delete.errorCode);
            }
            catch (Exception ex)
            {
                System.Diagnostics.Trace.TraceError(ex.Message);
                throw;
            }
            finally
            {
                _delete = null;
            }
        }

        #endregion

        #region History

        /// <summary>
        /// 
        /// </summary>
        /// <param name="campaignId"></param>
        /// <param name="sort"></param>
        /// <param name="timestampFrom"></param>
        /// <param name="timestampTill"></param>
        /// <returns></returns>
        public CampaignHistoryType History(string campaignId = null, string sort = null, string timestampFrom = null, string timestampTill = null)
        {
            GetCampaignHistoryResp _history = null;

            try
            {
                if (_history == null)
                {
                    var req = new GetCampaignHistoryReq() { header = Client.RequestHeader };

                    if (!string.IsNullOrWhiteSpace(campaignId))
                        req.campaignId = campaignId;

                    if (!string.IsNullOrWhiteSpace(sort))
                        req.sort = sort;

                    if (!string.IsNullOrWhiteSpace(timestampFrom))
                        req.timestampFrom = timestampFrom;

                    if (!string.IsNullOrWhiteSpace(timestampTill))
                        req.timestampTill = timestampTill;

                    GetCampaignHistoryRequest request = new GetCampaignHistoryRequest() { GetCampaignHistoryReq = req };
                    GetCampaignHistoryResponse response = Client.API.GetCampaignHistory(request);
                    _history = response.GetCampaignHistoryResp;
                }

                if (_history != null && _history.errorCode == (int)errorCode.No_error)
                    return _history.campaignHistoryType;
                else
                    if (_history != null) throw new FlexMailException(FlexMail.Resources.Campaign.ResourceManager.GetString("History_" + _history.errorCode), _history.errorCode);

                throw new FlexMailException(FlexMail.Resources.Blacklist.ResourceManager.GetString("History_" + _history.errorCode), _history.errorCode);
            }
            catch (Exception ex)
            {
                System.Diagnostics.Trace.TraceError(ex.Message);
                throw;
            }
            finally
            {
                _history = null;
            }
        }

        #endregion

        #region Report

        /// <summary>
        /// 
        /// </summary>
        /// <param name="campaignId"></param>
        /// <param name="language"></param>
        /// <returns></returns>
        public CampaignReportType Report(string campaignId = null, string language = "NL")
        {
            GetCampaignReportResp _report = null;

            try
            {

                if (_report == null)
                {
                    var req = new GetCampaignReportReq() { header = Client.RequestHeader };

                    if (!string.IsNullOrWhiteSpace(campaignId))
                        req.campaignId = int.Parse(campaignId);

                    req.language = language;

                    GetCampaignReportRequest request = new GetCampaignReportRequest() { GetCampaignReportReq = req };
                    GetCampaignReportResponse response = Client.API.GetCampaignReport(request);
                    _report = response.GetCampaignReportResp;
                }

                if (_report != null && _report.errorCode == (int)errorCode.No_error)
                    return _report.campaignReportType;
                else
                    if (_report != null) throw new FlexMailException(FlexMail.Resources.Campaign.ResourceManager.GetString("Report_" + _report.errorCode), _report.errorCode);

                throw new FlexMailException(FlexMail.Resources.Blacklist.ResourceManager.GetString("Report_" + _report.errorCode), _report.errorCode);
            }
            catch (Exception ex)
            {
                System.Diagnostics.Trace.TraceError(ex.Message);
                throw;
            }
            finally
            {
                _report = null;
            }
        }

        #endregion

        #region Summary

        private GetCampaignSummaryResp _summary = null;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="campaignId"></param>
        /// <returns></returns>
        public CampaignSummaryType Summary(string campaignId = null)
        {
            GetCampaignSummaryResp _summary = null;

            try
            {

                if (_summary == null)
                {
                    var req = new GetCampaignSummaryReq() { header = Client.RequestHeader };

                    if (!string.IsNullOrWhiteSpace(campaignId))
                        req.campaignId = campaignId;

                    GetCampaignSummaryRequest request = new GetCampaignSummaryRequest() { GetCampaignSummaryReq = req };
                    GetCampaignSummaryResponse response = Client.API.GetCampaignSummary(request);
                    _summary = response.GetCampaignSummaryResp;
                }

                if (_summary != null && _summary.errorCode == (int)errorCode.No_error)
                    return _summary.campaignSummaryType;
                else
                    if (_summary != null) throw new FlexMailException(FlexMail.Resources.Campaign.ResourceManager.GetString("Summary_" + _summary.errorCode), _summary.errorCode);

                throw new FlexMailException(FlexMail.Resources.Blacklist.ResourceManager.GetString("Summary_" + _summary.errorCode), _summary.errorCode);
            }
            catch (Exception ex)
            {
                System.Diagnostics.Trace.TraceError(ex.Message);
                throw;
            }
            finally
            {
                _summary = null;
            }
        }


        #endregion

        #region IDisposable Support

        private bool disposedValue = false; // To detect redundant calls

        /// <summary>
        /// 
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {
                }

                disposedValue = true;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        ~Campaign() { Dispose(false); }

        /// <summary>
        /// 
        /// </summary>
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        #endregion

    }
}
