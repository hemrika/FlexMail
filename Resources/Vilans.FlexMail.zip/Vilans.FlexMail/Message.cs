﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FlexMail.Service;

namespace FlexMail
{
    /// <summary>
    /// 
    /// </summary>
    public class Message : IDisposable
    {
        #region Messages

        private GetMessagesResp _messages = null;

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public List<MessageType> Messages(bool archived  = false, bool metaDataOnly = true, bool optin = true)
        {
            try
            {
                if (_messages == null)
                {
                    GetMessagesRequest request = new GetMessagesRequest() { GetMessagesReq = new GetMessagesReq() { header = Client.RequestHeader, archived  = archived, metaDataOnly = metaDataOnly, optin = optin } };
                    GetMessagesResponse response = Client.API.GetMessages(request);
                    _messages = response.GetMessagesResp;
                }

                if(_messages.errorCode == (int)errorCode.No_error)
                    return _messages.messageTypeItems.ToList<MessageType>();

                throw new FlexMailException(_messages.errorMessage, _messages.errorCode);
            }
            catch (Exception ex)
            {
                if(_messages !=null)
                    System.Diagnostics.Trace.TraceError(_messages.errorMessage ?? ex.Message);
                else
                    System.Diagnostics.Trace.TraceError(ex.Message);

                throw;
            }

            finally
            {
                _messages = null;
            }
        }

        #endregion

        #region Create

        private CreateMessageResp _create = null;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="messageType"></param>
        /// <returns></returns>
        public int Create(MessageType messageType = null)
        {
            try
            {
                if (_create == null)
                {
                    var req = new CreateMessageReq() { header = Client.RequestHeader };

                    if (messageType != null)
                        req.messageType = messageType;

                    CreateMessageRequest request = new CreateMessageRequest() { CreateMessageReq = req };
                    CreateMessageResponse response = Client.API.CreateMessage(request);
                    _create = response.CreateMessageResp;
                }

                if(_create.errorCode == (int)errorCode.No_error)
                    return _create.messageId;

                throw new FlexMailException(_create.errorMessage, _create.errorCode);
            }
            catch (Exception)
            {
                System.Diagnostics.Trace.TraceError(_create.errorMessage);
                throw;
            }

            finally
            {
                _create = null;
            }
        }

        #endregion

        #region Delete

        private DeleteMessageResp _delete = null;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="messageType"></param>
        public void Delete(MessageType messageType = null)
        {
            try
            {
                if (_delete == null)
                {
                    var req = new DeleteMessageReq() { header = Client.RequestHeader };

                    if (messageType != null)
                        req.messageType = messageType;

                    DeleteMessageRequest request = new DeleteMessageRequest() { DeleteMessageReq = req };
                    DeleteMessageResponse response = Client.API.DeleteMessage(request);
                    _delete = response.DeleteMessageResp;
                }

                if(_delete.errorCode == (int)errorCode.No_error)
                    return;

                throw new FlexMailException(_delete.errorMessage, _delete.errorCode);
            }
            catch (Exception)
            {
                System.Diagnostics.Trace.TraceError(_delete.errorMessage);
                throw;
            }
            finally
            {
                _delete = null;
            }
        }

        #endregion

        #region Update

        private UpdateMessageResp _update = null;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="messageType"></param>
        public void Update(MessageType messageType = null)
        {
            try
            {
                if (_update == null)
                {
                    var req = new UpdateMessageReq() { header = Client.RequestHeader };

                    if (messageType != null)
                        req.messageType = messageType;

                    UpdateMessageRequest request = new UpdateMessageRequest() { UpdateMessageReq = req };
                    UpdateMessageResponse response = Client.API.UpdateMessage(request);
                    _update = response.UpdateMessageResp;
                }

                if(_update.errorCode == (int)errorCode.No_error)
                    return;

                throw new FlexMailException(_update.errorMessage, _update.errorCode);
            }
            catch (Exception)
            {
                System.Diagnostics.Trace.TraceError(_update.errorMessage);
                throw;
            }

            finally
            {
                _update = null;
            }
        }

        #endregion

        #region IDisposable Support

        private bool disposedValue = false; // To detect redundant calls

        /// <summary>
        /// 
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {
                }

                _messages = null;
                _create = null;
                _delete = null;
                _update = null;

                disposedValue = true;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        ~Message() { Dispose(false); }

        /// <summary>
        /// 
        /// </summary>
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        #endregion

    }
}
