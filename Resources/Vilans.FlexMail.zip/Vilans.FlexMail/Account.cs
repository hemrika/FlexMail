﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FlexMail.Service;

namespace FlexMail
{
    /// <summary>
    /// 
    /// </summary>
    public class Account : IDisposable
    {

        #region Balance

        private GetBalanceResp _balance = null;

        /// <summary>
        /// 
        /// </summary>
        internal GetBalanceResp Balance
        {
            get
            {
                if (_balance == null)
                {
                    GetBalanceRequest request = new GetBalanceRequest() { GetBalanceReq = new GetBalanceReq() { header = Client.RequestHeader } };
                    GetBalanceResponse response = Client.API.GetBalance(request);

                    _balance = response.GetBalanceResp;
                }

                return _balance;
            }
        }

        /// <summary>
        /// Email credits available
        /// </summary>
        public int Email
        {
            get
            {
                return Balance.email;
            }
        }

        /// <summary>
        /// Fax credits available
        /// </summary>
        public int Fax
        {
            get
            {
                return Balance.fax;
            }
        }

        /// <summary>
        /// SMS credits available
        /// </summary>
        public int SMS
        {
            get
            {
                return Balance.sms;
            }
        }

        #endregion

        #region Bounces

        private GetBouncesResp _bounces = null;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="campaignId"></param>
        /// <param name="mailingListId"></param>
        /// <param name="timestampSince"></param>
        /// <returns></returns>
        public List<BounceType> Bounces(string campaignId = null, string mailingListId = null, string timestampSince = null)
        {
            try
            { 
                if (_bounces == null)
                {
                    var req = new GetBouncesReq() { header = Client.RequestHeader };

                    if (!string.IsNullOrWhiteSpace(campaignId))
                        req.campaignId = int.Parse(campaignId);

                    if (!string.IsNullOrWhiteSpace(mailingListId))
                        req.mailingListId = int.Parse(mailingListId);

                    if (!string.IsNullOrWhiteSpace(timestampSince))
                        req.timestampSince = timestampSince;

                    GetBouncesRequest request = new GetBouncesRequest() { GetBouncesReq = req };
                    GetBouncesResponse response = Client.API.GetBounces(request);
                    _bounces = response.GetBouncesResp;
                }

                if (_bounces.errorCode == (int)errorCode.No_error)
                    return _bounces.bounceTypeItems.ToList<BounceType>();

                throw new FlexMailException(_bounces.errorMessage, _bounces.errorCode);
            }
            catch (Exception)
            {
                System.Diagnostics.Trace.TraceError(_bounces.errorMessage);
                throw;
            }
            finally
            {
                _bounces = null;
            }
        }

        #endregion

        #region ProfileUpdates

        private GetProfileUpdatesResp _profileUpdates = null;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="campaignId"></param>
        /// <param name="mailingListId"></param>
        /// <param name="timestampSince"></param>
        /// <returns></returns>
        public List<ProfileUpdateType> ProfileUpdates(string campaignId = null, string mailingListId = null, string timestampSince = null)
        {
            try
            {
                if (_profileUpdates == null)
                {

                    var req = new GetProfileUpdatesReq() { header = Client.RequestHeader };

                    if (!string.IsNullOrWhiteSpace(campaignId))
                        req.campaignId = int.Parse(campaignId);

                    if (!string.IsNullOrWhiteSpace(mailingListId))
                        req.mailingListId = int.Parse(mailingListId);

                    if (!string.IsNullOrWhiteSpace(timestampSince))
                        req.timestampSince = timestampSince;

                    GetProfileUpdatesRequest request = new GetProfileUpdatesRequest() { GetProfileUpdatesReq = req };
                    GetProfileUpdatesResponse response = Client.API.GetProfileUpdates(request);
                    _profileUpdates = response.GetProfileUpdatesResp;
                }

                if (_profileUpdates.errorCode == (int)errorCode.No_error)
                    return _profileUpdates.profileUpdateTypeItems.ToList<ProfileUpdateType>();

                throw new FlexMailException(_profileUpdates.errorMessage, _profileUpdates.errorCode);
            }
            catch (Exception)
            {
                System.Diagnostics.Trace.TraceError(_profileUpdates.errorMessage);
                throw;
            }
            finally
            {
                _profileUpdates = null;
            }
        }

        #endregion

        #region Subscriptions

        private GetSubscriptionsResp _subscriptions = null;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="mailingListId"></param>
        /// <param name="timestampSince"></param>
        /// <returns></returns>
        public List<SubscriptionType> Subscriptions(string mailingListId = null, string timestampSince = null)
        {
            try
            {
                if (_subscriptions == null)
                {
                    var req = new GetSubscriptionsReq() { header = Client.RequestHeader };

                    if (!string.IsNullOrWhiteSpace(mailingListId))
                        req.mailingListId = int.Parse(mailingListId);

                    if (!string.IsNullOrWhiteSpace(timestampSince))
                        req.timestampSince = timestampSince;

                    GetSubscriptionsRequest request = new GetSubscriptionsRequest() { GetSubscriptionsReq = req };
                    GetSubscriptionsResponse response = Client.API.GetSubscriptions(request);
                    _subscriptions = response.GetSubscriptionsResp;
                }

                if (_subscriptions.errorCode == (int)errorCode.No_error)
                    return _subscriptions.subscriptionTypeItems.ToList<SubscriptionType>();

                throw new FlexMailException(_subscriptions.errorMessage, _subscriptions.errorCode);
            }
            catch (Exception ex)
            {
                if (_subscriptions != null)
                    System.Diagnostics.Trace.TraceError(_subscriptions.errorMessage ?? ex.Message);
                else
                    System.Diagnostics.Trace.TraceError(ex.Message);

                throw;
            }
            finally
            {
                _subscriptions = null;
            }
        }

        #endregion

        #region Unsubscriptions

        private GetUnsubscriptionsResp _unsubscriptions = null;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="campaignId"></param>
        /// <param name="mailingListId"></param>
        /// <param name="subListUnsubscriptions"></param>
        /// <param name="timestampSince"></param>
        /// <returns></returns>
        public List<UnsubscriptionType> Unsubscriptions(string campaignId = null, string mailingListId = null, bool subListUnsubscriptions = false, string timestampSince = null)
        {
            try
            {

                if (_unsubscriptions == null)
                {
                    var req = new GetUnsubscriptionsReq() { header = Client.RequestHeader };

                    if (!string.IsNullOrWhiteSpace(campaignId))
                        req.campaignId = int.Parse(campaignId);

                    if (!string.IsNullOrWhiteSpace(mailingListId))
                        req.mailingListId = int.Parse(mailingListId);

                    req.subListUnsubscriptions = subListUnsubscriptions;

                    if (!string.IsNullOrWhiteSpace(timestampSince))
                        req.timestampSince = timestampSince;

                    GetUnsubscriptionsRequest request = new GetUnsubscriptionsRequest() { GetUnsubscriptionsReq = req };
                    GetUnsubscriptionsResponse response = Client.API.GetUnsubscriptions(request);
                    _unsubscriptions = response.GetUnsubscriptionsResp;
                }

                if (_unsubscriptions.errorCode == (int)errorCode.No_error)
                    return _unsubscriptions.unsubscriptionTypeItems.ToList<UnsubscriptionType>();

                throw new FlexMailException(_subscriptions.errorMessage, _subscriptions.errorCode);
            }
            catch (Exception)
            {
                System.Diagnostics.Trace.TraceError(_unsubscriptions.errorMessage);
                throw;
            }
            finally
            {
                _unsubscriptions = null;
            }

        }

        #endregion

        #region IDisposable Support

        private bool disposedValue = false; // To detect redundant calls

        /// <summary>
        /// 
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {
                }

                _balance = null;
                _bounces = null;
                _profileUpdates = null;
                _subscriptions = null;
                _unsubscriptions = null;

                disposedValue = true;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        ~Account() { Dispose(false); }

        /// <summary>
        /// 
        /// </summary>
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        #endregion

    }
}
