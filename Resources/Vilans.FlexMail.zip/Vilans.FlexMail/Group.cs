﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FlexMail.Service;

namespace FlexMail
{
    /// <summary>
    /// 
    /// </summary>
    public class Group : IDisposable
    {
        #region Groups

        private GetGroupsResp _groups = null;

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public List<GroupType> Groups()
        {
            try
            {
                if (_groups == null)
                {
                    GetGroupsRequest request = new GetGroupsRequest() { GetGroupsReq = new GetGroupsReq() { header = Client.RequestHeader } };
                    GetGroupsResponse response = Client.API.GetGroups(request);
                    _groups = response.GetGroupsResp;
                }

                if(_groups.errorCode == (int)errorCode.No_error)
                    return _groups.groupTypeItems.ToList<GroupType>();

                throw new FlexMailException(_groups.errorMessage, _groups.errorCode);
            }
            catch (Exception)
            {
                System.Diagnostics.Trace.TraceError(_groups.errorMessage);
                throw;
            }

            finally
            {
                _groups = null;
            }
        }

        #endregion

        #region Create

        private CreateGroupResp _create = null;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="groupType"></param>
        public void Create(GroupType groupType = null)
        {
            try
            {
                if (_create == null)
                {
                    var req = new CreateGroupReq() { header = Client.RequestHeader };

                    if (groupType != null)
                        req.groupType = groupType;

                    CreateGroupRequest request = new CreateGroupRequest() { CreateGroupReq = req };
                    CreateGroupResponse response = Client.API.CreateGroup(request);
                    _create = response.CreateGroupResp;
                }

                if(_create.errorCode == (int)errorCode.No_error)
                    return;

                throw new FlexMailException(_create.errorMessage, _create.errorCode);
            }
            catch (Exception)
            {
                System.Diagnostics.Trace.TraceError(_create.errorMessage);
                throw;
            }

            finally
            {
                _create = null;
            }
        }

        #endregion

        #region CreateGroup

        private CreateGroupSubscriptionResp _createGroup = null;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="groupSubscriptionType"></param>
        /// <returns></returns>
        public int CreateGroup(GroupSubscriptionType groupSubscriptionType = null)
        {
            try
            {
                if (_createGroup == null)
                {
                    var req = new CreateGroupSubscriptionReq() { header = Client.RequestHeader };

                    if (groupSubscriptionType != null)
                        req.groupSubscriptionType = groupSubscriptionType;

                    CreateGroupSubscriptionRequest request = new CreateGroupSubscriptionRequest() { CreateGroupSubscriptionReq = req };
                    CreateGroupSubscriptionResponse response = Client.API.CreateGroupSubscription(request);
                    _createGroup = response.CreateGroupSubscriptionResp;
                }

                if (_createGroup.errorCode == (int)errorCode.No_error)
                    return _createGroup.groupSubscriptionId;

                throw new FlexMailException(_createGroup.errorMessage, _create.errorCode);
            }
            catch (Exception)
            {
                System.Diagnostics.Trace.TraceError(_createGroup.errorMessage);
                throw;
            }
            finally
            {
                _createGroup = null;
            }
        }

        #endregion

        #region Delete

        private DeleteGroupResp _delete = null;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="groupType"></param>
        public void Delete(GroupType groupType = null)
        {
            try
            {

                if (_delete == null)
                {
                    var req = new DeleteGroupReq() { header = Client.RequestHeader };

                    if (groupType != null)
                        req.groupType = groupType;

                    DeleteGroupRequest request = new DeleteGroupRequest() { DeleteGroupReq = req };
                    DeleteGroupResponse response = Client.API.DeleteGroup(request);
                    _delete = response.DeleteGroupResp;
                }

                if (_delete.errorCode == (int)errorCode.No_error)
                    return;

                throw new FlexMailException(_delete.errorMessage, _delete.errorCode);
            }
            catch (Exception)
            {
                System.Diagnostics.Trace.TraceError(_delete.errorMessage);
                throw;
            }
            finally
            {
                _delete = null;
            }
        }

        #endregion

        #region DeleteGroup

        private DeleteGroupSubscriptionResp _deleteGroup = null;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="groupSubscriptionType"></param>
        public void Delete(GroupSubscriptionType groupSubscriptionType = null)
        {
            try
            {
                if (_deleteGroup == null)
                {
                    var req = new DeleteGroupSubscriptionReq() { header = Client.RequestHeader };

                    if (groupSubscriptionType != null)
                        req.groupSubscriptionType = groupSubscriptionType;

                    DeleteGroupSubscriptionRequest request = new DeleteGroupSubscriptionRequest() { DeleteGroupSubscriptionReq = req };
                    DeleteGroupSubscriptionResponse response = Client.API.DeleteGroupSubscription(request);
                    _deleteGroup = response.DeleteGroupSubscriptionResp;
                }

                if (_deleteGroup.errorCode == (int)errorCode.No_error)
                    return;

                throw new FlexMailException(_deleteGroup.errorMessage, _deleteGroup.errorCode);
            }
            catch (Exception)
            {
                System.Diagnostics.Trace.TraceError(_deleteGroup.errorMessage);
                throw;
            }
            finally
            {
                _deleteGroup = null;
            }
        }

        #endregion

        #region Update

        private UpdateGroupResp _update = null;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="groupType"></param>
        public void Update(GroupType groupType = null)
        {
            try
            {
                if (_update == null)
                {
                    var req = new UpdateGroupReq() { header = Client.RequestHeader };

                    if (groupType != null)
                        req.groupType = groupType;

                    UpdateGroupRequest request = new UpdateGroupRequest() { UpdateGroupReq = req };
                    UpdateGroupResponse response = Client.API.UpdateGroup(request);
                    _update = response.UpdateGroupResp;
                }

                if (_update.errorCode == (int)errorCode.No_error)
                    return;

                throw new FlexMailException(_update.errorMessage, _update.errorCode);
            }
            catch (Exception)
            {
                System.Diagnostics.Trace.TraceError(_update.errorMessage);
                throw;
            }
            finally
            {
                _update = null;
            }
        }

        #endregion

        #region IDisposable Support

        private bool disposedValue = false; // To detect redundant calls

        /// <summary>
        /// 
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {
                }

                _create = null;
                _createGroup = null;
                _delete = null;
                _deleteGroup = null;
                _groups = null;
                _update = null;

                disposedValue = true;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        ~Group() { Dispose(false); }

        /// <summary>
        /// 
        /// </summary>
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        #endregion

    }
}
