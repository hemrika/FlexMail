﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FlexMail.Service;

namespace FlexMail
{
    /// <summary>
    /// 
    /// </summary>
    public class Form : IDisposable
    {
        #region Forms

        private GetFormsResp _forms = null;

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public List<FormType> Forms()
        {
            try
            {
                if (_forms == null)
                {
                    GetFormsRequest request = new GetFormsRequest() { GetFormsReq = new GetFormsReq() { header = Client.RequestHeader } };
                    GetFormsResponse response = Client.API.GetForms(request);
                    _forms = response.GetFormsResp;
                }

                if (_forms.errorCode == (int)errorCode.No_error)
                    return _forms.formTypeItems.ToList<FormType>();

                throw new FlexMailException(_forms.errorMessage, _forms.errorCode);
            }
            catch (Exception)
            {
                System.Diagnostics.Trace.TraceError(_forms.errorMessage);
                throw;
            }

            finally
            {
                _forms = null;
            }
        }

        #endregion

        #region Results

        private GetFormResultsResp _results = null;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="formId"></param>
        /// <param name="campaignId"></param>
        /// <param name="timestampSince"></param>
        /// <returns></returns>
        public List<FormResultType> Results(string formId = null, string campaignId = null, string timestampSince = null)
        {
            try
            {
                if (_results == null)
                {
                    var req = new GetFormResultsReq() { header = Client.RequestHeader };

                    if (!string.IsNullOrWhiteSpace(formId))
                        req.formId = formId;

                    if (!string.IsNullOrWhiteSpace(campaignId))
                        req.campaignId = campaignId;

                    if (!string.IsNullOrWhiteSpace(timestampSince))
                        req.timestampSince = timestampSince;

                    GetFormResultsRequest request = new GetFormResultsRequest() { GetFormResultsReq = req };
                    GetFormResultsResponse response = Client.API.GetFormResults(request);
                    _results = response.GetFormResultsResp;
                }

                if (_results.errorCode == (int)errorCode.No_error)
                    return _results.formResultTypeItems.ToList<FormResultType>();

                throw new FlexMailException(_results.errorMessage, _results.errorCode);
            }
            catch (Exception)
            {
                System.Diagnostics.Trace.TraceError(_results.errorMessage);
                throw;
            }

            finally
            {
                _results = null;
            }
        }

        #endregion

        #region IDisposable Support

        private bool disposedValue = false; // To detect redundant calls

        /// <summary>
        /// 
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {
                }

                _forms = null;
                _results = null;

                disposedValue = true;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        ~Form() { Dispose(false); }

        /// <summary>
        /// 
        /// </summary>
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        #endregion

    }
}
