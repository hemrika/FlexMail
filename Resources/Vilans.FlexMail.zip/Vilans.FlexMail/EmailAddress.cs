﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FlexMail.Service;

namespace FlexMail
{
    /// <summary>
    /// 
    /// </summary>
    public class EmailAddress : IDisposable
    {
        #region EmailAddresses

        private GetEmailAddressesResp _emailaddresses = null;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="emailAddressTypeItems"></param>
        /// <param name="groupIds"></param>
        /// <param name="mailingListIds"></param>
        /// <returns></returns>
        public List<EmailAddressType> EmailAddresses(EmailAddressType[] emailAddressTypeItems = null, int[] groupIds = null, int[] mailingListIds = null)
        {
            try
            {
                if (_emailaddresses == null)
                {
                    var req = new GetEmailAddressesReq() { header = Client.RequestHeader };

                    if (emailAddressTypeItems != null)
                        req.emailAddressTypeItems = emailAddressTypeItems;

                    if (groupIds != null)
                        req.groupIds = groupIds;

                    if (mailingListIds != null)
                        req.mailingListIds = mailingListIds;

                    GetEmailAddressesRequest request = new GetEmailAddressesRequest() { GetEmailAddressesReq = req };
                    GetEmailAddressesResponse response = Client.API.GetEmailAddresses(request);
                    _emailaddresses = response.GetEmailAddressesResp;
                }

                if (_emailaddresses.errorCode == (int)errorCode.No_error)
                    return _emailaddresses.emailAddressTypeItems.ToList<EmailAddressType>();

                throw new FlexMailException(_emailaddresses.errorMessage, _emailaddresses.errorCode);
            }
            catch (Exception)
            {
                System.Diagnostics.Trace.TraceError(_emailaddresses.errorMessage);
                throw;
            }

            finally
            {
                _emailaddresses = null;
            }
        }

        #endregion

        #region Create

        private CreateEmailAddressResp _create = null;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="emailAddressType"></param>
        /// <param name="mailingListId"></param>
        /// <param name="optInType"></param>
        /// <returns></returns>
        public int Create(EmailAddressType emailAddressType = null, string mailingListId = null, OptInType optInType = null)
        {
            try
            {
                if (_create == null)
                {
                    var req = new CreateEmailAddressReq() { header = Client.RequestHeader };

                    if (emailAddressType != null)
                        req.emailAddressType = emailAddressType;

                    if (!string.IsNullOrWhiteSpace(mailingListId))
                        req.mailingListId = int.Parse(mailingListId);

                    if (optInType != null)
                        req.optInType = optInType;

                    CreateEmailAddressRequest request = new CreateEmailAddressRequest() { CreateEmailAddressReq = req };
                    CreateEmailAddressResponse response = Client.API.CreateEmailAddress(request);
                    _create = response.CreateEmailAddressResp;
                }

                if(_create.errorCode == (int)errorCode.No_error)
                    return _create.emailAddressId;

                throw new FlexMailException(_create.errorMessage, _create.errorCode);
            }
            catch (Exception ex)
            {
                System.Diagnostics.Trace.TraceError(_create.errorMessage);
                throw;
            }

            finally
            {
                _create = null;
            }
        }

        #endregion

        #region Delete

        private DeleteEmailAddressResp _delete = null;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="emailAddressType"></param>
        /// <param name="mailingListId"></param>
        public void Delete(EmailAddressType emailAddressType = null, string mailingListId = null)
        {
            try
            {
                if (_delete == null)
                {
                    var req = new DeleteEmailAddressReq() { header = Client.RequestHeader };

                    if (emailAddressType != null)
                        req.emailAddressType = emailAddressType;

                    if (!string.IsNullOrWhiteSpace(mailingListId))
                        req.mailingListId = int.Parse(mailingListId);

                    DeleteEmailAddressRequest request = new DeleteEmailAddressRequest() { DeleteeEmailAddressReq = req };
                    DeleteEmailAddressResponse response = Client.API.DeleteEmailAddress(request);
                    _delete = response.DeleteEmailAddressResp;
                }

                if(_delete.errorCode == (int)errorCode.No_error)
                    return;

                throw new FlexMailException(_delete.errorMessage, _delete.errorCode);
            }
            catch (Exception)
            {
                System.Diagnostics.Trace.TraceError(_delete.errorMessage);
                throw;
            }
            finally
            {
                _delete = null;
            }
        }

        #endregion

        #region Update

        private UpdateEmailAddressResp _update = null;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="emailAddressType"></param>
        /// <param name="mailingListId"></param>
        /// <returns></returns>
        public int Update(EmailAddressType emailAddressType = null, string mailingListId = null)
        {
            try
            {
                if (_update == null)
                {
                    var req = new UpdateEmailAddressReq() { header = Client.RequestHeader };

                    if (emailAddressType != null)
                        req.emailAddressType = emailAddressType;

                    if (!string.IsNullOrWhiteSpace(mailingListId))
                        req.mailingListId = int.Parse(mailingListId);

                    UpdateEmailAddressRequest request = new UpdateEmailAddressRequest() { UpdateEmailAddressReq = req };
                    UpdateEmailAddressResponse response = Client.API.UpdateEmailAddress(request);
                    _update = response.UpdateEmailAddressResp;
                }

                if(_update.errorCode == (int)errorCode.No_error)
                    return _update.emailAddressId;

                throw new FlexMailException(_update.errorMessage, _update.errorCode);
            }
            catch (Exception)
            {
                System.Diagnostics.Trace.TraceError(_update.errorMessage);
                throw;
            }

            finally
            {
                _update = null;
            }
        }

        #endregion

        #region History

        private GetEmailAddressHistoryResp _history = null;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="emailAddress"></param>
        /// <param name="emailAddressHistoryOptionsType"></param>
        /// <param name="sort"></param>
        /// <param name="timestampFrom"></param>
        /// <param name="timestampTill"></param>
        /// <returns></returns>
        public EmailAddressHistoryType History(string emailAddress = null, EmailAddressHistoryOptionsType emailAddressHistoryOptionsType = null, string sort = null, string timestampFrom = null, string timestampTill = null)
        {
            try
            {

                if (_history == null)
                {
                    var req = new GetEmailAddressHistoryReq() { header = Client.RequestHeader };

                    if (!string.IsNullOrWhiteSpace(emailAddress))
                        req.emailAddress = emailAddress;

                    if (emailAddressHistoryOptionsType != null)
                        req.emailAddressHistoryOptionsType = emailAddressHistoryOptionsType;

                    if (!string.IsNullOrWhiteSpace(sort))
                        req.sort = sort;

                    if (!string.IsNullOrWhiteSpace(timestampFrom))
                        req.timestampFrom = timestampFrom;

                    if (!string.IsNullOrWhiteSpace(timestampTill))
                        req.timestampTill = timestampTill;

                    GetEmailAddressHistoryRequest request = new GetEmailAddressHistoryRequest() { GetEmailAddressHistoryReq = req };
                    GetEmailAddressHistoryResponse response = Client.API.GetEmailAddressHistory(request);
                    _history = response.GetEmailAddressHistoryResp;
                }

                if (_history.errorCode == (int)errorCode.No_error)
                    return _history.emailAddressHistoryType;

                throw new FlexMailException(_history.errorMessage, _history.errorCode);
            }
            catch (Exception)
            {
                System.Diagnostics.Trace.TraceError(_history.errorMessage);
                throw;
            }
            finally
            {
                _history = null;
            }
        }

        #endregion

        #region Import

        private ImportEmailAddressesResp _import = null;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="mailingListId"></param>
        /// <param name="emailAddressTypeItems"></param>
        /// <param name="allowDuplicates"></param>
        /// <param name="overwrite"></param>
        /// <param name="synchronise"></param>
        /// <param name="referenceField"></param>
        /// <param name="allowBouncedOut"></param>
        /// <returns></returns>
        internal List<ImportEmailAddressRespType> Import(string mailingListId = null, EmailAddressType[] emailAddressTypeItems = null, bool allowDuplicates = false, bool overwrite = false, bool synchronise = false, ReferenceFieldType referenceField = ReferenceFieldType.email, bool allowBouncedOut = true)
        {
            try
            {
                if (_import == null)
                {
                    var req = new ImportEmailAddressesReq() { header = Client.RequestHeader };

                    if (!string.IsNullOrWhiteSpace(mailingListId))
                        req.mailingListId = int.Parse(mailingListId);

                    if (emailAddressTypeItems != null)
                        req.emailAddressTypeItems = emailAddressTypeItems;

                    req.allowDuplicates = allowDuplicates;
                    req.overwrite = overwrite;
                    req.synchronise = synchronise;
                    req.referenceField = referenceField;
                    req.allowBouncedOut = allowBouncedOut;

                    ImportEmailAddressesRequest request = new ImportEmailAddressesRequest() { ImportEmailAddressesReq = req };
                    ImportEmailAddressesResponse response = Client.API.ImportEmailAddresses(request);
                    _import = response.ImportEmailAddressesResp;
                }

                if (_import.errorCode == (int)errorCode.No_error)
                    return _import.importEmailAddressRespTypeItems.ToList<ImportEmailAddressRespType>();

                throw new FlexMailException(_import.errorMessage, _import.errorCode);
            }
            catch (Exception)
            {
                System.Diagnostics.Trace.TraceError(_import.errorMessage);
                throw;
            }
            finally
            {
                _import = null;
            }
        }

        #endregion

        #region IDisposable Support

        private bool disposedValue = false; // To detect redundant calls

        /// <summary>
        /// 
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {
                }

                _create = null;
                _delete = null;
                _emailaddresses = null;
                _update = null;
                _history = null;
                _import = null;

                disposedValue = true;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        ~EmailAddress() { Dispose(false); }

        /// <summary>
        /// 
        /// </summary>
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        #endregion

    }

}
