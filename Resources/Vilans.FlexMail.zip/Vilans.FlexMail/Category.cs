﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FlexMail.Service;

namespace FlexMail
{
    /// <summary>
    /// 
    /// </summary>
    public class Category: IDisposable
    {
        #region Categories

        private GetCategoriesResp _categories = null;

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public List<CategoryType> Categories()
        {
            try
            {
                if (_categories == null)
                {
                    GetCategoriesRequest request = new GetCategoriesRequest() { GetCategoriesReq = new GetCategoriesReq() { header = Client.RequestHeader } };
                    GetCategoriesResponse response = Client.API.GetCategories(request);
                    _categories = response.GetCategoriesResp;
                }

                if(_categories.errorCode == (int)errorCode.No_error)
                    return _categories.categoryTypeItems.ToList<CategoryType>();

                throw new FlexMailException(_categories.errorMessage, _categories.errorCode);
            }
            catch (Exception)
            {
                System.Diagnostics.Trace.TraceError(_categories.errorMessage);
                throw;
            }

            finally
            {
                _categories = null;
            }
        }

        #endregion

        #region Create

        private CreateCategoryResp _create = null;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="categoryName"></param>
        /// <returns></returns>
        public int Create(string categoryName = null)
        {
            try
            {
                if (_create == null)
                {
                    var req = new CreateCategoryReq() { header = Client.RequestHeader };

                    if (!string.IsNullOrWhiteSpace(categoryName))
                        req.categoryName = categoryName;

                    CreateCategoryRequest request = new CreateCategoryRequest() { CreateCategoryReq = req };
                    CreateCategoryResponse response = Client.API.CreateCategory(request);
                    _create = response.CreateCategoryResp;
                }

                if(_create.errorCode == (int)errorCode.No_error)
                    return _create.categoryId;

                throw new FlexMailException(_create.errorMessage, _create.errorCode);
            }
            catch (Exception)
            {
                System.Diagnostics.Trace.TraceError(_create.errorMessage);
                throw;
            }

            finally
            {
                _create = null;
            }
        }

        #endregion

        #region Delete

        private DeleteCategoryResp _delete = null;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="categoryId"></param>
        public void Delete(string categoryId = null)
        {
            try
            {

                if (_delete == null)
                {
                    var req = new DeleteCategoryReq() { header = Client.RequestHeader };

                    if (!string.IsNullOrWhiteSpace(categoryId))
                        req.categoryId = int.Parse(categoryId);

                    DeleteCategoryRequest request = new DeleteCategoryRequest() { DeleteCategoryReq = req };
                    DeleteCategoryResponse response = Client.API.DeleteCategory(request);
                    _delete = response.DeleteCategoryResp;
                }

                if(_delete.errorCode == (int)errorCode.No_error)
                    return;

                throw new FlexMailException(_delete.errorMessage, _delete.errorCode);
            }
            catch (Exception)
            {
                System.Diagnostics.Trace.TraceError(_delete.errorMessage);
                throw;
            }
            finally
            {
                _delete = null;
            }
        }

        #endregion

        #region Update

        private UpdateCategoryResp _update = null;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="categoryId"></param>
        /// <param name="categoryName"></param>
        public void Update(string categoryId = null, string categoryName = null)
        {
            try
            {
                if (_update == null)
                {
                    var req = new UpdateCategoryReq() { header = Client.RequestHeader };

                    if (!string.IsNullOrWhiteSpace(categoryId))
                        req.categoryId = int.Parse(categoryId);

                    if (!string.IsNullOrWhiteSpace(categoryName))
                        req.categoryName = categoryName;

                    UpdateCategoryRequest request = new UpdateCategoryRequest() { UpdateCategoryReq = req };
                    UpdateCategoryResponse response = Client.API.UpdateCategory(request);
                    _update = response.UpdateCategoryResp;
                }

                if(_update.errorCode == (int)errorCode.No_error)
                    return;

                throw new FlexMailException(_update.errorMessage, _update.errorCode);
            }
            catch (Exception)
            {
                System.Diagnostics.Trace.TraceError(_update.errorMessage);
                throw;
            }

            finally
            {
                _update = null;
            }
        }

        #endregion

        #region IDisposable Support

        private bool disposedValue = false; // To detect redundant calls

        /// <summary>
        /// 
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {
                }

                _categories = null;
                _create = null;
                _delete = null;
                _update = null;

                disposedValue = true;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        ~Category() { Dispose(false); }

        /// <summary>
        /// 
        /// </summary>
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        #endregion

    }
}
